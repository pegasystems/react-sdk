export declare const resolveReferencedPConnect: (pConnect: any) => any;
/**
 * A helper function to create an object consisting react component as per the type.
 * This is used by CaseSummary template.
 * @param {object} pConnectMeta Object containing meta information for the particular field authored
 * @param {Function} getPConnect PConnect function passed along to other components.
 * @param {string} displayMode displayMode string contains information about the layout of component in review mode.
 */
export declare function prepareComponentInCaseSummary(pConnectMeta: any, getPConnect: Function): any;
export declare function resolveReferenceFields(item: {
    [key: string]: unknown;
}, hideFieldLabels: boolean, recordKey: string, pConnect: typeof PConnect): any;
//# sourceMappingURL=utils.d.ts.map