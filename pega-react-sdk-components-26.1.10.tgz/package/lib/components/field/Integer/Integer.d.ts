import type { PConnFieldProps } from '../../../types/PConnProps';
interface IntegerProps extends PConnFieldProps {
    showFieldMessage?: boolean;
    messageConfig?: {
        content?: string;
        visibility?: boolean;
    };
    variant?: string;
}
export default function Integer(props: IntegerProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=Integer.d.ts.map