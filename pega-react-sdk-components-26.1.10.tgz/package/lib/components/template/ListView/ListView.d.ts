import React from 'react';
import './ListView.css';
import type { PConnProps } from '../../../types/PConnProps';
interface ListViewProps extends PConnProps {
    bInForm?: boolean;
    globalSearch?: boolean;
    referenceList?: any[];
    selectionMode?: string;
    referenceType?: string;
    payload?: any;
    parameters?: any;
    compositeKeys?: any;
    showDynamicFields?: boolean;
    readonlyContextList?: any;
    selectedValues?: any;
    value: any;
    viewName?: string;
    showRecords?: boolean;
    displayAs?: string;
    localeReference?: string;
}
export default function ListView(props: ListViewProps): React.JSX.Element;
export {};
//# sourceMappingURL=ListView.d.ts.map