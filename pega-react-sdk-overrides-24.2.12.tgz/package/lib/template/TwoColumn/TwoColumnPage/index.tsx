export { default } from './TwoColumnPage';
