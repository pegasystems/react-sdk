export declare const getCurrencyOptions: (inISOCode: string) => {
    locale: string;
    style: string;
    currency: string;
};
export declare const getCurrencyCharacters: (inISOCode: string) => {
    theCurrencySymbol: string;
    theDecimalIndicator: string;
    theDigitGroupSeparator: string;
};
//# sourceMappingURL=currency-utils.d.ts.map