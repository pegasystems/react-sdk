export { default } from './TextContent';
