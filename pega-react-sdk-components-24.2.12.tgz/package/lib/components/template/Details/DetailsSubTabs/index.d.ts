export { default } from './DetailsSubTabs';
//# sourceMappingURL=index.d.ts.map