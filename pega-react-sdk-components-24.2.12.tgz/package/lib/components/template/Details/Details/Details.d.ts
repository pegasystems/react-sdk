import { PConnProps } from '../../../../types/PConnProps';
interface DetailsProps extends PConnProps {
    label: string;
    showLabel: boolean;
    showHighlightedData: boolean;
}
export default function Details(props: DetailsProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Details.d.ts.map