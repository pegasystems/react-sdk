import { PConnProps } from '../../../../types/PConnProps';
interface SimpleTableProps extends PConnProps {
    multiRecordDisplayAs: string;
    allowTableEdit: boolean;
    contextClass: any;
    label: string;
    propertyLabel?: string;
    displayMode?: string;
    fieldMetadata?: any;
    hideLabel?: boolean;
    parameters?: any;
    isDataObject?: boolean;
    type?: string;
    ruleClass?: string;
    authorContext?: string;
    name?: string;
}
export default function SimpleTable(props: SimpleTableProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=SimpleTable.d.ts.map