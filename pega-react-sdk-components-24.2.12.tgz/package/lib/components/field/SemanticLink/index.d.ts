export { default } from './SemanticLink';
//# sourceMappingURL=index.d.ts.map