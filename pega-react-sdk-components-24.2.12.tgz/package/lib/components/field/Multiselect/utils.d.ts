import { updateNewInstuctions, insertInstruction, deleteInstruction } from '../../helpers/instructions-utils';
export declare const setVisibilityForList: (c11nEnv: any, visibility: any) => void;
declare const useDeepMemo: (memoFn: any, key: any) => any;
declare const preProcessColumns: (columns: any) => any;
declare const getDisplayFieldsMetaData: (columns: any) => any;
declare const doSearch: (searchText: any, clickedGroup: any, initialCaseClass: any, displayFieldMeta: any, dataApiObj: any, itemsTree: any, isGroupData: any, showSecondaryInSearchOnly: any, selected: any) => Promise<any>;
declare const setValuesToPropertyList: (searchText: any, assocProp: any, items: any, columns: any, actions: any, updatePropertyInRedux?: boolean) => any;
declare const getGroupDataForItemsTree: (groupDataSource: any, groupsDisplayFieldMeta: any, showSecondaryInSearchOnly: any) => any;
export { useDeepMemo, preProcessColumns, getDisplayFieldsMetaData, doSearch, setValuesToPropertyList, getGroupDataForItemsTree, updateNewInstuctions, insertInstruction, deleteInstruction };
//# sourceMappingURL=utils.d.ts.map