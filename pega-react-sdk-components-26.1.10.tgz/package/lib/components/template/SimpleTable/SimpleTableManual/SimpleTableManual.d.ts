import React, { type PropsWithChildren } from 'react';
import type { PConnProps } from '../../../../types/PConnProps';
interface SimpleTableManualProps extends PConnProps {
    hideAddRow?: boolean;
    hideDeleteRow?: boolean;
    referenceList?: any[];
    renderMode?: string;
    presets?: any[];
    label?: string;
    showLabel?: boolean;
    dataPageName?: string;
    contextClass?: string;
    propertyLabel?: string;
    fieldMetadata?: any;
    editMode?: string;
    addAndEditRowsWithin?: any;
    viewForAddAndEditModal?: any;
    editModeConfig?: any;
    displayMode?: string;
    useSeparateViewForEdit: any;
    viewForEditModal: any;
    validatemessage?: string;
    required?: boolean;
    targetClassLabel?: string;
    uniqueField?: string;
    hideEditRow?: boolean;
}
export default function SimpleTableManual(props: PropsWithChildren<SimpleTableManualProps>): React.JSX.Element | null;
export {};
//# sourceMappingURL=SimpleTableManual.d.ts.map