import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../../types/PConnProps';
import './WideNarrowForm.css';
interface WideNarrowFormProps extends PConnProps {
}
export default function WideNarrowForm(props: PropsWithChildren<WideNarrowFormProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=WideNarrowForm.d.ts.map