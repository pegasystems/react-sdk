export interface FormStatusProps {
    hasSuggestions?: boolean;
    showFieldMessage?: boolean;
    messageVisibility?: boolean;
    showSuggestionStatus?: boolean;
    validatemessage?: string;
    readOnly?: boolean;
}
export type Status = 'error' | 'warning' | 'pending' | 'success' | undefined;
declare const useStatus: ({ showFieldMessage, messageVisibility, validatemessage, readOnly }?: FormStatusProps) => Status;
export default useStatus;
//# sourceMappingURL=useStatus.d.ts.map