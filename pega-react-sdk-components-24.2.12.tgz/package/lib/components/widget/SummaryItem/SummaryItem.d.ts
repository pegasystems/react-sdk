import { PConnProps } from '../../../types/PConnProps';
import './SummaryItem.css';
interface SummaryItemProps extends PConnProps {
    menuIconOverride$: string;
    menuIconOverrideAction$: any;
    arItems$: any[] | any;
}
export default function SummaryItem(props: SummaryItemProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=SummaryItem.d.ts.map