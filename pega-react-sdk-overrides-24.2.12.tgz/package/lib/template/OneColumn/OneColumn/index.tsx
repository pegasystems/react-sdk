export { default } from './OneColumn';
