import { ReactElement } from 'react';
import { PConnFieldProps } from '../../../types/PConnProps';
interface GroupProps extends PConnFieldProps {
    children: ReactElement[];
    heading: string;
    showHeading: boolean;
    instructions?: string;
    collapsible: boolean;
    type: string;
}
export default function Group(props: GroupProps): import("react/jsx-runtime").JSX.Element | null;
export {};
//# sourceMappingURL=Group.d.ts.map