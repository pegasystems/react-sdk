export { default } from './PortalAgentSplitView';
//# sourceMappingURL=index.d.ts.map