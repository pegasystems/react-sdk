export { default } from './DetailsThreeColumn';
//# sourceMappingURL=index.d.ts.map