export { default } from './PromotedFilters';
//# sourceMappingURL=index.d.ts.map