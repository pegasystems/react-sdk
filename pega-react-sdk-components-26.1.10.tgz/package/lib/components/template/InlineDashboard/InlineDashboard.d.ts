import type { PropsWithChildren } from 'react';
import type { PConnProps } from '../../../types/PConnProps';
interface InlineDashboardProps extends PConnProps {
    title: string;
    filterPosition?: string;
}
export default function InlineDashboard(props: PropsWithChildren<InlineDashboardProps>): import("react").JSX.Element;
export {};
//# sourceMappingURL=InlineDashboard.d.ts.map