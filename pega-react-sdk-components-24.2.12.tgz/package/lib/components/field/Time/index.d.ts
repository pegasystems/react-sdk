export { default } from './Time';
//# sourceMappingURL=index.d.ts.map