import { ReactElement } from 'react';
/**
 *
 * @param {*} pConn - pConnect object of the view
 * @returns {string} - returns the name of referenceList
 */
export declare const getReferenceList: (pConn: any) => any;
/**
 * creates and returns react element of the view
 * @param {*} pConn - pConnect object of the view
 * @param {*} index - index of the fieldGroup item
 * @param {*} viewConfigPath - boolean value to check for children in config
 * @returns {*} - return the react element of the view
 */
export declare function buildView(pConn: any, index: any, viewConfigPath: any): ReactElement;
//# sourceMappingURL=field-group-utils.d.ts.map