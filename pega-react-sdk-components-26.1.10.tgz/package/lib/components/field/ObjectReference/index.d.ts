export { default } from './ObjectReference';
//# sourceMappingURL=index.d.ts.map