import type { PConnProps } from '../../../types/PConnProps';
interface TabContentProps extends PConnProps {
    layout?: 'one-column' | 'two-column' | 'narrow-wide' | 'wide-narrow' | 'dynamic';
    label?: string;
    showLabel?: boolean;
}
/**
 * Port of the Constellation `TabContent` template, which App Studio uses for the views of the tabs it creates
 * (for example a case page tab with an agent). The tab container draws the card, as for the other tab templates.
 */
export default function TabContent(props: TabContentProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=TabContent.d.ts.map