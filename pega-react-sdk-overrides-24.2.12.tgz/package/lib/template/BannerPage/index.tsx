export { default } from './BannerPage';
