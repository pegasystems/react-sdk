// import { exec } from 'child_process';
const path = require('path');
const fs = require('fs');
const util = require('node:util');
const exec = util.promisify(require('node:child_process').exec);

describe('create publish and delete local override', () => {
  it('initial delete/cleanup', async () => {
    const script = `npm run deleteAll Local override Y --prefix ../../..`;

    const { stdout, stderr } = await exec(script);
    // console.log(stdout);
    expect(stdout).not.toBeNull();
    expect(stderr).not.toBeNull();
  }, 10000);

  it('npm run create Local override', async () => {
    const fileName = 'AutoComplete';
    const script = `npm run override Field ${fileName} --prefix ../../..`;

    const { stdout, stderr } = await exec(script);
    // console.log(stdout);
    expect(stdout).not.toBeNull();
    expect(stderr).not.toBeNull();

    // want message to contain component name
    expect(stdout).toContain(fileName);

    // don't want message with already exists
    expect(stdout).not.toContain('already exists');

    // check to see file exists

    // const fileDir = path.resolve('../../..', `src/components/${newFileName}`);
    const createOverrideFile = path.resolve('../../..', path.join(`src/components/override-sdk/field/${fileName}`, `${fileName}.tsx`));
    const doesOverrideExist = fs.existsSync(createOverrideFile);
    expect(doesOverrideExist).toBeTruthy();
  }, 20000);

  it('npm run publish override (no fetch) verify in map', async () => {
    const fileName = 'AutoComplete';

    const script = `npm run publish override field/${fileName} LoanV2 01-01-01 N noFetch --prefix ../../..`;
    const { stdout, stderr } = await exec(script);
    // console.log(stdout);
    expect(stdout).not.toBeNull();

    expect(stderr).not.toBeNull();

    expect(stdout).toContain('AutoComplete');
    // expect(stdout).toContain('Compiled successfully.');

    // verify in map
    const pegaLocalComponentMapPath = path.join(path.resolve('../../..'), 'sdk-local-component-map.js');
    const mapData = fs.readFileSync(pegaLocalComponentMapPath, { encoding: 'utf8' });
    let isInMap = true;

    if (mapData.indexOf('AutoComplete') < 0) {
      isInMap = false;
    }


    expect(isInMap).toBeTruthy();
  }, 200000);

  it('npm run delete Local override verify removed from map', async () => {
    const fileName = 'AutoComplete';
    const script = `npm run delete Local override field/${fileName} Y --prefix ../../..`;

    const { stdout, stderr } = await exec(script);
    // console.log(stdout);
    expect(stdout).not.toBeNull();
    expect(stderr).not.toBeNull();

    // want message to contain component name
    expect(stdout).toContain(fileName);

    // message deleted
    expect(stdout).toContain('is deleted');

    // check to see file exists

    // const fileDir = path.resolve('../../..', `src/components/${newFileName}`);
    const createFile = path.resolve('../../..', path.join(`src/components/override-sdk/field/${fileName}`, `${fileName}.tsx`));
    const doesExist = fs.existsSync(createFile);
    expect(doesExist).not.toBeTruthy();

    // verify removed from map
    const pegaLocalComponentMapPath = path.join(path.resolve('../../..'), 'sdk-local-component-map.js');
    const mapData = fs.readFileSync(pegaLocalComponentMapPath, { encoding: 'utf8' });
    let isInMap = false;

    if (mapData.indexOf('AutoComplete') >= 0) {
      isInMap = true;
    }

    expect(isInMap).not.toBeTruthy();
  }, 10000);
});
