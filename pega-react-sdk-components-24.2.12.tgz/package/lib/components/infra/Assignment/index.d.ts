export { default } from './Assignment';
//# sourceMappingURL=index.d.ts.map