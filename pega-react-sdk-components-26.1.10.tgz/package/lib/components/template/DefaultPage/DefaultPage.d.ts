import type { ReactNode } from 'react';
import type { GenAICoach } from '../../widget/GenAICoach/GenAICoach.types';
export interface CommonPageProps {
    /** Page title */
    title: string;
    /** Page icon */
    icon: string;
    /** Region children */
    children: ReactNode | ReactNode[];
    /** Dynamic page pconnect object */
    getPConnect: () => typeof PConnect;
    /** Enable GetNextWork in page */
    enableGetNextWork?: boolean;
    /** GetAI coaches configured in page */
    coaches?: GenAICoach[];
    /** Locale reference */
    localeReference: string;
}
interface DefaultPageProps extends CommonPageProps {
    /** Default page layout one or two columns */
    layout: 'one-column' | 'two-column' | 'wide-narrow' | 'narrow-wide' | 'dynamic';
    /** Flag to enable banner/hero */
    enableBanner?: boolean;
    /** Banner - Heading displayed */
    heading?: string;
    /** Banner - Message displayed */
    message?: string;
    /** Banner - Theme of the image */
    imageTheme?: 'light' | 'dark' | undefined;
    /** Banner - Background image */
    backgroundImage?: string;
    /** Banner - Background color */
    backgroundColor?: string;
    /** Banner - Tint image */
    tintImage?: boolean;
}
export default function DefaultPage({ layout, children, getPConnect, localeReference, coaches, enableBanner, heading, message, imageTheme, backgroundImage, backgroundColor, tintImage }: DefaultPageProps): string | number | bigint | boolean | import("react").JSX.Element | Iterable<ReactNode> | Promise<string | number | bigint | boolean | import("react").ReactPortal | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined;
export {};
//# sourceMappingURL=DefaultPage.d.ts.map