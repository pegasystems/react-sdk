export { default } from './AppShell';
//# sourceMappingURL=index.d.ts.map