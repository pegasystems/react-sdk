export { default } from './MultiReferenceReadOnly';
//# sourceMappingURL=index.d.ts.map