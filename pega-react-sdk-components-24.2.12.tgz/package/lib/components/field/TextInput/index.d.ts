export { default } from './TextInput';
//# sourceMappingURL=index.d.ts.map