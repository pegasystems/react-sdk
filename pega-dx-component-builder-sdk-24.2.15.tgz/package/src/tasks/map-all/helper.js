
import {
  getOptionsCategory
} from '../../util.js';
import { COMPONENT_SCHEMA, CATEGORY_CONSTELLATION, CATEGORY_CUSTOM } from '../../constants.js';



export const getBuildCategory = async (options) => {
  const categoryType = getOptionsCategory(options);

  return [
    {
      name: 'category',
      type: 'rawlist',
      message: 'Category of components ?',
      choices: COMPONENT_SCHEMA.category,
      when() {
        return !options.params[4] && categoryType == null;
      }
    }
  ];
};
