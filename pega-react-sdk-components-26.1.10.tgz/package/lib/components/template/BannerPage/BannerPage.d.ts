import { type PropsWithChildren } from 'react';
import type { GenAICoach } from '../../widget/GenAICoach/GenAICoach.types';
import type { PConnProps } from '../../../types/PConnProps';
interface BannerPageProps extends PConnProps {
    layout?: string;
    heading?: string;
    message?: string;
    imageTheme?: string;
    backgroundImage?: string;
    backgroundColor?: string;
    tintImage?: boolean;
    coaches?: GenAICoach[];
    localeReference?: string;
}
export default function BannerPage(props: PropsWithChildren<BannerPageProps>): string | number | bigint | boolean | import("react").JSX.Element | Iterable<import("react").ReactNode> | Promise<string | number | bigint | boolean | import("react").ReactPortal | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | Iterable<import("react").ReactNode> | null | undefined> | null | undefined;
export {};
//# sourceMappingURL=BannerPage.d.ts.map