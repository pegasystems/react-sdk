export { default } from './SummaryItem';
//# sourceMappingURL=index.d.ts.map