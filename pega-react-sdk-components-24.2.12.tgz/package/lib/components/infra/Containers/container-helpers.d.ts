export declare const isContainerInitialized: (pConnect: any) => boolean | undefined;
//# sourceMappingURL=container-helpers.d.ts.map