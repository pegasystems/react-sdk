export declare const SELECTION_MODE: {
    SINGLE: string;
    MULTI: string;
};
export declare const AT_FILTEREDLIST = "@FILTERED_LIST";
export declare const AT_PROPERTY = "@P";
export declare const SQUARE_BRACKET_START = "[";
export declare const SQUARE_BRACKET_END = "]";
export declare const SIMPLE_TABLE_MANUAL_READONLY = "SimpleTableManualReadOnly";
export declare const PAGE = "!P!";
export declare const PAGELIST = "!PL!";
export declare const PERIOD = ".";
export declare function updatePageListPropertyValue(value: string): string;
export declare function getPropertyValue(value: string): string;
export declare const generateColumns: (config: any, pConn: any, referenceType: string) => void;
export declare const addCompositeKeysToConfig: (config: any, pConn: any) => void;
export declare const getDataRelationshipContextFromKey: (key: string) => string;
export declare const createNewRecord: ({ referenceType, disableStartingFieldsForReference, pConn, contextClass, startingFields, getPConnect }: {
    referenceType: string;
    disableStartingFieldsForReference: boolean;
    pConn: any;
    contextClass: string;
    startingFields: Record<string, any>;
    getPConnect: any;
}) => any;
export declare const getAdditionalInfo: (pConn: any, propertyName: string) => {
    content: any;
} | undefined;
export declare const camelCase: (str: string) => string;
//# sourceMappingURL=utils.d.ts.map