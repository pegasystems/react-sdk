import { type ReactElement } from 'react';
import type { PConnFieldProps } from '../../../types/PConnProps';
interface GroupProps extends PConnFieldProps {
    children: ReactElement[];
    heading: string;
    showHeading: boolean;
    instructions?: string;
    collapseOnLoad?: any;
    type: string;
    defaultCollapsed?: any;
    collapsible?: any;
}
export default function Group(props: GroupProps): import("react").JSX.Element | null;
export {};
//# sourceMappingURL=Group.d.ts.map