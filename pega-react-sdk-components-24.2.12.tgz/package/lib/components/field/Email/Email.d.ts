import { PConnFieldProps } from '../../../types/PConnProps';
interface EmailProps extends PConnFieldProps {
}
export default function Email(props: EmailProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Email.d.ts.map