import type { UtilitiesLayoutProps } from '../GenAICoachContent/GenAICoach.types';
/**
 * The utilities column of a landing page: MUI port of the Cosmos `UtilitiesLayout` component. Collapsed, it offers a
 * "Chat with AI" button that opens the agent next to it; expanded, it shows the agent in the column (in a drawer
 * below the lg breakpoint). Below the md breakpoint the agent is shown in the page.
 */
export default function UtilitiesLayout(props: UtilitiesLayoutProps): import("react").JSX.Element;
//# sourceMappingURL=UtilitiesLayout.d.ts.map