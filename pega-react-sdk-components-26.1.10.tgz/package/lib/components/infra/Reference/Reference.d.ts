import type { PConnProps } from '../../../types/PConnProps';
interface ReferenceProps extends PConnProps {
    visibility?: boolean;
    context?: string;
    readOnly?: boolean;
    displayMode?: string;
}
export default function Reference(props: ReferenceProps): import("react").JSX.Element | null;
export {};
//# sourceMappingURL=Reference.d.ts.map