import { PConnProps } from '../../../../types/PConnProps';
interface TwoColumnPageProps extends PConnProps {
}
export default function TwoColumnPage(props: TwoColumnPageProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=TwoColumnPage.d.ts.map