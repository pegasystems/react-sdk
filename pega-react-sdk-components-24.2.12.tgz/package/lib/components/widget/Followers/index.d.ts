export { default } from './Followers';
//# sourceMappingURL=index.d.ts.map