import type { PConnProps } from '../../../types/PConnProps';
interface SummaryListProps extends PConnProps {
    arItems$: any[];
    menuIconOverride$?: string;
    menuIconOverrideAction$?: any;
}
export default function SummaryList(props: SummaryListProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=SummaryList.d.ts.map