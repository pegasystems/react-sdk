/**
 * Hook that subscribes to parameter field changes and triggers a data re-fetch
 * when the parameters change. This mirrors the useCascadeAndUpdate hook from
 * the constellation-frontend codebase.
 */
export declare function useCascadeAndUpdate({ getPConnect, listContext, referenceList, parameters, fetchDataFromServer }: {
    getPConnect: any;
    listContext: any;
    referenceList: any;
    parameters: any;
    fetchDataFromServer: any;
}): void;
export default function useInit(props: any): void;
//# sourceMappingURL=hooks.d.ts.map