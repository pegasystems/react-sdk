declare const useGetTabsCount: (deferLoadedTabs: any, uuid: any, selectedTabId: any, template: any) => {
    availableTabs: any;
    data: any[];
    loading: boolean;
    error: boolean;
    updateCurrentTabId: import("react").Dispatch<any>;
    refreshTabData: () => void;
};
export default useGetTabsCount;
//# sourceMappingURL=useGetTabsCount.d.ts.map