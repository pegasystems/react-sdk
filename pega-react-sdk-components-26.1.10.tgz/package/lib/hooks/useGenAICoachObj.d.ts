import type { ActionsProps, FileItemProps, GenAIMessageProps, MenuItems, MessageProps, QuestionnaireConfig, SendMessageProps, State } from '../components/designSystemExtension/GenAICoachContent/GenAICoach.types';
import type { GenAICoach } from '../components/widget/GenAICoach/GenAICoach.types';
declare const useGenAICoachObj: (coaches: undefined | GenAICoach[], caseID: string, pConnect: typeof PConnect, isCaseView?: boolean, utilitiesExpanded?: boolean, isLandingPage?: boolean) => {
    loading: boolean;
    messages: never[];
    coachOptions: never[];
    onCoachChange: () => void;
    onSend: () => void;
    onOpen: () => void;
    initialSuggestedMessages: never[];
    suggestions: undefined;
    error: string;
    onStateChange: (() => void) | undefined;
    guidedMode: boolean;
} | {
    loading: string | boolean;
    enableStreaming: boolean;
    messages: GenAIMessageProps[];
    coachOptions: MenuItems;
    onCoachChange: (id: string) => void;
    onSend: (sendItem: SendMessageProps) => Promise<void>;
    onOpen: () => void;
    initialSuggestedMessages: MessageProps[];
    suggestions: MenuItems;
    error: string;
    guidedMode: boolean;
    onStateChange: ((state: State) => void) | undefined;
    onLayoutChange: (inFullPageArg: boolean) => void;
    actions: ActionsProps;
    onNewChat: (() => void) | undefined;
    conversationHistory: {
        error: string | undefined;
        loading: boolean;
        data: {
            id: string;
            section: string;
            conversations: {
                id: string;
                title: string;
            }[];
        }[];
        onDismiss: () => void;
        onItemClick: (conversationId: string) => void;
        loadMore: () => void;
        selectedItemId: string;
    } | undefined;
    onAddAttachment: ((files: File[]) => void) | undefined;
    attachments: FileItemProps[];
    attachmentsError: string;
    draftMessage: string;
    conversationError: string;
    onStop: (() => void) | undefined;
    isCreatingConversation: boolean;
    salutation: string | undefined;
    questionnaireData: QuestionnaireConfig | undefined;
    onQuestionnaireDismiss: () => void;
} | undefined;
export default useGenAICoachObj;
//# sourceMappingURL=useGenAICoachObj.d.ts.map