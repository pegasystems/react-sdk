import path from 'path';
import fs from 'fs';
import { promisify } from 'util';
import { join } from 'path';

import inquirer from 'inquirer';
import ncp from 'ncp';
import chalk from 'chalk';
import { updateComponentMap  } from '../map/map.js';

import {
  checkPathAccess,
  showVersion,
  getPegaConfig,
  convertIntoKebabCase,
  getFramework,
  getComponentDirectoryPath,
  getComponents,
  getComponentDefaults
} from '../../util.js';

import { COMPONENT_SCHEMA,
  CATEGORY_OVERRIDE,
  SDK_CONFIG_JSON_FILENAME,
  DXCB_CONFIG,
  DXCB_COMPONENT_DEFAULTS,
  CUSTOM_TEMPLATES,
  OVERRIDE_TEMPLATE_PATH,
  OVERRIDE_REACT_LIB_PATH,
  OVERRIDE_ANGULAR_LIB_PATH } from '../../constants.js';

const pegaConfigJsonPath = path.join(path.resolve(), SDK_CONFIG_JSON_FILENAME);

const copy = promisify(ncp);

const copyComponentTemplate = async options => {
  return copy(options.overrideDirectory, options.targetDirectory, {
    clobber: false
  });
};


const checkAndCreateConfigComponentKey = async (targetDirectory) => {

  const configFile = path.join(targetDirectory, "config-ext.json");
  try {
    const configData = fs.readFileSync(path.resolve(configFile), 'utf8');
    let configObj = JSON.parse(configData);

    let writeUpdate = false;
    if (!configObj.componentKey || !configObj.label) {
      const name = configObj.name;

      if (!configObj.componentKey) {
        const componentKey = name;
        configObj = { componentKey, ...configObj };
      }

      if (!configObj.label) {
        const label = name;
        configObj = { label, ...configObj };
      }


      // stringify "4", makes the json string look like JSON in the file, formated instead of a single line
      const configContent = JSON.stringify(configObj, null, 4);

      // update file
      fs.writeFileSync(configFile, configContent, { encoding: 'utf8' });
    }

  }
  catch (err) {
    // no config-ext.json file, so no update, which is ok
    const arPaths = targetDirectory.split("/");
    const compName = arPaths[arPaths.length-1] ;
    console.log(chalk.yellow(`Component ${compName} has no config file for extension.`));
  }
}


const getListAvailableComponents = async (type) => {
  const components = await getComponents(false, CATEGORY_OVERRIDE);
  let fullList;
  const framework = await getFramework();
  switch (framework) {
    case "SDK-Angular":
      fullList = COMPONENT_SCHEMA.overrideAngularComponent[type];
      break;
    case "SDK-React":
      fullList = COMPONENT_SCHEMA.overrideReactComponent[type];
      break;
    case "SDK-WebComponents":
      fullList = COMPONENT_SCHEMA.overrideWCComponent[type];
      break;
  }

  let availList = [];
  for (var el in fullList) {

    let listEl = fullList[el].value;

    if (listEl.indexOf("/") >=0) {
      const arKey = listEl.split("/");
      listEl = arKey[arKey.length - 1];
    }

    if (framework === "SDK-Angular") {
      // need to convert to match in "includes"
      listEl = convertIntoKebabCase(listEl);
    }

    if (components.includes(listEl)) {
      // currently don't show, because too many separators inquirer flaky
      //availList.push(new inquirer.Separator("** " + fullList[el].name));
    }
    else {
      availList.push(fullList[el]);
    }
  }

  return availList;
}

const adjustAngularComponentName = (componentName) => {
  if (componentName.indexOf("/") >= 0) {
    componentName = componentName.split("/")[1];
  }


  return componentName;
}

const adjustAngularKebabCase = (componentName) => {
  componentName = componentName.replaceAll("/-", "/");
  return componentName;
}

const validateCompile = async (
  {
    componentName,
    type
  },
  options
) => {

  if (componentName == undefined) {
    console.log(chalk.red(`No ${type} components exist to override. Possibly already overridden.`));
    process.exit(1);
  }

  const originalComponentName = componentName;

  let pegaConfig = await getPegaConfig();

  // will need to put a case statement here checking framework
  const framework = await getFramework();
  let templateParentDir = "";

  switch (framework) {
    case "SDK-Angular":
      templateParentDir = OVERRIDE_ANGULAR_LIB_PATH;
      // componentName = adjustAngularComponentName(componentName);
      componentName = convertIntoKebabCase(componentName);
      componentName = adjustAngularKebabCase(componentName);
      break;
    case "SDK-React":
      templateParentDir = OVERRIDE_REACT_LIB_PATH;
      break;
    case "SDK-WebComponents":
      break;
  }

  if (pegaConfig[DXCB_CONFIG] &&
    pegaConfig[DXCB_CONFIG][CUSTOM_TEMPLATES] &&
    pegaConfig[DXCB_CONFIG][CUSTOM_TEMPLATES][OVERRIDE_TEMPLATE_PATH] &&
    pegaConfig[DXCB_CONFIG][CUSTOM_TEMPLATES][OVERRIDE_TEMPLATE_PATH] != "") {
    templateParentDir = pegaConfig[DXCB_CONFIG][CUSTOM_TEMPLATES][OVERRIDE_TEMPLATE_PATH];
  }



  // componentName has sub directory if components are in a sub directory of main "type"
  const overrideDirectory = `${templateParentDir}/${type}/${componentName}`;

  await checkPathAccess(overrideDirectory);

  let componentKey = componentName;
  if (componentKey.indexOf("/") >= 0) {
    componentKey = componentKey.split("/")[1];
  }
  const typeLC = type.toLowerCase();
  const targetDirectory = await getComponentDirectoryPath(join(typeLC, "/",componentKey), CATEGORY_OVERRIDE);

  const components = await getComponents(false, CATEGORY_OVERRIDE);
  if (components.includes(componentKey)) {
    console.log(chalk.red(`${componentKey} component already exists in ${targetDirectory}`));
    return;
  }

  await copyComponentTemplate({
    ...options,
    targetDirectory,
    overrideDirectory
  });

  await checkAndCreateConfigComponentKey(targetDirectory);


  console.log(chalk.green(`> Created ${componentKey} component in ${targetDirectory}`));

  const componentKeyWithType = join(type, componentKey);
  await updateComponentMap(componentKeyWithType, CATEGORY_OVERRIDE);

  console.log(chalk.green(`> Added ${componentKeyWithType} to map`));

};

export default async options => {
  showVersion();

  let promptType = null;
  if (options.params[3]) {
    let inputType = options.params[3];

    switch (inputType.toLowerCase()) {
      case "field" :
      case "f" :
        promptType = "field";
        break;
      case "template" :
      case "t" :
        promptType = "template";
        break;
      case "widget" :
      case "w" :
        promptType = "widget";
        break;
      case "designsystemextension" :
      case "des" :
      case "d" :
        promptType = "designSystemExtension";
        break;
      case "infra" :
      case "i" :
        promptType = "infra";
        break;
      }
  }

  await checkPathAccess(pegaConfigJsonPath);

  let data = fs.readFileSync(pegaConfigJsonPath, { encoding: 'utf8' });
  data = data && JSON.parse(data);

  if (!data[DXCB_CONFIG] || !data[DXCB_CONFIG][DXCB_COMPONENT_DEFAULTS]) {
    console.error(
      `${chalk.red.bold('ERROR')} Could not able find components defaults path in config.json`
    );
    process.exit(1);
  }

  const componentData = data[DXCB_CONFIG][DXCB_COMPONENT_DEFAULTS];

  const { organization, library} = componentData;

  let componentDefaults = await getComponentDefaults();
  componentDefaults.library = library;

  const formsList = await getListAvailableComponents("field");
  const desList = await getListAvailableComponents("designSystemExtension");
  const templateList = await getListAvailableComponents("template");
  const widgetList = await getListAvailableComponents("widget");
  const infraList = await getListAvailableComponents("infra");

  if (options.params.length >= 5) {
    let componentName = options.params[4];
    let type;

    if (promptType) type = promptType;

    await validateCompile(
      {
        componentName,
        type
      },
      options
    );
  }
  else {
    const questions = [
      {
        name: 'type',
        type: 'rawlist',
        message: 'Enter type of component',
        choices: COMPONENT_SCHEMA.overrideType,
        when (propmtType) {
          return promptType === null;
        }
      },
      {
        name: 'componentName',
        type: 'rawlist',
        message: 'Enter component to be overridden',
        choices: formsList,
        pageSize: 15,
        when(answers) {
          return formsList.length > 0 && (answers.type === 'field' || promptType === 'field');
        }
      },
      {
        name: 'componentName',
        type: 'rawlist',
        message: 'Enter component to be overridden',
        choices: desList,
        pageSize: 15,
        when(answers) {
          return desList.length > 0 && (answers.type === 'designSystemExtension' || promptType === 'designSystemExtension');
        }
      },
      {
        name: 'componentName',
        type: 'rawlist',
        message: 'Enter component to be overridden',
        choices: infraList,
        pageSize: 15,
        when(answers) {
          return infraList.length > 0 && (answers.type === 'infra'  || promptType === 'infra');
        }
      },
      {
        name: 'componentName',
        type: 'rawlist',
        message: 'Enter component to be overridden',
        choices: templateList,
        pageSize: 15,
        when(answers) {
          return templateList.length > 0 && (answers.type === 'template' || promptType === 'template');
        }
      },
      {
        name: 'componentName',
        type: 'rawlist',
        message: 'Enter component to be overridden',
        choices: widgetList,
        pageSize: 15,
        when(answers) {
          return widgetList.length > 0 && (answers.type === 'widget'  || promptType === 'widget');
        }
      },

    ];

    await inquirer.prompt(questions).then(async answers => {
      let {
        componentName,
        type
      } = answers;
      if (promptType) type = promptType;

      await validateCompile(
        {
          componentName,
          type
        },
        options
      );
    });

  }



};
