import path from 'path';
import { URL, fileURLToPath } from 'url';
import fs from 'fs';
import { promisify } from 'util';
import { join } from 'path';

import inquirer from 'inquirer';
import ncp from 'ncp';
import chalk from 'chalk';

import { checkPathAccess, showVersion, getComponentsObj, getDirectoryFiles, getFramework } from '../../util.js';
import { CATEGORY_CONSTELLATION, 
  CATEGORY_CUSTOM,
  SDK_CONFIG_JSON_FILENAME,
  DXCB_CONFIG, 
  DXCB_COMPONENT_DEFAULTS } from '../../constants.js';

  import { renameComponentInMap  } from '../map/map.js';


export const DXCB_CONFIG_INTERNAL_JSON_FILENAME = 'src/dxcb.config.json';

const pegaConfigJsonPath = path.join(path.resolve(), SDK_CONFIG_JSON_FILENAME);


import {
  convertIntoPascalCase,
  convertIntoKebabCase,
  getComponentDirectoryPath,
  getPegaConfig,
  getComponentDefaults,
  sanitize,
  validateSemver
} from '../../util.js';
import { COMPONENT_SCHEMA } from '../../constants.js';

const copy = promisify(ncp);


export const updateConfig = async (
  {
    oldComponentKey,
    newComponentKey,
    library,
    organization,
    componentName,
    componentLabel,
    version,
    description,
    allowedApplications,
    targetDirectory,
  },
  options,
  onlyCompanion = false
) => {
  
  let configData = fs.readFileSync(join(targetDirectory, "/config.json"), { encoding: 'utf8' });
  configData = configData && JSON.parse(configData);

  configData.name = newComponentKey;
  configData.label = componentLabel;
  configData.organization = organization;
  if (configData.componentKey) configData.componentKey = newComponentKey;
  configData.library = library;
  configData.version = version;
  configData.description = (description != '') ? description : componentLabel;

  if (allowedApplications.trim() === '') {
    allowedApplications = [];
  } else {
    if (allowedApplications.indexOf(',') !== -1) {
      allowedApplications = allowedApplications.split(',');
    }
    allowedApplications = [].concat(allowedApplications);
  }

  allowedApplications = allowedApplications.filter(el => !!el.trim()).map(el => el.trim());

  configData.allowedApplications = allowedApplications;

  // stringify "4", makes the json string look like JSON in the file, formated instead of a single line
  fs.writeFileSync(join(targetDirectory, "/config.json"), JSON.stringify(configData, null, 4), { encoding: 'utf8' });

};

export const updateFile = async (
    fileName,
    oldComponentKeyPC,
    newComponentKeyPC,
    targetDirectory,
    framework
) => {

  let fileData = fs.readFileSync(join(targetDirectory, "/", fileName), { encoding: 'utf8' });

  if (fileData.indexOf(oldComponentKeyPC) >= 0) {
    fileData = fileData.replaceAll(oldComponentKeyPC, newComponentKeyPC);
    fileData = fileData.replaceAll(convertIntoKebabCase(oldComponentKeyPC), convertIntoKebabCase(newComponentKeyPC));
    
    fs.writeFileSync(join(targetDirectory, "/", fileName), fileData, { encoding: 'utf8' });

    switch (framework) {
      case "SDK-Angular":
        if (fileName.indexOf(".component") >=0 ) {
          const newFileName = fileName.replaceAll(convertIntoKebabCase(oldComponentKeyPC), convertIntoKebabCase(newComponentKeyPC));

          fs.renameSync(join(targetDirectory, "/", fileName), join(targetDirectory, "/", newFileName));
        }
        break;
      case "SDK-React":
        break;
      case "SDK-WebComponents":
        break;
    }
    
  }
  
};


export const renameComponent = async (
  {
    library,
    organization,
    componentKey,
    componentName,
    componentLabel,
    version,
    description,
    allowedApplications
  },
  options,
  onlyCompanion = false
) => {


  let pegaConfig = await getPegaConfig();
 
  let originalComponentKey = componentKey;
  let associatedComponentKey = componentKey;

  const framework = await getFramework();

  let newComponentKey = `${organization}_${library}_${componentName}`;
  let newCustomComponentKey = newComponentKey;
  let newComponentKeyAssociated = newComponentKey;

  switch (framework) {
    case "SDK-Angular":
      // componentKey is in Pascal case, which is associated, need to convert to Kabab case
      let arComp = componentKey.split("/");
      arComp[1] = convertIntoKebabCase(convertIntoPascalCase(arComp[1]));
      componentKey = arComp.join("/");

      newCustomComponentKey = convertIntoKebabCase(convertIntoPascalCase(newCustomComponentKey));
      break;
    case "SDK-React":
      break;
    case "SDK-WebComponents":
      break;
  }


  const typeLC = originalComponentKey.split("/")[0];
  const oldComponentKey = originalComponentKey.split("/")[1];
  const newComponentKeyPC = convertIntoPascalCase(newComponentKey);
  const oldComponentKeyPC = convertIntoPascalCase(oldComponentKey);

  const currentDirectory = await getComponentDirectoryPath(componentKey);
  const currentDirectoryConstellation = await getComponentDirectoryPath(associatedComponentKey, CATEGORY_CONSTELLATION);

  const targetDirectory = await getComponentDirectoryPath(join(typeLC, "/",newCustomComponentKey));
  const targetDirectoryConstellation = await getComponentDirectoryPath(join(typeLC, "/",newComponentKeyAssociated), CATEGORY_CONSTELLATION);

  

  // custom component
  try {
    fs.renameSync(currentDirectory, targetDirectory);
  } catch(err) {
    console.log(err)
  }

  const targetFileList = await getDirectoryFiles(targetDirectory);

  for (var fileIndex in targetFileList) {
    const fileName = targetFileList[fileIndex];

    if (fileName === "config.json") {
      await updateConfig(
        { 
          oldComponentKey,
          newComponentKey,
          componentName,
          componentLabel,
          library,
          version,
          description,
          allowedApplications,
          organization,
          targetDirectory,
        },
        options
      );
    }
    else {
      await updateFile(
          fileName, 
          oldComponentKeyPC, 
          newComponentKeyPC, 
          targetDirectory, 
          framework );

    }

  } // for

  // associated component
  try {
    fs.renameSync(currentDirectoryConstellation, targetDirectoryConstellation);
  } catch(err) {
    console.log(err)
  }

  const targetConstellationFileList = await getDirectoryFiles(targetDirectoryConstellation);

  for (var fileIndex in targetConstellationFileList) {
    const fileName = targetConstellationFileList[fileIndex];

    await updateFile(
        fileName, 
        oldComponentKeyPC, 
        newComponentKeyPC, 
        targetDirectoryConstellation 
    );

  } // for

  // update map
  renameComponentInMap(oldComponentKey, newComponentKey);

  console.log(chalk.green(`Component ${oldComponentKey} renamed to ${newComponentKey}`));

};





export default async options => {
  showVersion();

  await checkPathAccess(pegaConfigJsonPath);

  let data = fs.readFileSync(pegaConfigJsonPath, { encoding: 'utf8' });
  data = data && JSON.parse(data);

  if (!data[DXCB_CONFIG] || !data[DXCB_CONFIG][DXCB_COMPONENT_DEFAULTS]) {
    console.error(
      `${chalk.red.bold('ERROR')} Could not able find component defaults in config.json`
    );
    process.exit(1);
  }

  const componentData = data[DXCB_CONFIG][DXCB_COMPONENT_DEFAULTS];

  const { organization, library} = componentData;

  let componentDefaults = await getComponentDefaults();
  componentDefaults.library = library;

  // since custom has differnet naming convention for Angular, will get "constellation", which has the same name
  // regardless of framework
  const localComponents = await getComponentsObj(true);

  if (options.params.length >= 11) {
    const componentKey = options.params[3];
    const componentName = options.params[4];
    const componentLabel = options.params[5];
    const organization = options.params[6];
    const version = options.params[7];
    const library = options.params[8];
    const allowedApplications = options.params[9];
    const description = options.params[10];

    await renameComponent(
      {
        componentKey,
        componentName,
        componentLabel,
        library,
        version,
        description,
        allowedApplications,
        organization
      },
      options
    );

  }
  else {
    const questions = [
      {
        name: 'componentKey',
        type: 'rawlist',
        pageSize: 15,
        message: 'Select component to rename',
        choices: localComponents
      },
      {
        name: 'componentName',
        message: 'Enter new component name (required, no spaces)',
        validate: value => {
          /* value should not be empty
          It should not have spaces
          It should not start with a number
          Only case-insensitive alphanumeric values are allowed
        */
          if (value && !/^\d/.test(value) && value === sanitize(value)) {
            return true;
          }
          return 'Only alphanumeric values are allowed, starting with alphabets';
        }
      },
      {
        name: 'componentLabel',
        message: 'Enter new component label for display (required)',
        validate: value => {
          if (value) {
            return true;
          }
          return 'Please provide value for label';
        }
      },
      {
        name: 'organization',
        message: 'Enter new component organization',
        default: componentDefaults.organization,
        validate: value => {
          if (value) {
            return true;
          }
          return 'Please provide value for organization';
        }
      },
      {
        name: 'version',
        message: 'Enter new component version',
        default: componentDefaults.version,
        validate: value => {
          if (validateSemver(value)) {
            return true;
          }
          return 'Please provide semver compatible version e.g 0.0.1';
        }
      },
      {
        name: 'library',
        message: 'Enter new library name (required)',
        default: componentDefaults.library,
        validate: value => {
          /* value should not be empty
            It should not have spaces
            It should not start with a number
            Only case-insensitive alphanumeric values are allowed
          */
          if (value && !/^\d/.test(value) && value === sanitize(value)) {
            return true;
          }
          return 'Only alphanumeric values are allowed, starting with alphabets';
        }
      },
      {
        name: 'allowedApplications',
        message: 'Please enter the application names to be supported (comma-separated). ',
        suffix: 'Keep empty for all applications'
      },
      {
        name: 'description',
        message: 'Enter new description for the component (defaults to new label)',
        default: componentDefaults.description,
        /* if left blank and no defaults, mustache will use componentLabel, because description is used in app studio and
        shouldn't be blank */
      }
    ];
  
    await inquirer.prompt(questions).then(async answers => {
      const {
        componentKey,
        componentName,
        componentLabel,
        organization,
        library,
        version,
        description,
        allowedApplications
      } = answers;
  
      await renameComponent(
        { 
          componentKey,
          componentName,
          componentLabel,
          library,
          version,
          description,
          allowedApplications,
          organization
        },
        options
      );
      
    });
  }

  
  
};
