export { default } from './OneColumnPage';
