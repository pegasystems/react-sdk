import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../../types/PConnProps';
interface WideNarrowPageProps extends PConnProps {
    title: string;
    templateCol?: string;
    icon?: string;
}
export default function WideNarrowPage(props: PropsWithChildren<WideNarrowPageProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=WideNarrowPage.d.ts.map