import { PConnProps } from '../../../types/PConnProps';
interface QuickCreateProps extends PConnProps {
    heading: string;
    showCaseIcons: boolean;
    classFilter: any[];
}
export default function QuickCreate(props: QuickCreateProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=QuickCreate.d.ts.map