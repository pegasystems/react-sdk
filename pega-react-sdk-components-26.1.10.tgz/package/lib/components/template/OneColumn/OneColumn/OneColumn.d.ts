import type { PropsWithChildren } from 'react';
import type { PConnProps } from '../../../../types/PConnProps';
interface OneColumnProps extends PConnProps {
}
export default function OneColumn(props: PropsWithChildren<OneColumnProps>): import("react").JSX.Element;
export {};
//# sourceMappingURL=OneColumn.d.ts.map