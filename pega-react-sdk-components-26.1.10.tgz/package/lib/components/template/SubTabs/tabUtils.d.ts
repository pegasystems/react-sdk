export declare const getDeferFriendlyTabs: (allTabs: any) => any;
export declare const getVisibleTabs: (allTabs: any, uuid: any) => any;
export declare const getTransientTabs: (availableTabs: any, currentTabId: any, tabItems: any) => any;
export declare const tabClick: (id: any, availableTabs: any, currentTabId: any, setCurrentTabId: any, tabItems: any) => void;
export declare const searchtabsClick: (id: any, mainTabs: any, currentTabId: any, setCurrentTabId: any) => void;
export declare const getTabLabel: (tabPConnect: any) => any;
export declare const getActiveTabId: (mainTabs: any, currentTabId: any) => any;
/**
 *
 * @param {*} deferLoadedTabs list of deferLoadedTabs
 * @param {string} tabViewName (optional) if provided, tabId of the given tabView will be returned
 * @returns {string} a tab id is returned
 */
export declare const getFirstVisibleTabId: (deferLoadedTabs: any, tabViewName: any) => string | null;
//# sourceMappingURL=tabUtils.d.ts.map