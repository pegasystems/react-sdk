import React from 'react';
interface DetailsFieldsProps {
    fields: any[];
}
export default function DetailsFields(props: DetailsFieldsProps): React.JSX.Element;
export {};
//# sourceMappingURL=DetailsFields.d.ts.map