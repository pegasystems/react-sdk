import React from 'react';
import type { PConnFieldProps } from '../../../types/PConnProps';
import './CancelAlert.css';
interface CancelAlertProps extends PConnFieldProps {
    heading: string;
    content: string;
    itemKey: string;
    hideDelete: boolean;
    isDataObject: boolean;
    skipReleaseLockRequest: any;
    dismiss: Function;
}
export default function CancelAlert(props: CancelAlertProps): React.JSX.Element;
export {};
//# sourceMappingURL=CancelAlert.d.ts.map