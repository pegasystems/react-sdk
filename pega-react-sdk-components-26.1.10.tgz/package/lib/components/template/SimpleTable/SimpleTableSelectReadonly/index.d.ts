export { default } from './SimpleTableSelectReadonly';
//# sourceMappingURL=index.d.ts.map