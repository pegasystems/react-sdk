import { PConnProps } from '../../../../types/PConnProps';
interface DetailsThreeColumnProps extends PConnProps {
    showLabel: boolean;
    label: string;
    showHighlightedData: boolean;
}
export default function DetailsThreeColumn(props: DetailsThreeColumnProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=DetailsThreeColumn.d.ts.map