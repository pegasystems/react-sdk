interface GenAIMessageProgressProps {
    messages?: string[];
    completedSteps?: number;
}
export default function GenAIMessageProgress(props: GenAIMessageProgressProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=GenAIMessageProgress.d.ts.map