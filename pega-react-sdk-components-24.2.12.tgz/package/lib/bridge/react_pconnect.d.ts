export function setVisibilityForList(c11nEnv: any, visibility: any): void;
export default createPConnectComponent;
/**
 *
 * @param {*} declarative
 * @returns {React.Components<Props, State>}

 */
declare function createPConnectComponent(): React.Components<Props, State>;
//# sourceMappingURL=react_pconnect.d.ts.map