import { PConnFieldProps } from '../../../types/PConnProps';
interface PercentageProps extends PConnFieldProps {
    currencyISOCode?: string;
    showGroupSeparators?: string;
    decimalPrecision?: number;
}
export default function Percentage(props: PercentageProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Percentage.d.ts.map