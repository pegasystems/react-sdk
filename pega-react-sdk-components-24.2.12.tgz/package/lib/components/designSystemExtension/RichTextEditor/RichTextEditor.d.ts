import React from 'react';
interface RichTextEditorProps {
    id?: string;
    defaultValue: string;
    label: string;
    labelHidden: boolean;
    info: string;
    testId: string;
    placeholder: string;
    disabled: boolean;
    required: boolean;
    readOnly: boolean;
    error: boolean;
    onBlur: React.EventHandler<any>;
    onChange: React.EventHandler<any>;
}
declare const RichTextEditor: React.ForwardRefExoticComponent<RichTextEditorProps & React.RefAttributes<unknown>>;
export default RichTextEditor;
//# sourceMappingURL=RichTextEditor.d.ts.map