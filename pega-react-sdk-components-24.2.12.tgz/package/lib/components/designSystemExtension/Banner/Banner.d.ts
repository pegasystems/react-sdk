import './Banner.css';
interface BannerProps {
    a: any;
    b: any;
    banner: {
        variant: any;
        backgroundColor: any;
        title: any;
        message: any;
        backgroundImage: any;
        tintImage: any;
    };
    variant: any;
}
export default function Banner(props: BannerProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Banner.d.ts.map