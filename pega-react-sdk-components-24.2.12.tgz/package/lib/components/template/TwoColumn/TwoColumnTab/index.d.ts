export { default } from './TwoColumnTab';
//# sourceMappingURL=index.d.ts.map