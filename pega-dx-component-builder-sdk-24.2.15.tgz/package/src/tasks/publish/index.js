import inquirer from 'inquirer';
import { Listr } from 'listr2';
import chalk from 'chalk';

import validate from '../validator/index.js';
import { getComponentDirectoryPath, showVersion, getOptionsCategory, getFramework, getLocalComponentKeyFromConfig, convertIntoKebabCase, convertIntoPascalCase } from '../../util.js';
import { bundleReactComponent, bundleAngularComponent, bundleAssociatedComponent} from '../bundle/index.js';
import { updateComponentMap  } from '../map/map.js';
import { lintComponent } from '../linter/index.js';
import { CATEGORY_CONSTELLATION, CATEGORY_CUSTOM } from '../../constants.js';


import { getPublishComponentQuestions,
  publishComponentToServer,
  zipComponent,
  getBuildCategory,
  mapConfigJsonToCompanion,
  removeCompanionConfigJson} from './helper.js';


export default async options => {
  showVersion();

  const framework = await getFramework();

  let componentKey;
  let sourceMap;
  let devBuild;
  let content;
  let category;

  let doFetch = true;

  if (options.params.length >= 8) {
    category = options.params[3];
    componentKey = options.params[4];
    const rulesetName = options.params[5];
    const rulesetVersion = options.params[6];
    const dBuild = options.params[7];
    devBuild = dBuild === 'Y' || dBuild === 'y' || dBuild === true || dBuild === 'true';

    // eslint-disable-next-line no-unneeded-ternary,no-nested-ternary
    doFetch = options.params.length >= 9 ? (options.params[8] === 'noFetch' ? false : true) : true;

    content = { componentKey, rulesetName, rulesetVersion, devBuild };
  } else {
    const catQuestion = await getBuildCategory(options);
    const catAnswers = await inquirer.prompt(catQuestion);

    category = catAnswers.category;
    if (category == null) {
      category = getOptionsCategory(options);
    }

    const questions = await getPublishComponentQuestions(category);
    const answers = await inquirer.prompt(questions);
    ({ componentKey, sourceMap, devBuild } = answers);

    content = {
      ...answers
    };
  }


  const sDevBuild = devBuild ? '(dev build)' : '';
  const sFramework = framework.split("-")[1];

  let associatedComponentKey = componentKey;

  switch (framework) {
    case "SDK-Angular":
      // componentKey is in Pascal case, which is associated, need to convert to Kabab case
      let arComp = componentKey.split("/");
      arComp[1] = convertIntoKebabCase(convertIntoPascalCase(arComp[1]));
      componentKey = arComp.join("/");
      break;
    case "SDK-React":
      break;
    case "SDK-WebComponents":
      break;
  }

  const customTasks = new Listr(
    [

      {
        title: 'Validate config schema',
        task: async () => {
          await validate(componentKey, category);
        }
      },
      {
        title: `Lint ${sFramework} component`,
        task: async () => {
          const targetDirectory = await getComponentDirectoryPath(componentKey, category);
          // console.log(`in buildComponent Lint component task: componentKey: ${componentKey} targetDirectory: ${targetDirectory}`);
          await lintComponent(targetDirectory);
        }
      },
      {
        title: `Bundle React component ${sDevBuild}`,
        task: async () => await bundleReactComponent(componentKey, sourceMap, devBuild, category),
        skip: () => (options.skipBundle ? 'Skipped bundling component' : undefined),
        enabled: ok => framework === "SDK-React"
      },
      {
        title: `Bundle Angular component ${sDevBuild}`,
        task: async () => await bundleAngularComponent(componentKey, sourceMap, devBuild, category),
        skip: () => (options.skipBundle ? 'Skipped bundling component' : undefined),
        enabled: ok => framework === "SDK-Angular"
      },
      {
        title: 'Update component map',
        task: async () => {
            await updateComponentMap(componentKey);
        }
      },
      {
        title: 'Lint associated component',
        task: async () => {
          const targetDirectory = await getComponentDirectoryPath(associatedComponentKey, CATEGORY_CONSTELLATION);
          // console.log(`in buildComponent Lint component task: componentKey: ${componentKey} targetDirectory: ${targetDirectory}`);
          await lintComponent(targetDirectory);
        }
      },
      {
        title: 'Map config to associated component',
        task: async () => {
          mapConfigJsonToCompanion(componentKey);
        }
      },
      {
        title: `Bundle associated component ${sDevBuild}`,
        task: async () => await bundleAssociatedComponent(associatedComponentKey, sourceMap, devBuild, CATEGORY_CONSTELLATION),
        skip: () => (options.skipBundle ? 'Skipped bundling component' : undefined)
      },
      {
        title: 'Zip associated component',
        task: async () => {
          const output = await zipComponent(associatedComponentKey, CATEGORY_CONSTELLATION);
          content = { ...content, ...output };
        }
      },
      {
        title: 'Publish associated component',
        task: async () => {
          await publishComponentToServer(content, doFetch);
        }
      },
      {
        title: 'Clean up associated',
        task: async () => {
          await removeCompanionConfigJson(associatedComponentKey);
        }
      }
    ],
    {
      exitOnError: true
    }
  );

  const overrideTasks = new Listr(
    [
      {
        title: 'Validate config schema',
        task: async () => {
          await validate(componentKey, category);
        }
      },
      {
        title: `Lint ${sFramework} component`,
        task: async () => {
          const targetDirectory = await getComponentDirectoryPath(componentKey, category);
          // console.log(`in buildComponent Lint component task: componentKey: ${componentKey} targetDirectory: ${targetDirectory}`);
          await lintComponent(targetDirectory);
        }
      },
      {
        title: `Bundle React component ${sDevBuild}`,
        task: async () => await bundleReactComponent(componentKey, sourceMap, devBuild, category),
        enabled: ok => framework === "SDK-React"
      },
      {
        title: `Bundle Angular component ${sDevBuild}`,
        task: async () => await bundleAngularComponent(componentKey, sourceMap, devBuild, category),
        enabled: ok => framework === "SDK-Angular"
      },
      {
        title: 'Update component map',
        task: async () => {
            await updateComponentMap(componentKey, category);
        }
      },
      {
        title: 'Zip component config',
        task: async () => {
          const output = await zipComponent(associatedComponentKey, category);
          content = { ...content, ...output };
        }
      },
      {
        title: 'Publish component config',
        task: async () => {
          await publishComponentToServer(content, doFetch);
        }
      }

    ],
    {
      exitOnError: true
    }
  );

  if (category === CATEGORY_CUSTOM) {
    await customTasks.run().catch(err => {
      console.log(chalk.bold.red(err.toString()));
    });
  }
  else {
    await overrideTasks.run().catch(err => {
      console.log(chalk.bold.red(err.toString()));
    });

  }

  return true;
};
