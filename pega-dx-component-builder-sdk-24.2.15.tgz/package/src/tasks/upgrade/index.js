import { promisify } from 'util';
import { exec } from 'child_process';

import { Listr } from 'listr2';

const execPromise = promisify(exec);

export default async options => {
  const installDependenciesText = `Upgrading package to latest version.`;

  const tasks = new Listr(
    [
      {
        title: installDependenciesText,
        task: async () => {
          await execPromise('npm uninstall --save-dev @pega/dx-component-builder-sdk', {
            cwd: options.targetDirectory
          });
          await execPromise('npm install --save-dev @pega/dx-component-builder-sdk', {
            cwd: options.targetDirectory
          });
        }
      }
    ],
    {
      exitOnError: false
    }
  );

  await tasks.run();
};
