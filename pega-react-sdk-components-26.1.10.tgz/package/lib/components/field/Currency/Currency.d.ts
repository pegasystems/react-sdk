import type { PConnFieldProps } from '../../../types/PConnProps';
interface CurrrencyProps extends PConnFieldProps {
    currencyISOCode?: string;
    allowDecimals: boolean;
    showFieldMessage?: boolean;
    messageConfig?: {
        content?: string;
        visibility?: boolean;
    };
    variant?: string;
}
export default function Currency(props: CurrrencyProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=Currency.d.ts.map