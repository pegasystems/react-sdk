import React, { type PropsWithChildren } from 'react';
import type { PConnProps } from '../../../types/PConnProps';
interface DataReferenceProps extends PConnProps {
    label: string;
    showLabel: any;
    displayMode: string;
    allowAndPersistChangesInReviewMode: boolean;
    referenceType: string;
    selectionMode: string;
    displayAs: string;
    ruleClass: string;
    parameters: string[];
    hideLabel: boolean;
    imagePosition: string;
    showImageDescription: string;
    showPromotedFilters: boolean;
    isCreationOfNewRecordAllowedForReference: boolean;
    contextClass: string;
    inline: any;
    selectionList: any;
}
export default function DataReference(props: PropsWithChildren<DataReferenceProps>): React.JSX.Element;
export {};
//# sourceMappingURL=DataReference.d.ts.map