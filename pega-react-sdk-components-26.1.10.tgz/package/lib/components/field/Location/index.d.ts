export { default } from './Location';
//# sourceMappingURL=index.d.ts.map