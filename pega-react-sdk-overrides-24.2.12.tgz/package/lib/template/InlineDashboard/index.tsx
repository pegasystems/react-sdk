export { default } from './InlineDashboard';
