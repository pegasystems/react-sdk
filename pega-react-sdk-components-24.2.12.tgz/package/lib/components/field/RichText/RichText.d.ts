import { PConnFieldProps } from '../../../types/PConnProps';
interface RichTextProps extends PConnFieldProps {
    additionalProps?: object;
}
export default function RichText(props: RichTextProps): any;
export {};
//# sourceMappingURL=RichText.d.ts.map