import type { PConnProps } from '../../../types/PConnProps';
interface TextContentProps extends PConnProps {
    content: string;
    displayAs: 'Paragraph' | 'Heading 1' | 'Heading 2' | 'Heading 3' | 'Heading 4';
}
export default function TextContent(props: TextContentProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=TextContent.d.ts.map