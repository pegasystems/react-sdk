import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../types/PConnProps';
interface RootContainerProps extends PConnProps {
    renderingMode?: string;
    routingInfo: {
        type: string;
        accessedOrder: any[];
        items: any;
    };
    skeleton: any;
    httpMessages: any[];
}
export default function RootContainer(props: PropsWithChildren<RootContainerProps>): any;
export {};
//# sourceMappingURL=RootContainer.d.ts.map