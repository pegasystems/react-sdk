export { default } from './DetailsTwoColumn';
