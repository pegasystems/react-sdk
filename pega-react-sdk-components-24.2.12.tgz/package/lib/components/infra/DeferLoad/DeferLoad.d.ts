import { PConnProps } from '../../../types/PConnProps';
interface DeferLoadProps extends PConnProps {
    name: string;
    isChildDeferLoad?: boolean;
    isTab: boolean;
    deferLoadId: string;
    lastUpdateCaseTime: any;
}
export default function DeferLoad(props: DeferLoadProps): any;
export {};
//# sourceMappingURL=DeferLoad.d.ts.map