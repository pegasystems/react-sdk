import arg from 'arg';
import chalk from 'chalk';

import {
  authenticate,
  buildComponent,
  buildAllComponents,
  buildJestAssets,
  clearMap,
  createComponent,
  createAllComponents,
  deleteComponent,
  deleteAllComponents,
  scanAndFix,
  listComponents,
  mapAllComponents,
  overrideComponent,
  overrideAllComponents,
  publishComponent,
  publishAllComponents,
  renameComponent,
  quarantine,
  updateComponent,
  validate,
  upgrade
} from './tasks/index.js';

const TASKS = {
  CLEAR_MAP: 'clearMap',
  CREATE: 'create',
  CREATE_ALL: 'createAll',
  OVERRIDE: 'override',
  OVERRIDE_ALL: 'overrideAll',
  BUILD: 'buildComponent',
  BUILD_ALL: 'buildAllComponents',
  BUILD_JEST_ASSETS: 'buildJestAssets',
  MAP_ALL: "mapAll",
  PUBLISH: 'publish',
  PUBLISH_ALL: 'publishAll',
  RENAME: 'rename',
  QUARANTINE: 'quarantine',
  LIST: 'list',
  VALIDATE_SCHEMA: 'validateSchema',
  UPDATE: 'update',
  DELETE: 'delete',
  DELETE_ALL: 'deleteAll',
  AUTHENTICATE: 'authenticate',
  UPGRADE: 'upgrade',
  SCAN_AND_FIX: 'scanAndFix'
};

const parseArgumentsIntoOptions = rawArgs => {
  const args = arg(
    {
      '--install': Boolean,
      '--skipBundle': Boolean
    },
    {
      argv: rawArgs.slice(2)
    }
  );
  return {
    task: args._[0],
    git: true, // args['--git'] || false
    runInstall: true, // args['--install'] || false
    skipBundle: args['--skipBundle'] || false,
    params: rawArgs
  };
};

export default async (args = []) => {
  const options = parseArgumentsIntoOptions(args);
  const { task } = options;
  switch (task) {
    case TASKS.CLEAR_MAP: {
      clearMap(options);
      break;
    }
    case TASKS.CREATE: {
      createComponent(options);
      break;
    }
    case TASKS.CREATE_ALL: {
      createAllComponents(options);
      break;
    }
    case TASKS.OVERRIDE: {
      overrideComponent(options);
      break;
    }
    case TASKS.OVERRIDE_ALL: {
      overrideAllComponents(options);
      break;
    }
    case TASKS.MAP_ALL: {
      mapAllComponents(options);
      break;
    }
    case TASKS.PUBLISH: {
      publishComponent(options);
      break;
    }
    case TASKS.PUBLISH_ALL: {
      publishAllComponents(options);
      break;
    }
    case TASKS.RENAME: {
      renameComponent(options);
      break;
    }
    case TASKS.QUARANTINE: {
      quarantine(options);
      break;
    }
    case TASKS.BUILD: {
      buildComponent(options);
      break;
    }
    case TASKS.BUILD_ALL: {
      buildAllComponents(options);
      break;
    }
    case TASKS.LIST: {
      listComponents(options);
      break;
    }
    case TASKS.VALIDATE_SCHEMA: {
      validate(options);
      break;
    }
    case TASKS.UPDATE: {
      updateComponent(options);
      break;
    }
    case TASKS.DELETE: {
      deleteComponent(options);
      break;
    }
    case TASKS.DELETE_ALL: {
      deleteAllComponents(options);
      break;
    }
    case TASKS.AUTHENTICATE: {
      authenticate(options);
      break;
    }
    case TASKS.UPGRADE: {
      upgrade(options);
      break;
    }
    case TASKS.SCAN_AND_FIX: {
      scanAndFix(options);
      break;
    }
    case TASKS.BUILD_JEST_ASSETS: {
      buildJestAssets(options);
      break;
    }
    default: {
      console.log(chalk.red(`No task matched with ${task}`));
      break;
    }
  }
};
