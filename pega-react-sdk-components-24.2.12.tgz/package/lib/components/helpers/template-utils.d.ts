export declare function getAllFields(pConnect: any): any[];
export declare function filterForFieldValueList(fields: any[]): {
    id: any;
    name: any;
    value: any;
}[];
/**
 * Determine if the current view is the view of the case step/assignment.
 * @param {Function} pConnect PConnect object for the component
 */
export declare function getIsAssignmentView(pConnect: any): boolean;
/**
 * A hook that gets the instructions content for a view.
 * @param {Function} pConnect PConnect object for the component
 * @param {string} [instructions="casestep"] 'casestep', 'none', or the html content of a Rule-UI-Paragraph rule (processed via core's paragraph annotation handler)
 */
export declare function getInstructions(pConnect: any, instructions?: string): string | undefined;
//# sourceMappingURL=template-utils.d.ts.map