interface FieldValueListProps {
    name?: string;
    value: any;
    variant?: string;
    isHtml?: boolean;
}
export default function FieldValueList(props: FieldValueListProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=FieldValueList.d.ts.map