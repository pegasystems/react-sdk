import { type ComponentType } from 'react';
import type { Tokens } from 'marked';
import type { CaseDetails } from '../designSystemExtension/GenAICoachContent/GenAICoach.types';
import { type CoachPConnectGetter } from './agent-inline-edit-utils';
/** Returns the cases created or opened in the conversation. */
export type ConversationCasesGetter = () => CaseDetails[];
/** Markdown overrides for GenAI coach */
export declare const createAgentMarkdownMap: (options?: {
    getPConnect?: CoachPConnectGetter;
    getConversationCases?: ConversationCasesGetter;
}) => {
    code: () => ({ token }: {
        token: Tokens.Code;
    }) => import("react").JSX.Element;
    link: () => ({ token }: {
        token: Tokens.Link;
    }) => import("react").JSX.Element;
    text: (token: Tokens.Text) => ComponentType<{
        token: Tokens.Text;
    }> | undefined;
};
declare const agentMarkdownMap: {
    code: () => ({ token }: {
        token: Tokens.Code;
    }) => import("react").JSX.Element;
    link: () => ({ token }: {
        token: Tokens.Link;
    }) => import("react").JSX.Element;
    text: (token: Tokens.Text) => ComponentType<{
        token: Tokens.Text;
    }> | undefined;
};
export default agentMarkdownMap;
//# sourceMappingURL=agent-markdown-renderers.d.ts.map