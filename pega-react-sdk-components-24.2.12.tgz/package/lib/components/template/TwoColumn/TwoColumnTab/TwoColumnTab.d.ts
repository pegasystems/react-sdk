import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../../types/PConnProps';
interface TwoColumnTabProps extends PConnProps {
    templateCol?: string;
}
export default function TwoColumnTab(props: PropsWithChildren<TwoColumnTabProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=TwoColumnTab.d.ts.map