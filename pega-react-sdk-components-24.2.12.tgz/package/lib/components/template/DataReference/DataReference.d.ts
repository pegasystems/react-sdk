import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../types/PConnProps';
interface DataReferenceProps extends PConnProps {
    label: string;
    showLabel: any;
    displayMode: string;
    allowAndPersistChangesInReviewMode: boolean;
    referenceType: string;
    selectionMode: string;
    displayAs: string;
    ruleClass: string;
    parameters: string[];
    hideLabel: boolean;
}
export default function DataReference(props: PropsWithChildren<DataReferenceProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=DataReference.d.ts.map