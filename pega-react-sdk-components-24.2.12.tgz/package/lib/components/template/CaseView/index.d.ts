export { default } from './CaseView';
//# sourceMappingURL=index.d.ts.map