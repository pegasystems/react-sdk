import './FileUtility.css';
import { PConnProps } from '../../../../types/PConnProps';
interface FileUtilityProps extends PConnProps {
}
export default function FileUtility(props: FileUtilityProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=FileUtility.d.ts.map