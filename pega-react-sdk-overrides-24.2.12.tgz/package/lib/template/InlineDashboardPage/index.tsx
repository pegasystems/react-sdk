export { default } from './InlineDashboardPage';
