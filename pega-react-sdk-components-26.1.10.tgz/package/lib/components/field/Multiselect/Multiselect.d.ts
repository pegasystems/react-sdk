export default function Multiselect(props: any): import("react").JSX.Element;
//# sourceMappingURL=Multiselect.d.ts.map