export { default } from './WideNarrowDetails';
