import { PConnProps } from '../../../../types/PConnProps';
interface SimpleTableSelectProps extends PConnProps {
    label: string;
    referenceList: object[] | string;
    renderMode: string;
    showLabel: boolean;
    promptedFilters: object[];
    viewName: string;
    parameters: any;
    readonlyContextList: object[] | string;
    dataRelationshipContext: string;
}
/**
 * SimpleTable react component
 * @param {*} props - props
 */
export default function SimpleTableSelect(props: SimpleTableSelectProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=SimpleTableSelect.d.ts.map