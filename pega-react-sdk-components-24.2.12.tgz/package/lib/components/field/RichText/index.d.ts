export { default } from './RichText';
//# sourceMappingURL=index.d.ts.map