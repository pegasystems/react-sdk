import { Ref, RefObject } from 'react';
/**
 * @example const ref = useConsolidatedRefs(refs);
 * @param refs The ref or refs to consolidate.
 * @returns ref:: The consolidated ref.
 */
declare const useConsolidatedRef: <T>(...refs: (Ref<T> | undefined)[]) => RefObject<T>;
export default useConsolidatedRef;
//# sourceMappingURL=useConsolidatedRef.d.ts.map