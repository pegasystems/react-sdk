export default function SelfServiceCaseView(props: any): import("react").JSX.Element;
//# sourceMappingURL=SelfServiceCaseView.d.ts.map