export { default } from './CaseHistory';
//# sourceMappingURL=index.d.ts.map