import React from 'react';
import type { PConnProps } from '../../../types/PConnProps';
interface CaseViewActionsMenuProps extends PConnProps {
    availableActions: any[];
    availableProcesses: any[];
    dataObjectAvailableActions?: any[];
    dataObjectCreateCaseActions?: any[];
    caseTypeID: string;
    caseTypeName: string;
}
export default function CaseViewActionsMenu(props: CaseViewActionsMenuProps): React.JSX.Element;
export {};
//# sourceMappingURL=CaseViewActionsMenu.d.ts.map