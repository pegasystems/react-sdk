export { default } from './View';
//# sourceMappingURL=index.d.ts.map