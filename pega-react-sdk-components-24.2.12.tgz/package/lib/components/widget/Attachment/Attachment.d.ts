import { PConnFieldProps } from '../../../types/PConnProps';
import './Attachment.css';
interface AttachmentProps extends Omit<PConnFieldProps, 'value'> {
    value: any;
    allowMultiple: string;
    extensions: string;
}
export default function Attachment(props: AttachmentProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Attachment.d.ts.map