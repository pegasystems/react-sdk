import chalk from 'chalk';
import inquirer from 'inquirer';
import ora from 'ora';
import { join } from 'path';
//import { element } from 'prop-types';

import { LIST_COMPONENT_SERVICE_REST_ENDPOINT, COMPONENT_SCHEMA, CATEGORY_CONSTELLATION, CATEGORY_CUSTOM, CATEGORY_OVERRIDE } from '../../constants.js';
import {
  deleteLocalComponent,
  getLocalComponentConfig,
  getFramework,
  deleteServerComponent,
  getComponentsObj,
  getPegaServerConfig,
  convertIntoKebabCase,
  convertIntoPascalCase
} from '../../util.js';

import { getComponentsFromServer } from '../list/helper.js';

import { deleteFromComponentMap } from '../map/map.js';

export const SOURCE_OF_COMPONENT_TYPES = {
  SERVER: 'Server',
  LOCAL: 'Local'
};

export const visualLCCategory = (category) => {

  switch (category) {
    case CATEGORY_CONSTELLATION :
      return "custom-".concat(category.toLowerCase());
    case CATEGORY_CUSTOM :
    case CATEGORY_OVERRIDE :
      return category.toLowerCase().concat("-sdk");
  }

  return category.toLowerCase();
}

export const getDeleteComponentsQuestions = async (options, sourceOfComponentsOption) => {
  const defaultPegaServerConfig = await getPegaServerConfig();

  return [
    {
      name: 'sourceOfComponents',
      type: 'rawlist',
      message: 'Delete components from Server or Local ?',
      choices: Object.values(SOURCE_OF_COMPONENT_TYPES),
      default: defaultPegaServerConfig.sourceOfComponents,

    },
    {
      name: 'category',
      type: 'rawlist',
      message: 'Category of components ?',
      choices: COMPONENT_SCHEMA.category,
      when(answers) {
        return answers.sourceOfComponents != "Server"
      }
    }

  ];
};

export const deleteLocalComponents = async (sourceOfComponents, category = CATEGORY_CUSTOM, options) => {
  const localComponents = await getComponentsObj(true, category);
  //const localComponentsAndSub = await getComponentsAndSubDirectory();

  let confirmDeletion;
  let componentKey;

  if (localComponents.length > 0) {
    if (options.params.length >= 7) {
      componentKey = options.params[5];
      const sDeletion = options.params[6];
      confirmDeletion = sDeletion === 'Y' || sDeletion === 'y' || sDeletion === true || sDeletion === 'true';

    } else {
      const answers = await inquirer.prompt([
        {
          name: 'componentKey',
          type: 'rawlist',
          pageSize: 15,
          message: 'Select component to delete',
          choices: localComponents
        },
        {
          name: 'confirmDeletion',
          type: 'confirm',
          message: 'Are you sure ?',
          default: false
        }
      ]);
      ({componentKey, confirmDeletion} = answers);;

    }

    if (confirmDeletion) {

      const framework = await getFramework();
      let customComponentKey = componentKey;

      switch (framework) {
        case "SDK-Angular":
          // because of naming Pascal case vs Kebab case, given Pascal - use for associated
          // Kebab case customComponentKey

          let arComp = componentKey.split("/");
          arComp[1] = convertIntoKebabCase(convertIntoPascalCase(arComp[1]));
          customComponentKey = arComp.join("/");

          await deleteLocalComponent(customComponentKey, category);
          if (category  === CATEGORY_CUSTOM) {
            await deleteLocalComponent(componentKey, CATEGORY_CONSTELLATION);
          }

          break;
        case "SDK-React":
          await deleteLocalComponent(componentKey, category);
          if (category  === CATEGORY_CUSTOM) {
            await deleteLocalComponent(componentKey, CATEGORY_CONSTELLATION);
          }
          break;
        case "SDK-WebComponents":
          await deleteLocalComponent(componentToDelete, category);
          if (category  === CATEGORY_CUSTOM) {
            await deleteLocalComponent(componentToDelete, CATEGORY_CONSTELLATION);
          }
          break;
      }



      if (category === CATEGORY_OVERRIDE || category === CATEGORY_CUSTOM) {
        // need to remove the map as well
        if (customComponentKey != undefined) {

          await deleteFromComponentMap(customComponentKey, category);
        }
        else {
          console.log(chalk.bold.yellow(`No component in map: ` + componentName));
        }

      }
    }
  } else {
    const categoryLC = visualLCCategory(category);
    console.log(chalk.bold.redBright(`No ${categoryLC} components in ${sourceOfComponents}`));
  }
};

export const deleteServerComponents = async (sourceOfComponents, answers) => {
  let spinner;
  let data;
  try {
    spinner = ora('Fetching components from server').start();
    data = await getComponentsFromServer(answers);
    spinner.stop();
  }
  catch (error) {
    spinner.stop();
    if (error.indexOf("ECONNREFUSED") >= 0) {
      console.log(`\n${chalk.bold.red('Error occurred in authentication. Please regenerate using authenticate')}`);
    }
    else {
      console.log(`${chalk.bold.red(error)}`);
    }

    // spinner.stop();
    process.exit(1);
  }

  const componentObj = await getComponentsObj(false);
  const framework = await getFramework();
  const serverComponents = JSON.parse(data);
  spinner.stop();


  if (serverComponents && serverComponents.pxResults?.length > 0) {
    const choicesArr = serverComponents.pxResults.map(({ label, pyRuleSet, pyRuleSetVersion }) => {
      const name = `${standardizeStr(label, 45)} ${standardizeStr(pyRuleSet, 30)} ${standardizeStr(
        pyRuleSetVersion,
        20
      )}`;

      const value = `${label}~|~${pyRuleSet}~|~${pyRuleSetVersion}`;
      const short = `Selected component : ${chalk.redBright(
        `${label} ${pyRuleSet} : ${pyRuleSetVersion}`
      )}`;

      return { name, value, short };
    });
    const answers = await inquirer.prompt({
      name: 'componentToDelete',
      type: 'rawlist',
      pageSize: 15,
      message: `Select component to delete \n  ${standardizeStr('Rule name', 48)} ${standardizeStr(
        'Ruleset name',
        30
      )} ${standardizeStr('Ruleset version', 22)}`,
      choices: choicesArr
    });

    await deleteServerComponent(answers.componentToDelete);

    const componentName = answers.componentToDelete.split("~")[0];
    let componentKey;

    switch (framework) {
      case "SDK-Angular":
        const tempComponentName = convertIntoKebabCase(convertIntoPascalCase(componentName));
        componentKey = componentObj.find( theObj => theObj.name === tempComponentName);
        break;
      case "SDK-React":
        componentKey = componentObj.find( theObj => theObj.name === componentName);
        break;
      case "SDK-WebComponents":
        break;
    }

    // check to see if component is an override component
    if (componentKey === undefined) {
      const overrideObj = await getComponentsObj(false, CATEGORY_OVERRIDE);
      if (overrideObj) {
        const overrideKey = overrideObj.find( theObj => theObj.name === componentName);
        if (overrideKey != undefined) {
          // override component, don't remove from map, just end
          return;
        }
      }
    }

    if (componentKey != undefined) {
      await deleteFromComponentMap(componentKey.value);
    }
    else {
      console.log(chalk.bold.yellow(`No component in map: ` + componentName));
    }

  } else {
    console.log(chalk.bold.redBright(`No custom components in ${sourceOfComponents}`));
  }
};

export const standardizeStr = (str, leng) => {
  for (let i = str.length; i <= leng; i++) {
    str += ' ';
  }
  return str;
};
