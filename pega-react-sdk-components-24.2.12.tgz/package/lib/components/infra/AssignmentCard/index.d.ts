export { default } from './AssignmentCard';
//# sourceMappingURL=index.d.ts.map