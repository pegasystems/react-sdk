import { PConnProps } from '../../../types/PConnProps';
import './NavBar.css';
interface NavBarProps extends PConnProps {
    appName?: string;
    pages?: any[];
    caseTypes: any[];
    pConn?: any;
}
export default function NavBar(props: NavBarProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=NavBar.d.ts.map