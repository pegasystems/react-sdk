export { default } from './BannerPage';
//# sourceMappingURL=index.d.ts.map