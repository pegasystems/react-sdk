export { default } from './DetailsFields';
//# sourceMappingURL=index.d.ts.map