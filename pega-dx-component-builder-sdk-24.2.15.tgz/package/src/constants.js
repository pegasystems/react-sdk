// cSpell:ignore words timeofday caseview casepreview objectview
export const SDK_CONFIG_JSON_FILENAME = 'sdk-config.json';
export const BUILD_CONFIG_JSON_FILENAME = 'build.config.json';
export const SDK_LOCAL_COMPONENT_MAP_FILENAME = 'sdk-local-component-map.js';
export const PRETTIER_CONFIG_FILENAME = 'prettierrc.js';
export const DXCB_CONFIG = 'dxcbConfig';
export const DXCB_PUBLISH_ACCESS = 'publishAccess';
export const DXCB_COMPONENT_DEFAULTS = 'componentDefaults';
export const REACT_COMPONENTS_DIRECTORY_PATH = 'src/components';
export const ANGULAR_COMPONENTS_DIRECTORY_PATH = 'src/app/_components';
export const ANGULAR_COMPONENTS_APP_DIRECTORY_PATH = 'app/_components';
export const TOKEN_PATH = '../.access_token';
export const OOTB_COMPONENTS = '../.ootb_components';
export const FIELD_PATH = '/field';
export const TEMPLATE_PATH = '/template';
export const WIDGET_PATH = '/widget';
export const DSE_PATH = '/designSystemExtension';
export const INFRA_PATH = '/infra';
export const COMPONENT_PREFIX_FIELD_PATH = 'field/';
export const COMPONENT_PREFIX_TEMPLATE_PATH = 'template/';
export const COMPONENT_PREFIX_WIDGET_PATH = 'widget/';
export const COMPONENT_PREFIX_DSE_PATH = 'designSystemExtension/';
export const COMPONENT_PREFIX_INFRA_PATH = 'infra/';

export const CUSTOM_TEMPLATES = 'componentTemplates';
export const CUSTOM_TEMPLATE_PATH = 'customTemplatesPath';
export const OVERRIDE_TEMPLATE_PATH = 'overrideTemplatesPath';

export const COMPONENT_REACT_LIB_PATH = 'node_modules/@pega/react-sdk-components/lib';
export const OVERRIDE_REACT_LIB_PATH = 'node_modules/@pega/react-sdk-overrides/lib';

export const COMPONENT_ANGULAR_LIB_PATH = 'node_modules/@pega/angular-sdk-components';
export const COMPONENT_ANGULAR_LIB_LIB_PATH = 'node_modules/@pega/angular-sdk-components/lib';
export const OVERRIDE_ANGULAR_LIB_PATH = 'node_modules/@pega/angular-sdk-overrides/lib';

export const COMPONENT_DIRECTORY_PREFIX_CUSTOM = '/custom-';
export const COMPONENT_DIRECTORY_SUFFIX_SDK = '-sdk';

export const CATEGORY_CUSTOM = 'custom';
export const CATEGORY_OVERRIDE = 'override';
export const CATEGORY_CONSTELLATION = 'constellation';

/* REST end points */
export const PUBLISH_COMPONENT_SERVICE_REST_ENDPOINT = 'PRRestService/dev/v1/publish_component';
export const LIST_COMPONENT_SERVICE_REST_ENDPOINT = 'PRRestService/dev/v1/list_component';
export const OOTB_COMPONENT_SERVICE_REST_ENDPOINT = 'PRRestService/dev/v1/ootb_component';
export const DELETE_COMPONENT_SERVICE_REST_ENDPOINT = 'PRRestService/dev/v1/delete_component';
export const TOKEN_URL_V1 = 'PRRestService/oauth2/v1/token';
export const AUTHORIZE_URL_V1 = 'PRRestService/oauth2/v1/authorize';
export const LP_TOKEN_URL = 'uas/oauth/token';
export const LP_AUTHORIZE_URL = 'uas/oauth/authorize';
export const SERVER_CONFIG = 'serverConfig';
export const SERVER_TYPE = 'serverType';
export const SERVER_REST_URL = 'infinityRestServerUrl';
export const LP_SERVER_REST_URL = 'launchpadRestServerUrl';

export const JEST_ASSETS_PATH = 'node_modules/@pega/dx-component-builder-sdk/tests/assets/';
export const JEST_ASSETS_SDK_A = 'sdk-a/components';
export const JEST_ASSETS_SDK_R = 'sdk-r/components';
export const JEST_CREATE_PATH = 'create/';
export const JEST_CREATE_ALL_PATH = 'createAll/';
export const JEST_TESTS_FUNCTIONAL_PATH = 'node_modules/@pega/dx-component-builder-sdk/tests/functional/';



/* dxcbConfig.componentDefaults LINT setting/value constants */
export const LINT_SETTING_KEY = 'lintAction'; // LINT_SETTING_KEY is expected to be in sdk-config's dxcbConfig.componentDefaults
export const LINT_OFF = 'off'; // LINT_OFF: don't run lint
export const LINT_SHOW = 'show'; // LINT_SHOW: run lint, show results, but don't block processing from continuing if there are lint errors/warnings
export const LINT_BLOCK = 'block'; // LINT_BLOCK: run lint, show results, block processing from continuing if there are lint errors/warnings
export const LINT_DEFAULT = LINT_BLOCK; // LINT_DEFAULT: the default value to use if the key isn't found or key value isn't valid
/* END of dxcb.componentdefaults LINT setting/value constants */

export const AUTHENTICATE_SCHEMA = {
  serverType: [
    {
      name: 'Infinity',
      value: 'infinity'
    },
    {
      name: 'Launchpad',
      value: 'launchpad'
    }
  ],
  grantType: [
    {
      name: 'Authorization code',
      value: 'authCode'
    },
    {
      name: 'Password credentials',
      value: 'passwordCreds'
    },
    {
      name: 'Client credentials',
      value: 'clientCreds'
    }
  ]
};

export const COMPONENT_SCHEMA = {
  framework: [
    {
      name: 'Constellation',
      value: 'Constellation'
    },
    {
      name: 'SDK Angular',
      value: 'SDK-Angular'
    },
    {
      name: 'SDK React',
      value: 'SDK-React'
    },
    {
      name: 'SDK Web Components',
      value: 'SDK-WebComponents'
    }
  ],
  category: [
    {
      name: 'Custom',
      value: 'custom'
    },
    {
      name: 'Override',
      value: 'override'
    }
  ],
  type: [
    {
      name: 'Field',
      value: 'Field'
    },
    {
      name: 'Layout template',
      value: 'Template'
    },
    {
      name: 'Widget',
      value: 'Widget'
    }
  ],
  subtype: {
    field: [
      {
        name: 'Text',
        value: 'Text'
      },
      {
        name: 'Text Input',
        value: 'Text-Input'
      },
      {
        name: 'Paragraph',
        value: 'Text-Paragraph'
      },
      {
        name: 'Email',
        value: 'Text-Email'
      },
      {
        name: 'Phone',
        value: 'Text-Phone'
      },
      {
        name: 'URL',
        value: 'Text-URL'
      },
      {
        name: 'Icon Button URL',
        value: 'Icon-Button-URL'
      },
      {
        name: 'Integer',
        value: 'Integer'
      },
      {
        name: 'Decimal',
        value: 'Decimal'
      },
      {
        name: 'Currency',
        value: 'Decimal-Currency'
      },
      {
        name: 'Percentage',
        value: 'Decimal-Percentage'
      },
      {
        name: 'Boolean',
        value: 'Boolean'
      },
      {
        name: 'Date',
        value: 'Date'
      },
      {
        name: 'DateTime',
        value: 'DateTime'
      },
      {
        name: 'TimeOfDay',
        value: 'TimeOfDay'
      },
      {
        name: 'Picklist',
        value: 'Picklist'
      },
      {
        name: 'Search box',
        value: 'Picklist-Autocomplete'
      },
      {
        name: 'Radio buttons',
        value: 'Picklist-RadioButtons'
      }
    ],
    template: [
      {
        name: 'DETAILS',
        value: 'DETAILS'
      },
      {
        name: 'DETAILS region',
        value: 'DETAILS-region'
      },
      {
        name: 'FORM',
        value: 'FORM'
      },
      {
        name: 'FORM region',
        value: 'FORM-region'
      },
      {
        name: 'PAGE',
        value: 'PAGE'
      }
    ],
    widget: [
      {
        name: 'CASE',
        value: 'CASE'
      },
      {
        name: 'PAGE',
        value: 'PAGE'
      },
      {
        name: 'PAGE & CASE',
        value: ['PAGE', 'CASE']
      }
    ]
  },
  overrideType: [
    {
      name: 'Field',
      value: 'field'
    },
    {
      name: 'Template',
      value: 'template'
    },
    {
      name: 'Widget',
      value: 'widget'
    },
    {
      name: 'Design System Extension',
      value: 'designSystemExtension'
    },
    {
      name: 'Infrastructure',
      value: 'infra'
    }
  ],
  overrideReactComponent: {
    field: [
      {
        name: 'Auto Complete',
        value: 'AutoComplete'
      },
      {
        name: 'Cancel Alert',
        value: 'CancelAlert'
      },
      {
        name: 'Checkbox',
        value: 'Checkbox'
      },
      {
        name: 'Currency',
        value: 'Currency'
      },
      {
        name: 'Date',
        value: 'Date'
      },
      {
        name: 'Date Time',
        value: 'DateTime'
      },
      {
        name: 'Decimal',
        value: 'Decimal'
      },
      {
        name: 'Dropdown',
        value: 'Dropdown'
      },
      {
        name: 'Email',
        value: 'Email'
      },
      {
        name: 'Field Group',
        value: 'Group'
      },
      {
        name: 'Integer',
        value: 'Integer'
      },
      {
        name: 'Multi Select',
        value: 'Multiselect'
      },
      {
        name: 'Percentage',
        value: 'Percentage'
      },
      {
        name: 'Phone',
        value: 'Phone'
      },
      {
        name: 'Radio Buttons',
        value: 'RadioButtons'
      },
      {
        name: 'Rich Text',
        value: 'RichText'
      },
      {
        name: 'Scalar List',
        value: 'ScalarList'
      },
      {
        name: 'Semantic Link',
        value: 'SemanticLink'
      },
      {
        name: 'Text Area',
        value: 'TextArea'
      },
      {
        name: 'Text Content',
        value: 'TextContent'
      },
      {
        name: 'Text Input',
        value: 'TextInput'
      },
      {
        name: 'Time',
        value: 'Time'
      },
      {
        name: 'URL',
        value: 'URL'
      },
      {
        name: 'User Reference',
        value: 'UserReference'
      }
    ],
    designSystemExtension: [
      {
        name: 'Alert Banner',
        value: 'AlertBanner'
      },
      {
        name: 'Banner',
        value: 'Banner'
      },
      {
        name: 'Case Summary Fields',
        value: 'CaseSummaryFields'
      },
      {
        name: 'Details Fields',
        value: 'DetailsFields'
      },
      {
        name: 'Field Group',
        value: 'FieldGroup'
      },
      {
        name: 'Field Group List',
        value: 'FieldGroupList'
      },
      {
        name: 'Field Value List',
        value: 'FieldValueList'
      },
      {
        name: 'Operator',
        value: 'Operator'
      },
      {
        name: 'Pulse',
        value: 'Pulse'
      },
      {
        name: 'Rich Text Editor',
        value: 'RichTextEditor'
      },
      {
        name: 'Wss Quick Create',
        value: 'WssQuickCreate'
      }
    ],
    infra: [
      {
        name: 'Action Buttons',
        value: 'ActionButtons'
      },
      {
        name: 'Assignment',
        value: 'Assignment'
      },
      {
        name: 'Assignment Card',
        value: 'AssignmentCard'
      },
      {
        name: 'Dashboard Filter',
        value: 'DashboardFilter'
      },
      {
        name: 'Defer Load',
        value: 'DeferLoad'
      },
      {
        name: 'Error Boundary',
        value: 'ErrorBoundary'
      },
      {
        name: 'Flow Container',
        value: 'Containers/FlowContainer'
      },
      {
        name: 'Modal View Container',
        value: 'Containers/ModalViewContainer'
      },
      {
        name: 'Multi Step',
        value: 'MultiStep'
      },
      {
        name: 'Nav Bar',
        value: 'NavBar'
      },
      {
        name: 'Reference',
        value: 'Reference'
      },
      {
        name: 'Region',
        value: 'Region'
      },
      {
        name: 'Root Container',
        value: 'RootContainer'
      },
      {
        name: 'Simple View',
        value: 'Containers/SimpleView'
      },
      {
        name: 'Stages',
        value: 'Stages'
      },
      {
        name: 'Vertical Tabs',
        value: 'VerticalTabs/VerticalTabs'
      },
      {
        name: 'Left Align Vertical Tabs',
        value: 'VerticalTabs/LeftAlignVerticalTabs'
      },
      {
        name: 'View',
        value: 'View'
      },
      {
        name: 'View Container',
        value: 'Containers/ViewContainer'
      },
    ],
    template: [
      {
        name: 'App Shell',
        value: 'AppShell'
      },
      {
        name: 'Banner Page',
        value: 'BannerPage'
      },
      {
        name: 'Case Summary',
        value: 'CaseSummary'
      },
      {
        name: 'Case View',
        value: 'CaseView'
      },
      {
        name: 'Case View Actions Menu',
        value: 'CaseViewActionsMenu'
      },
      {
        name: 'Confirmation',
        value: 'Confirmation'
      },
      {
        name: 'Data Reference',
        value: 'DataReference'
      },
      {
        name: 'Default Form',
        value: 'DefaultForm'
      },
      {
        name: 'Details',
        value: 'Details/Details'
      },
      {
        name: 'Details Sub Tabs',
        value: 'Details/DetailsSubTabs'
      },
      {
        name: 'Details Two Column',
        value: 'Details/DetailsTwoColumn'
      },
      {
        name: 'Details Three Column',
        value: 'Details/DetailsThreeColumn'
      },
      {
        name: 'Dynamic Tabs',
        value: 'Details/DynamicTabs'
      },
      {
        name: 'Field Group Template',
        value: 'FieldGroupTemplate'
      },
      {
        name: 'Inline Dashboard',
        value: 'InlineDashboard'
      },
      {
        name: 'Inline Dashboard Page',
        value: 'InlineDashboardPage'
      },
      {
        name: 'List Page',
        value: 'ListPage'
      },
      {
        name: 'List View',
        value: 'ListView'
      },
      {
        name: 'Multi Reference - ReadOnly',
        value: 'MultiReferenceReadOnly'
      },
      {
        name: 'Narrow Wide',
        value: 'NarrowWide/NarrowWide'
      },
      {
        name: 'Narrow Wide Details',
        value: 'NarrowWide/NarrowWideDetails'
      },
      {
        name: 'Narrow Wide Form',
        value: 'NarrowWide/NarrowWideForm'
      },
      {
        name: 'Narrow Wide Page',
        value: 'NarrowWide/NarrowWidePage'
      },
      {
        name: 'One Column',
        value: 'OneColumn/OneColumn'
      },
      {
        name: 'One Column Page',
        value: 'OneColumn/OneColumnPage'
      },
      {
        name: 'One Column Tab',
        value: 'OneColumn/OneColumnTab'
      },
      {
        name: 'Promoted Filters',
        value: 'PromotedFilters'
      },
      {
        name: 'Simple Table',
        value: 'SimpleTable/SimpleTable'
      },
      {
        name: 'Simple Table Manual',
        value: 'SimpleTable/SimpleTableManual'
      },
      {
        name: 'Simple Table Select',
        value: 'SimpleTable/SimpleTableSelect'
      },
      {
        name: 'Single Reference - ReadOnly',
        value: 'SingleReferenceReadOnly'
      },
      {
        name: 'Sub Tabs',
        value: 'SubTabs'
      },
      {
        name: 'Two Column',
        value: 'TwoColumn/TwoColumn'
      },
      {
        name: 'Two Column Page',
        value: 'TwoColumn/TwoColumnPage'
      },
      {
        name: 'Two Column Tab',
        value: 'TwoColumn/TwoColumnTab'
      },
      {
        name: 'Wide Narrow',
        value: 'WideNarrow/WideNarrow'
      },
      {
        name: 'Wide Narrow Details',
        value: 'WideNarrow/WideNarrowDetails'
      },
      {
        name: 'Wide Narrow Form',
        value: 'WideNarrow/WideNarrowForm'
      },
      {
        name: 'Wide Narrow Page',
        value: 'WideNarrow/WideNarrowPage'
      },
      {
        name: 'Wss Nav Bar',
        value: 'WssNavBar'
      }
    ],
    widget: [
      {
        name: 'Action Buttons For File Util',
        value: 'FileUtility/ActionButtonsForFileUtil'
      },
      {
        name: 'App Announcement',
        value: 'AppAnnouncement'
      },
      {
        name: 'Attachment',
        value: 'Attachment'
      },
      {
        name: 'Case History',
        value: 'CaseHistory'
      },
      {
        name: 'File Utility',
        value: 'FileUtility/FileUtility'
      },
      
      {
        name: 'Followers',
        value: 'Followers'
      },
      {
        name: 'Quick Create',
        value: 'QuickCreate'
      },
      {
        name: 'Summary Item',
        value: 'SummaryItem'
      },
      {
        name: 'Summary List',
        value: 'SummaryList'
      },
      {
        name: 'To Do',
        value: 'ToDo'
      }
    ]
  },
  overrideAngularComponent: {
    field: [
      {
        name: 'Auto Complete',
        value: 'AutoComplete'
      },
      {
        name: 'Cancel Alert',
        value: 'CancelAlert'
      },
      {
        name: 'Checkbox',
        value: 'CheckBox'
      },
      {
        name: 'Currency',
        value: 'Currency'
      },
      {
        name: 'Date',
        value: 'Date'
      },
      {
        name: 'Date Time',
        value: 'DateTime'
      },
      {
        name: 'Decimal',
        value: 'Decimal'
      },
      {
        name: 'Dropdown',
        value: 'Dropdown'
      },
      {
        name: 'Email',
        value: 'Email'
      },
      {
        name: 'Field Group',
        value: 'Group'
      },
      {
        name: 'Integer',
        value: 'Integer'
      },
      {
        name: 'Percentage',
        value: 'Percentage'
      },
      {
        name: 'Phone',
        value: 'Phone'
      },
      {
        name: 'Radio Buttons',
        value: 'RadioButtons'
      },
      {
        name: 'Rich Text',
        value: 'RichText'
      },
      {
        name: 'Scalar List',
        value: 'ScalarList'
      },
      {
        name: 'Semantic Link',
        value: 'SemanticLink'
      },
      {
        name: 'Text',
        value: 'Text'
      },
      {
        name: 'Text Area',
        value: 'TextArea'
      },
      {
        name: 'Text Content',
        value: 'TextContent'
      },
      {
        name: 'Text Input',
        value: 'TextInput'
      },
      {
        name: 'Time',
        value: 'Time'
      },
      {
        name: 'Url',
        value: 'url'
      },
      {
        name: 'User Reference',
        value: 'UserReference'
      }
    ],
    designSystemExtension: [
      {
        name: 'Alert',
        value: 'Alert'
      },
      {
        name: 'Alert Banner',
        value: 'AlertBanner'
      },
      {
        name: 'Banner',
        value: 'Banner'
      },
      {
        name: 'Case Create Stage',
        value: 'CaseCreateStage'
      },
      {
        name: 'Field Group',
        value: 'FieldGroup'
      },
      {
        name: 'Material Case Summary',
        value: 'MaterialCaseSummary'
      },
      {
        name: 'Material Details',
        value: 'MaterialDetails'
      },
      {
        name: 'Material Details Fields',
        value: 'MaterialDetailsFields'
      },
      {
        name: 'Material Summary Item',
        value: 'MaterialSummaryItem'
      },
      {
        name: 'Material Summary List',
        value: 'MaterialSummaryList'
      },
      {
        name: 'Material Utility',
        value: 'MaterialUtility'
      },
      {
        name: 'Material Vertical Tabs',
        value: 'MaterialVerticalTabs'
      },
      {
        name: 'Operator',
        value: 'Operator'
      },
      {
        name: 'Pulse',
        value: 'Pulse'
      },
      {
        name: 'Rich Text Editor',
        value: 'RichTextEditor'
      },
      {
        name: 'Wss Quick Create',
        value: 'WssQuickCreate'
      }
    ],
    infra: [
      {
        name: 'Action Buttons',
        value: 'ActionButtons'
      },
      {
        name: 'Assignment',
        value: 'Assignment'
      },
      {
        name: 'Assignment Card',
        value: 'AssignmentCard'
      },
      {
        name: 'Dashboard Filter',
        value: 'DashboardFilter'
      },
      {
        name: 'Defer Load',
        value: 'DeferLoad'
      },
      {
        name: 'Error Boundary',
        value: 'ErrorBoundary'
      },
      {
        name: 'Flow Container',
        value: 'Containers/FlowContainer'
      },
      {
        name: 'Hybrid View Container',
        value: 'Containers/HybridViewContainer'
      },
      {
        name: 'Modal View Container',
        value: 'Containers/ModalViewContainer'
      },
      {
        name: 'Multi Step',
        value: 'MultiStep'
      },
      {
        name: 'Nav Bar',
        value: 'Navbar'
      },
      {
        name: 'Preview View Container',
        value: 'Containers/PreviewViewContainer'
      },
      {
        name: 'Region',
        value: 'Region'
      },
      {
        name: 'Root Container',
        value: 'RootContainer'
      },
      {
        name: 'Stages',
        value: 'Stages'
      },
      {
        name: 'View',
        value: 'View'
      },
      {
        name: 'View Container',
        value: 'Containers/ViewContainer'
      },
    ],
    template: [
      {
        name: 'App Shell',
        value: 'AppShell'
      },
      {
        name: 'Banner Page',
        value: 'BannerPage'
      },
      {
        name: 'Case Summary',
        value: 'CaseSummary'
      },
      {
        name: 'Case View',
        value: 'CaseView'
      },
      {
        name: 'Confirmation',
        value: 'Confirmation'
      },
      {
        name: 'Data Reference',
        value: 'DataReference'
      },
      {
        name: 'Default Form',
        value: 'DefaultForm'
      },
      {
        name: 'Details',
        value: 'Details'
      },
      {
        name: 'Details Narrow Wide',
        value: 'DetailsNarrowWide'
      },
      {
        name: 'Details One Column',
        value: 'DetailsOneColumn'
      },
      {
        name: 'Details Sub Tabs',
        value: 'DetailsSubTabs'
      },
      {
        name: 'Details Two Column',
        value: 'DetailsTwoColumn'
      },
      {
        name: 'Details Three Column',
        value: 'DetailsThreeColumn'
      },
      {
        name: 'Details Wide Narrow',
        value: 'DetailsWideNarrow'
      },
      {
        name: 'Dynamic Tabs',
        value: 'DynamicTabs'
      },
      {
        name: 'Field Group List',
        value: 'FieldGroupList'
      },
      {
        name: 'Field Group Template',
        value: 'FieldGroupTemplate'
      },
      {
        name: 'Field Value List',
        value: 'FieldValueList'
      },
      {
        name: 'Inline Dashboard',
        value: 'InlineDashboard'
      },
      {
        name: 'Inline Dashboard Page',
        value: 'InlineDashboardPage'
      },
      {
        name: 'List Page',
        value: 'ListPage'
      },
      {
        name: 'List View',
        value: 'ListView'
      },
      {
        name: 'Multi Refernce - ReadOnly',
        value: 'MultiReferenceReadonly'
      },
      {
        name: 'Narrow Wide Form',
        value: 'NarrowWideForm'
      },
      {
        name: 'One Column',
        value: 'OneColumn'
      },
      {
        name: 'One Column Page',
        value: 'OneColumnPage'
      },
      {
        name: 'One Column Tab',
        value: 'OneColumnTab'
      },
      {
        name: 'Page',
        value: 'Page'
      },
      {
        name: 'Promoted Filters',
        value: 'PromotedFilters'
      },
      {
        name: 'Repeating Structures',
        value: 'RepeatingStructures'
      },
      {
        name: 'Simple Table',
        value: 'SimpleTable'
      },
      {
        name: 'Simple Table Manual',
        value: 'SimpleTableManual'
      },
      {
        name: 'Simple Table Select',
        value: 'SimpleTableSelect'
      },
      {
        name: 'Single Reference - ReadOnly',
        value: 'SingleReferenceReadonly'
      },
      {
        name: 'Sub Tabs',
        value: 'SubTabs'
      },
      {
        name: 'Two Column',
        value: 'TwoColumn'
      },
      {
        name: 'Two Column Page',
        value: 'TwoColumnPage'
      },
      {
        name: 'Two Column Tab',
        value: 'TwoColumnTab'
      },
      {
        name: 'Three Column',
        value: 'ThreeColumn'
      },
      {
        name: 'Three Column Page',
        value: 'ThreeColumnPage'
      },
      {
        name: 'Wide Narrow Form',
        value: 'WideNarrowForm'
      },
      {
        name: 'Wide Narrow Page',
        value: 'WideNarrowPage'
      },
      {
        name: 'Wss Nav Bar',
        value: 'WssNavBar'
      }
    ],
    widget: [
      {
        name: 'App Announcement',
        value: 'AppAnnouncement'
      },
      {
        name: 'Attachment',
        value: 'Attachment'
      },
      {
        name: 'Case History',
        value: 'CaseHistory'
      },
      {
        name: 'Feed Container',
        value: 'FeedContainer'
      },
      {
        name: 'File Utility',
        value: 'FileUtility'
      },
      {
        name: 'List Utility',
        value: 'ListUtility'
      },
      {
        name: 'Quick Create',
        value: 'QuickCreate'
      },
      {
        name: 'To Do',
        value: 'Todo'
      },
      {
        name: 'Utility',
        value: 'Utility'
      }
    ]
  },
  overrideWCComponent: {
    field: [
      {
        name: 'Auto Complete',
        value: 'AutoComplete'
      },
      {
        name: 'Cancel Alert',
        value: 'CancelAlert'
      },
      {
        name: 'Checkbox',
        value: 'Checkbox'
      },
      {
        name: 'Currency',
        value: 'Currency'
      },
      {
        name: 'Date',
        value: 'Date'
      },
      {
        name: 'Date Time',
        value: 'DateTime'
      },
      {
        name: 'Decimal',
        value: 'Decimal'
      },
      {
        name: 'Dropdown',
        value: 'Dropdown'
      },
      {
        name: 'Email',
        value: 'Email'
      },
      {
        name: 'Integer',
        value: 'Integer'
      },
      {
        name: 'Percentage',
        value: 'Percentage'
      },
      {
        name: 'Phone',
        value: 'Phone'
      },
      {
        name: 'Radio Buttons',
        value: 'RadioButtons'
      },
      {
        name: 'Semantic Link',
        value: 'SemanticLink'
      },
      {
        name: 'Text Area',
        value: 'TextArea'
      },
      {
        name: 'Text Content',
        value: 'TextContent'
      },
      {
        name: 'Text Input',
        value: 'TextInput'
      },
      {
        name: 'Time',
        value: 'Time'
      },
      {
        name: 'URL',
        value: 'URL'
      },
      {
        name: 'User Reference',
        value: 'UserReference'
      }
    ],
    designSystemExtension: [
      {
        name: 'Banner',
        value: 'Banner'
      },
      {
        name: 'Case Summary Fields',
        value: 'CaseSummaryFields'
      },
      {
        name: 'Details Fields',
        value: 'DetailsFields'
      },
      {
        name: 'Field Group',
        value: 'FieldGroup'
      },
      {
        name: 'Field Group List',
        value: 'FieldGroupList'
      },
      {
        name: 'Field Value List',
        value: 'FieldValueList'
      },
      {
        name: 'Operator',
        value: 'Operator'
      },
      {
        name: 'Pulse',
        value: 'Pulse'
      },
      {
        name: 'Wss Quick Create',
        value: 'WssQuickCreate'
      }
    ],
    infra: [
      {
        name: 'Action Buttons',
        value: 'ActionButtons'
      },
      {
        name: 'Assignment',
        value: 'Assignment'
      },
      {
        name: 'Assignment Card',
        value: 'AssignmentCard'
      },
      {
        name: 'Defer Load',
        value: 'DeferLoad'
      },
      {
        name: 'Error Boundary',
        value: 'ErrorBoundary'
      },
      {
        name: 'Multi Step',
        value: 'MultiStep'
      },
      {
        name: 'Nav Bar',
        value: 'Navbar'
      },
      {
        name: 'Region',
        value: 'Region'
      },
      {
        name: 'Stages',
        value: 'Stages'
      },
      {
        name: 'View',
        value: 'View'
      }
    ],
    template: [
      {
        name: 'App Shell',
        value: 'AppShell'
      },
      {
        name: 'Case Summary',
        value: 'CaseSummary'
      },
      {
        name: 'Case View',
        value: 'CaseView'
      },
      {
        name: 'Confirmation',
        value: 'Confirmation'
      },
      {
        name: 'Data Reference',
        value: 'DataReference'
      },
      {
        name: 'Default Form',
        value: 'DefaultForm'
      },
      {
        name: 'Details',
        value: 'Details'
      },
      {
        name: 'Details Narrow Wide',
        value: 'DetailsNarrowWide'
      },
      {
        name: 'Details One Column',
        value: 'DetailsOneColumn'
      },
      {
        name: 'Details Sub Tabs',
        value: 'DetailsSubTabs'
      },
      {
        name: 'Details Two Column',
        value: 'DetailsTwoColumn'
      },
      {
        name: 'Details Three Column',
        value: 'DetailsThreeColumn'
      },
      {
        name: 'Field Group List',
        value: 'FieldGroupList'
      },
      {
        name: 'Field Group Template',
        value: 'FieldGroupTemplate'
      },
      {
        name: 'Field Value List',
        value: 'FieldValueList'
      },
      {
        name: 'List Page',
        value: 'ListPage'
      },
      {
        name: 'List View',
        value: 'ListView'
      },
      {
        name: 'Multi Refernce - ReadOnly',
        value: 'MultiReferenceReadonly'
      },
      {
        name: 'Narrow Wide Form',
        value: 'NarrowWideForm'
      },
      {
        name: 'One Column',
        value: 'OneColumn'
      },
      {
        name: 'One Column Page',
        value: 'OneColumnPage'
      },
      {
        name: 'One Column Tab',
        value: 'OneColumnTab'
      },
      {
        name: 'Page',
        value: 'Page'
      },
      {
        name: 'Promoted Filters',
        value: 'PromotedFilters'
      },
      {
        name: 'Repeating Structures',
        value: 'RepeatingStructures'
      },
      {
        name: 'Simple Table',
        value: 'SimpleTable'
      },
      {
        name: 'Simple Table Manual',
        value: 'SimpleTableManual'
      },
      {
        name: 'Simple Table Select',
        value: 'SimpleTableSelect'
      },
      {
        name: 'Single Reference - ReadOnly',
        value: 'SingleReferenceReadonly'
      },
      {
        name: 'Sub Tabs',
        value: 'SubTabs'
      },
      {
        name: 'Two Column',
        value: 'TwoColumn'
      },
      {
        name: 'Two Column Page',
        value: 'TwoColumnPage'
      },
      {
        name: 'Two Column Tab',
        value: 'TwoColumnTab'
      },
      {
        name: 'Three Column',
        value: 'ThreeColumn'
      },
      {
        name: 'Three Column Page',
        value: 'ThreeColumnPage'
      },
      {
        name: 'Wide Narrow Form',
        value: 'WideNarrowForm'
      },
      {
        name: 'Wide Narrow Page',
        value: 'WideNarrowPage'
      },
      {
        name: 'Wss Nav Bar',
        value: 'WssNavBar'
      }
    ],
    widget: [
      {
        name: 'App Announcement',
        value: 'AppAnnouncement'
      },
      {
        name: 'Attachment',
        value: 'Attachment'
      },
      {
        name: 'Case History',
        value: 'CaseHistory'
      },
      {
        name: 'Feed Container',
        value: 'FeedContainer'
      },
      {
        name: 'File Utility',
        value: 'FileUtility'
      },
      {
        name: 'List Utility',
        value: 'ListUtility'
      },
      {
        name: 'To Do',
        value: 'ToDo'
      },
      {
        name: 'Utility',
        value: 'Utility'
      }
    ]
  }
};
