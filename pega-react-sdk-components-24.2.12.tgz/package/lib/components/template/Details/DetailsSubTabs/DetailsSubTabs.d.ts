import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../../types/PConnProps';
interface DetailsSubTabsProps extends PConnProps {
    showLabel: boolean;
    label: string;
}
export default function DetailsSubTabs(props: PropsWithChildren<DetailsSubTabsProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=DetailsSubTabs.d.ts.map