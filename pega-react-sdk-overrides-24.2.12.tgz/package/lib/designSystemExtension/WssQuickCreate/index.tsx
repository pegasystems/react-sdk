export { default } from './WssQuickCreate';
