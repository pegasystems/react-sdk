export declare class Utils {
    static lastControlID: number;
    static getSDKStaticConentUrl(): string;
    static getUniqueControlID(): string;
    static getOptionList(configProps: any, dataObject: any): any[];
    static getInitials(userName: string): string;
    static getImageSrc(name: string, serverUrl: string): string;
    static getIconPath(serverUrl: string): string;
    static getBooleanValue(inValue: any): boolean;
    static generateDate(dateVal: any, dateFormat: any): any;
    static generateDateTime(dateTimeVal: any, dateFormat: any): any;
    static getSeconds(sTime: any): any;
    static getIconFromFileType(fileType: any): string;
    static getIconForAttachment(attachment: any): any;
    static getLastChar(text: any): any;
    static isObject(objValue: any): any;
}
export default Utils;
//# sourceMappingURL=utils.d.ts.map