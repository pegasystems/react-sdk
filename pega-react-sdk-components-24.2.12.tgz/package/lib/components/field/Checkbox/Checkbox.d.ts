import { PConnFieldProps } from '../../../types/PConnProps';
interface CheckboxProps extends Omit<PConnFieldProps, 'value'> {
    value?: boolean;
    caption?: string;
    trueLabel?: string;
    falseLabel?: string;
    selectionMode?: string;
    datasource?: any;
    selectionKey?: string;
    selectionList?: any;
    primaryField: string;
    readonlyContextList: any;
    referenceList: string;
}
export default function CheckboxComponent(props: CheckboxProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Checkbox.d.ts.map