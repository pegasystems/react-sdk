import './CaseSummaryFields.css';
interface CaseSummaryFieldsProps {
    status?: string;
    showStatus?: boolean;
    theFields: any[] | any | never;
}
export default function CaseSummaryFields(props: CaseSummaryFieldsProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=CaseSummaryFields.d.ts.map