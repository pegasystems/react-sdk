import { PConnProps } from '../../../../../types/PConnProps';
interface ListViewActionButtonsProps extends PConnProps {
    context: string;
    closeActionsDialog: Function;
}
declare function ListViewActionButtons(props: ListViewActionButtonsProps): import("react/jsx-runtime").JSX.Element;
export default ListViewActionButtons;
//# sourceMappingURL=ListViewActionButtons.d.ts.map