import type { CoachMessageProps, GenAIMessageProps, MenuGroupProps, MenuItemProps, Question, State, UserMessageProps, Variant } from './GenAICoach.types';
export declare const getSelectedKeys: (question: Question) => string[];
export declare const isCoachMessage: (message: GenAIMessageProps) => message is CoachMessageProps;
export declare const isUserMessage: (message: GenAIMessageProps) => message is UserMessageProps;
export declare const isInUtilities: (item: Variant) => item is {
    placement: "utilities";
    state: State;
    onStateChange: (state: State) => void;
};
export declare const createUID: () => string;
export declare const isMenuGroupProps: (item: MenuItemProps | MenuGroupProps) => item is MenuGroupProps;
//# sourceMappingURL=GenAICoach.utils.d.ts.map