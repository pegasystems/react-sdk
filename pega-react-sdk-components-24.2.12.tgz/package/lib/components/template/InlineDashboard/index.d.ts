export { default } from './InlineDashboard';
//# sourceMappingURL=index.d.ts.map