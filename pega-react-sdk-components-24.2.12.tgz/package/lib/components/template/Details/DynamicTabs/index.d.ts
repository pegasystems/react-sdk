export { default } from './DynamicTabs';
//# sourceMappingURL=index.d.ts.map