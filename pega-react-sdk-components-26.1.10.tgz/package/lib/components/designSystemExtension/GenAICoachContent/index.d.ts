export { default } from './GenAICoachContent';
//# sourceMappingURL=index.d.ts.map