import { type PropsWithChildren } from 'react';
import type { PConnProps } from '../../../../types/PConnProps';
interface DetailsSubTabsProps extends PConnProps {
    showLabel: boolean;
    label: string;
}
export default function DetailsSubTabs(props: PropsWithChildren<DetailsSubTabsProps>): import("react").JSX.Element;
export {};
//# sourceMappingURL=DetailsSubTabs.d.ts.map