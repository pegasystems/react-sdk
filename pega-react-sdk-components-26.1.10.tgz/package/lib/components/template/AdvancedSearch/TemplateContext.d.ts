declare const TemplateContext: import("react").Context<{
    depth: number;
    columnCount: number;
    outerColumnCount: undefined;
    templateOverrideMode: undefined;
    inheritParentLayout: undefined;
    lastContainerItem: undefined;
}>;
export default TemplateContext;
//# sourceMappingURL=TemplateContext.d.ts.map