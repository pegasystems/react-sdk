import './AlertBanner.css';
interface AlertBannerProps {
    id: string;
    variant: string;
    messages: string[];
    onDismiss?: any;
}
export default function AlertBanner({ id, variant, messages, onDismiss }: AlertBannerProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=AlertBanner.d.ts.map