export declare const dateFormatInfoDefault: {
    dateFormatString: string;
    dateFormatStringLong: string;
    dateFormatStringLC: string;
    dateFormatMask: string;
};
export declare const getDateFormatInfo: () => typeof dateFormatInfoDefault;
//# sourceMappingURL=date-format-utils.d.ts.map