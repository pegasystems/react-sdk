export { default } from './WideNarrowPage';
//# sourceMappingURL=index.d.ts.map