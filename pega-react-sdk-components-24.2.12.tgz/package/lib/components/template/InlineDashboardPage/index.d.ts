export { default } from './InlineDashboardPage';
//# sourceMappingURL=index.d.ts.map