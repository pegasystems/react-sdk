export { default } from './Reference';
//# sourceMappingURL=index.d.ts.map