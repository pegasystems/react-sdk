import type { PropsWithChildren } from 'react';
import type { PConnProps } from '../../../../types/PConnProps';
interface OneColumnTabProps extends PConnProps {
}
export default function OneColumnTab(props: PropsWithChildren<OneColumnTabProps>): import("react").JSX.Element;
export {};
//# sourceMappingURL=OneColumnTab.d.ts.map