export declare let SdkComponentMap: any;
export declare function getComponentFromMap(inComponentName: string): any;
export declare function getSdkComponentMap(inLocalComponentMap?: {}): Promise<unknown>;
//# sourceMappingURL=sdk_component_map.d.ts.map