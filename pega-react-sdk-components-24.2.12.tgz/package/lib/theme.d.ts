import { Theme } from '@mui/material/styles';
/**
 * Since makeStyles is now exported from @mui/styles package which does not know about Theme in the core package.
 * you need to augment the DefaultTheme (empty object) in @mui/styles with Theme from the core.
 */
declare module '@mui/styles/defaultTheme' {
    interface DefaultTheme extends Theme {
    }
}
export declare const theme: Theme;
//# sourceMappingURL=theme.d.ts.map