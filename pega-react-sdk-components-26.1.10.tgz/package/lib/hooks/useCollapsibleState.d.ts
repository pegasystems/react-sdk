import { type Dispatch, type SetStateAction } from 'react';
/**
 * Controls the initial collapse behaviour of the field group:
 * - `'none'` — not collapsible (default)
 * - `'expanded'` — collapsible, starts expanded
 * - `'collapsed'` — collapsible, starts collapsed
 * - `true` / `false` — legacy aliases for `'expanded'` / `'none'`, kept for backward
 *   compatibility with existing authored views that still emit the old boolean `collapsible` prop.
 */
type CollapseOnLoad = 'none' | 'expanded' | 'collapsed' | boolean;
interface CollapsibleState {
    isCollapsibleMode: boolean;
    collapsed: boolean | undefined;
    setCollapsed: Dispatch<SetStateAction<boolean | undefined>>;
}
declare const useCollapsibleState: (collapseOnLoad: CollapseOnLoad, collapsible: boolean | undefined, defaultCollapsed: boolean, showHeading: boolean) => CollapsibleState;
export default useCollapsibleState;
//# sourceMappingURL=useCollapsibleState.d.ts.map