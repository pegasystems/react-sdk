import chalk from 'chalk';
import inquirer from 'inquirer';
import ora from 'ora';
import { join } from 'path';

import { COMPONENT_SCHEMA, CATEGORY_CONSTELLATION, CATEGORY_CUSTOM, CATEGORY_OVERRIDE } from '../..//constants.js';
import {
  deleteLocalComponent,
  deleteServerComponent,
  getComponentsObj,
  getPegaServerConfig,
  validateRulesetVersion,
  getOptionsCategory,
  getFramework,
  getLocalComponentKeyFromConfig,
  convertIntoKebabCase,
  convertIntoPascalCase
} from '../../util.js';
import { getComponentsFromServer } from '../list/helper.js';

import { deleteFromComponentMap } from '../map/map.js';

export const SOURCE_OF_COMPONENT_TYPES = {
  SERVER: 'Server',
  LOCAL: 'Local'
};

export const visualLCCategory = (category) => {

  switch (category) {
    case CATEGORY_CONSTELLATION :
      return "custom-".concat(category.toLowerCase());
    case CATEGORY_CUSTOM :
    case CATEGORY_OVERRIDE :
      return category.toLowerCase().concat("-sdk");
  }

  return category.toLowerCase();
}

export const getDeleteComponentsQuestions = async (options, sourceOfComponentsOption) => {
  const defaultPegaServerConfig = await getPegaServerConfig();
  const categoryType = getOptionsCategory(options);

  return [
    {
      name: 'sourceOfComponents',
      type: 'rawlist',
      message: 'Delete components from Server or Local ?',
      choices: Object.values(SOURCE_OF_COMPONENT_TYPES),
      default: defaultPegaServerConfig.sourceOfComponents,

    },
    {
      name: 'category',
      type: 'rawlist',
      message: 'Category of components ?',
      choices: COMPONENT_SCHEMA.category,
      when(answers) {
        return answers.sourceOfComponents != "Server"
      }
    }
  ];
};



export const deleteLocalComponents = async (sourceOfComponents, category = CATEGORY_CUSTOM, options) => {
  const localComponents = await getComponentsObj(true, category);
  const framework = await getFramework();

  let confirmDeletion;

  if (localComponents.length > 0) {
    if (options.params.length >= 6) {
      const sDeletion = options.params[5];
      confirmDeletion = sDeletion === 'Y' || sDeletion === 'y' || sDeletion === true || sDeletion === 'true';

    } else {

      for (var index in localComponents) {
        if (localComponents[index].type != undefined && localComponents[index].type === "separator") {
          console.log(chalk.bold.green(localComponents[index]));
        }
        else {
          console.log(chalk.bold.green(localComponents[index].name));
        }

      }

      const answers = await inquirer.prompt([

        {
          name: 'confirmDeletion',
          type: 'confirm',
          message: 'Delete all local ?',
          default: false
        }
      ]);

      confirmDeletion = answers.confirmDeletion;
    }

    if (confirmDeletion) {
      for (var index in localComponents) {
        if (localComponents[index].type == undefined) {
          var componentToDelete = localComponents[index].value;

          let customComponentKey = componentToDelete;

          switch (framework) {
            case "SDK-Angular":
              // because of naming Pascal case vs Kebab case, given Pascal - use for associated
              // Kebab case customComponentKey

              let arComp = componentToDelete.split("/");
              arComp[1] = convertIntoKebabCase(convertIntoPascalCase(arComp[1]));
              customComponentKey = arComp.join("/");

              await deleteLocalComponent(customComponentKey, category);
              if (category  === CATEGORY_CUSTOM) {
                await deleteLocalComponent(componentToDelete, CATEGORY_CONSTELLATION);
              }

              break;
            case "SDK-React":
              await deleteLocalComponent(componentToDelete, category);
              if (category  === CATEGORY_CUSTOM) {
                await deleteLocalComponent(componentToDelete, CATEGORY_CONSTELLATION);
              }
              break;
            case "SDK-WebComponents":
              await deleteLocalComponent(componentToDelete, category);
              if (category  === CATEGORY_CUSTOM) {
                await deleteLocalComponent(componentToDelete, CATEGORY_CONSTELLATION);
              }
              break;
          }



          // need to remove the map as well
          if (componentToDelete != undefined) {
            await deleteFromComponentMap(customComponentKey, category);
          }
          else {
            console.log(chalk.bold.redBright(`No component in map: ` + customComponentKey));
          }

        }

      }
    }
  } else {
    const categoryLC = visualLCCategory(category);
    console.log(chalk.bold.redBright(`No ${categoryLC} components in ${sourceOfComponents}`));
  }
};

export const deleteServerComponents = async (sourceOfComponents, answers) => {
  let spinner;
  let data;
  try {
    spinner = ora('Fetching components from server').start();
    data = await getComponentsFromServer(answers);
    spinner.stop();
  }
  catch (error) {
    spinner.stop();
    if (error.indexOf("ECONNREFUSED") >= 0) {
      console.log(`\n${chalk.bold.red('Error occurred in authentication. Please regenerate using authenticate')}`);
    }
    else {
      console.log(`${chalk.bold.red(error)}`);
    }

    // spinner.stop();
    process.exit(1);
  }


  const defaultPegaConfig = await getPegaServerConfig();
  const componentObj = await getComponentsObj(false);

  const framework = await getFramework();

  const serverComponents = JSON.parse(data);
  spinner.stop();
  if (serverComponents && serverComponents.pxResults?.length > 0) {
    const choicesArr = serverComponents.pxResults.map(({ label, pyRuleSet, pyRuleSetVersion }) => {
      const name = `${standardizeStr(label, 45)} ${standardizeStr(pyRuleSet, 30)} ${standardizeStr(
        pyRuleSetVersion,
        20
      )}`;

      const value = `${label}~|~${pyRuleSet}~|~${pyRuleSetVersion}`;
      const short = `Selected component : ${chalk.redBright(
        `${label} ${pyRuleSet} : ${pyRuleSetVersion}`
      )}`;

      return { name, value, short };
    });

    const selectedComp = await inquirer.prompt([
      {
        name: 'rulesetName',
        message: 'Enter ruleset name',
        default: defaultPegaConfig.rulesetName,
        validate: value => {
          if (value.trim()) {
            return true;
          }
          return 'Ruleset name cannot be empty';
        }
      },
      {
        name: 'rulesetVersion',
        message: 'Enter ruleset version',
        default: defaultPegaConfig.rulesetVersion,
        validate: value => {
          if (validateRulesetVersion(value)) {
            return true;
          }
          return 'Please provide compatible version e.g 01-01-01';
        }
      }
      ]);

      for (var index in choicesArr) {
        var componentToDelete = choicesArr[index].value;
        var arData = componentToDelete.split("~|~");
        if (arData[1] == selectedComp.rulesetName && arData[2] == selectedComp.rulesetVersion) {
          console.log(chalk.bold.green(arData[0]));
        }
      }


    const answers = await inquirer.prompt([
      {
        name: 'confirmDeletion',
        type: 'confirm',
        message: 'Do you want to delete these components ?',
        default: false
      }
    ]);
    if (answers.confirmDeletion) {
      for (var index in choicesArr) {
        var componentToDelete = choicesArr[index].value;
        var arData = componentToDelete.split("~|~");
        if (arData[1] == selectedComp.rulesetName && arData[2] == selectedComp.rulesetVersion) {
          await deleteServerComponent(componentToDelete);

          const componentName = componentToDelete.split("~")[0];
          let componentKey;

          switch (framework) {
            case "SDK-Angular":
              const tempComponentName = convertIntoKebabCase(convertIntoPascalCase(componentName));
              componentKey = componentObj.find( theObj => theObj.name === tempComponentName);
              break;
            case "SDK-React":
              componentKey = componentObj.find( theObj => theObj.name === componentName);
              break;
            case "SDK-WebComponents":
              break;
          }



          // check to see if component is an override component
          if (componentKey === undefined) {
            const overrideObj = await getComponentsObj(false, CATEGORY_OVERRIDE);
            if (overrideObj) {
              const overrideKey = overrideObj.find( theObj => theObj.name === componentName);
              if (overrideKey != undefined) {
                // override component, don't remove from map, just end
                continue;
              }
            }
          }

          if (componentKey != undefined) {
            await deleteFromComponentMap(componentKey.value);
          }
          else {
            console.log(chalk.bold.redBright(`No component in map: ` + componentName));
          }
        }
      }
    }

  } else {
    console.log(chalk.bold.redBright(`No custom components in ${sourceOfComponents}`));
  }
};

export const standardizeStr = (str, leng) => {
  for (let i = str.length; i <= leng; i++) {
    str += ' ';
  }
  return str;
};
