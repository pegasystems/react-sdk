export { default } from './SemanticLink';
