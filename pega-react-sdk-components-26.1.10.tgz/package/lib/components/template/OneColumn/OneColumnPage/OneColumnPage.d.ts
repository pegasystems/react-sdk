import type { GenAICoach } from '../../../widget/GenAICoach/GenAICoach.types';
import type { PConnProps } from '../../../../types/PConnProps';
interface OneColumnPageProps extends PConnProps {
    coaches?: GenAICoach[];
    localeReference?: string;
}
export default function OneColumnPage(props: OneColumnPageProps): string | number | bigint | boolean | import("react").JSX.Element | Iterable<import("react").ReactNode> | Promise<string | number | bigint | boolean | import("react").ReactPortal | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | Iterable<import("react").ReactNode> | null | undefined> | null | undefined;
export {};
//# sourceMappingURL=OneColumnPage.d.ts.map