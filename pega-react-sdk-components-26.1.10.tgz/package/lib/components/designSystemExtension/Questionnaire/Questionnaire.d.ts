import type { QuestionnaireProps } from '../GenAICoachContent/GenAICoach.types';
export default function Questionnaire(props: QuestionnaireProps): import("react").JSX.Element | null;
//# sourceMappingURL=Questionnaire.d.ts.map