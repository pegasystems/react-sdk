import { PConnProps } from '../../../types/PConnProps';
interface OperatorProps extends PConnProps {
    label: string;
    createDateTime: string;
    createLabel: string;
    createOperator: {
        userName: string;
        userId: string;
    };
    updateDateTime: string;
    updateLabel: string;
    updateOperator: {
        userName: string;
        userId: string;
    };
    displayLabel?: any;
}
export default function Operator(props: OperatorProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Operator.d.ts.map