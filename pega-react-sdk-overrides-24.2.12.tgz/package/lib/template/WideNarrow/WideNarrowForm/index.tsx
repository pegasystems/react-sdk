export { default } from './WideNarrowForm';
