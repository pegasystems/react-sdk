import type { PropsWithChildren } from 'react';
import type { PConnProps } from '../../../../types/PConnProps';
import './NarrowWideForm.css';
interface NarrowWideFormProps extends PConnProps {
}
export default function NarrowWideForm(props: PropsWithChildren<NarrowWideFormProps>): import("react").JSX.Element;
export {};
//# sourceMappingURL=NarrowWideForm.d.ts.map