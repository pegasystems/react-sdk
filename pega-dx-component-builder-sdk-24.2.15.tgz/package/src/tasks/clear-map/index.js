
import fs from 'fs';
import path from 'path';
import { join } from 'path';
import chalk from 'chalk';

import { clearComponentMap  } from '../map/map.js';
import { showVersion } from '../../util.js';


export default async options => {
  showVersion();

  await clearComponentMap();

  console.log(chalk.bold.green("Clear component map"));
  
};
