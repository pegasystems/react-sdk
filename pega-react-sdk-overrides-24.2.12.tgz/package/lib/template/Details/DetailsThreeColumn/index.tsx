export { default } from './DetailsThreeColumn';
