export { default } from './SimpleTableSelect';
//# sourceMappingURL=index.d.ts.map