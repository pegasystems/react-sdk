/**
 * Subscribes to the PCore store and returns formatted validation error messages
 * for the given itemKey. Reacts to any ADD_MESSAGES / CLEAR_MESSAGES dispatch
 * (blur, tab, submit, etc.) so the banner appears and clears in real time.
 */
export declare function useValidationBanner(itemKey: string): string[];
//# sourceMappingURL=useValidationBanner.d.ts.map