export declare function getAllFields(pConnect: any): any[];
export declare function filterForFieldValueList(fields: any[]): {
    id: any;
    name: any;
    value: any;
}[];
/**
 * Determine if the current view is the view of the case step/assignment.
 * @param {Function} pConnect PConnect object for the component
 */
export declare function getIsAssignmentView(pConnect: any): boolean;
/**
 * A hook that gets the instructions content for a view.
 * @param {Function} pConnect PConnect object for the component
 * @param {string} [instructions="casestep"] 'casestep', 'none', or the html content of a Rule-UI-Paragraph rule (processed via core's paragraph annotation handler)
 */
export declare function getInstructions(pConnect: any, instructions?: string): string | undefined;
/**
 * Gets the message type for instructions to determine how they should be displayed.
 * @param {string | object | undefined | null} instructions The instructions object (from paragraph processing)
 * @returns {string | undefined} The message type from the instructions object (e.g., 'Caution', 'Information', 'Good'), or undefined if not available
 */
export declare function getInstructionsType(instructions: any): string | undefined;
/**
 * Gets the dismissBanner flag from instructions to determine if the banner can be dismissed.
 * @param {string | object | undefined | null} instructions The instructions object (from paragraph processing)
 * @returns {boolean} Whether the banner can be dismissed
 */
export declare function getDismissBanner(instructions: any): boolean;
/**
 * Maps instructions type to banner variant for consistent styling
 * @param {string | undefined} instructionsType - The type of instructions (Caution, Information, Good)
 * @returns {'warning' | 'info' | 'success'} The corresponding banner variant
 */
export declare function mapInstructionsTypeToBannerVariant(instructionsType: string | undefined): 'warning' | 'info' | 'success';
//# sourceMappingURL=template-utils.d.ts.map