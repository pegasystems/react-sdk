export { default } from './WideNarrow';
//# sourceMappingURL=index.d.ts.map