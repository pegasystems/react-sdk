import type { ReactElement, ReactNode } from 'react';
import type { GenAICoach } from '../widget/GenAICoach/GenAICoach.types';
import type { UtilitiesLayoutProps } from '../designSystemExtension/GenAICoachContent/GenAICoach.types';
export declare function prepareCaseSummaryData(caseSummaryRegion: any, portalSpecificVisibilityChecker?: any): {
    primarySummaryFields: any;
    secondarySummaryFields: any;
};
export declare const filterUtilities: (utils: ReactNode) => any;
/**
 * Agent props for the agents configured on a landing page. As in the Constellation page templates, the page's locale
 * reference is the conversation context and the conversations are cached as the landing page's. Infinity runtime only
 * (isInfinityRuntime() is not in the 4.1 typings).
 */
export declare const usePageGenAICoach: (getPConnect: () => typeof PConnect, coaches?: GenAICoach[], localeReference?: string) => {
    loading: boolean;
    messages: never[];
    coachOptions: never[];
    onCoachChange: () => void;
    onSend: () => void;
    onOpen: () => void;
    initialSuggestedMessages: never[];
    suggestions: undefined;
    error: string;
    onStateChange: (() => void) | undefined;
    guidedMode: boolean;
} | {
    loading: string | boolean;
    enableStreaming: boolean;
    messages: import("../designSystemExtension/GenAICoachContent/GenAICoach.types").GenAIMessageProps[];
    coachOptions: import("../designSystemExtension/GenAICoachContent/GenAICoach.types").MenuItems;
    onCoachChange: (id: string) => void;
    onSend: (sendItem: import("../designSystemExtension/GenAICoachContent/GenAICoach.types").SendMessageProps) => Promise<void>;
    onOpen: () => void;
    initialSuggestedMessages: import("../designSystemExtension/GenAICoachContent/GenAICoach.types").MessageProps[];
    suggestions: import("../designSystemExtension/GenAICoachContent/GenAICoach.types").MenuItems;
    error: string;
    guidedMode: boolean;
    onStateChange: ((state: import("../designSystemExtension/GenAICoachContent/GenAICoach.types").State) => void) | undefined;
    onLayoutChange: (inFullPageArg: boolean) => void;
    actions: import("../designSystemExtension/GenAICoachContent/GenAICoach.types").ActionsProps;
    onNewChat: (() => void) | undefined;
    conversationHistory: {
        error: string | undefined;
        loading: boolean;
        data: {
            id: string;
            section: string;
            conversations: {
                id: string;
                title: string;
            }[];
        }[];
        onDismiss: () => void;
        onItemClick: (conversationId: string) => void;
        loadMore: () => void;
        selectedItemId: string;
    } | undefined;
    onAddAttachment: ((files: File[]) => void) | undefined;
    attachments: import("../designSystemExtension/GenAICoachContent/GenAICoach.types").FileItemProps[];
    attachmentsError: string;
    draftMessage: string;
    conversationError: string;
    onStop: (() => void) | undefined;
    isCreatingConversation: boolean;
    salutation: string | undefined;
    questionnaireData: import("../designSystemExtension/GenAICoachContent/GenAICoach.types").QuestionnaireConfig | undefined;
    onQuestionnaireDismiss: () => void;
} | undefined;
/**
 * Renders a landing page with its utilities column at the end, as the Cosmos page templates do with their
 * `utilities` slot; below the md breakpoint the column follows the page. A page without agents is returned unchanged.
 */
export declare const withPageUtilities: (page: ReactNode, genAICoachProps?: UtilitiesLayoutProps["genAICoachProps"]) => string | number | bigint | boolean | import("react").JSX.Element | Iterable<ReactNode> | Promise<string | number | bigint | boolean | import("react").ReactPortal | ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | Iterable<ReactNode> | null | undefined> | null | undefined;
//# sourceMappingURL=utils.d.ts.map