export { default } from './PromotedFilters';
