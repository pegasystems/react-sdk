import { PConnFieldProps } from '../../../types/PConnProps';
interface CurrrencyProps extends PConnFieldProps {
    currencyISOCode?: string;
    allowDecimals: boolean;
}
export default function Currency(props: CurrrencyProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Currency.d.ts.map