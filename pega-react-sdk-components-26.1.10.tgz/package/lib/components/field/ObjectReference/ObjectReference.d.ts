import type { PConnFieldProps } from '../../../types/PConnProps';
interface ObjectReferenceProps extends Omit<PConnFieldProps, 'value'> {
    getPConnect: any;
    displayMode: string;
    allowAndPersistChangesInReviewMode: any;
    allowCreatingRecords?: boolean;
    targetObjectType: any;
    mode: string;
    parameters: object;
    hideLabel: boolean;
    inline: boolean;
    showPromotedFilters: boolean;
    additionalFields: any;
    linkReference?: boolean;
    matchPosition?: string;
    children?: any;
}
export default function ObjectReference(props: ObjectReferenceProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=ObjectReference.d.ts.map