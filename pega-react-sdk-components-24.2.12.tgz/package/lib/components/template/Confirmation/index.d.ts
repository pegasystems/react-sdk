export { default } from './Confirmation';
//# sourceMappingURL=index.d.ts.map