export type CoachPConnectGetter = () => typeof PConnect;
export interface ParsedCaseLink {
    appName: string;
    caseTypeID: string;
    caseReferenceID: string;
    pegaServerUrl: string;
}
export interface ResolvedCaseLink extends ParsedCaseLink {
    insKey?: string;
    assignmentID?: string;
    className?: string;
}
export type CaseOpenStrategy = 'native' | 'webembed';
export declare const parseCaseLink: (href: string) => ParsedCaseLink | undefined;
export interface CaseKeysResult {
    pzInsKey?: string;
    className?: string;
}
export declare const hasCaseIdentifierQueryParams: (href: string) => boolean;
export declare const resolveCaseKeysFromLink: (parsed: ParsedCaseLink, originalHref: string) => ResolvedCaseLink;
export declare const resolveCaseOpenStrategy: (resolved: ResolvedCaseLink) => CaseOpenStrategy;
//# sourceMappingURL=agent-inline-edit-utils.d.ts.map