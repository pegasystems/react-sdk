import { PConnProps } from '../../../types/PConnProps';
interface FieldGroupTemplateProps extends PConnProps {
    referenceList?: any[];
    contextClass: string;
    renderMode?: string;
    heading?: string;
    lookForChildInConfig?: boolean;
    displayMode?: string;
    fieldHeader?: string;
    allowTableEdit: boolean;
    allowActions?: any;
}
export default function FieldGroupTemplate(props: FieldGroupTemplateProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=FieldGroupTemplate.d.ts.map