declare const getComponentStateOptions: (getPConnect: any) => {
    clearOnCancelForContext: any;
};
interface SearchCategory {
    selectedCategory: string;
}
interface SearchGroup {
    searchFields: unknown;
    activeGroupId: string;
}
declare const componentCachePersistUtils: {
    getComponentStateKey: (getPConnect: any, propertyName: string) => string;
    getComponentStateOptions: (getPConnect: any) => {
        clearOnCancelForContext: any;
    };
    setComponentCache: ({ cacheKey, state, options }: {
        cacheKey: string;
        state: SearchCategory | SearchGroup;
        options: ReturnType<typeof getComponentStateOptions>;
    }) => void;
};
export default componentCachePersistUtils;
//# sourceMappingURL=persistUtils.d.ts.map