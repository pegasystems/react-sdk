import type { MessageFeedbackProps } from '../GenAICoachContent/GenAICoach.types';
export default function GenAIMessageFeedback(props: MessageFeedbackProps): import("react").JSX.Element;
//# sourceMappingURL=GenAIMessageFeedback.d.ts.map