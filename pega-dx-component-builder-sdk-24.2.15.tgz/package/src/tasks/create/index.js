import path from 'path';
import { URL, fileURLToPath } from 'url';
import fs from 'fs';
import { promisify } from 'util';
import { join } from 'path';

import inquirer from 'inquirer';
import ncp from 'ncp';
import chalk from 'chalk';

import { checkPathAccess,
  showVersion,
  getFramework} from '../../util.js';
import { CATEGORY_CONSTELLATION, CATEGORY_CUSTOM,
  SDK_CONFIG_JSON_FILENAME,
  DXCB_CONFIG,
  DXCB_COMPONENT_DEFAULTS,
  CUSTOM_TEMPLATES,
  CUSTOM_TEMPLATE_PATH } from '../../constants.js';



export const DXCB_CONFIG_INTERNAL_JSON_FILENAME = 'src/dxcb.config.json';

const pegaConfigJsonPath = path.join(path.resolve(), SDK_CONFIG_JSON_FILENAME);
const pegaConfigInternalJsonPath = path.join(path.resolve(), DXCB_CONFIG_INTERNAL_JSON_FILENAME);

import {
  convertIntoPascalCase,
  convertIntoKebabCase,
  compileMustacheTemplate,
  getComponentDirectoryPath,
  getPegaConfig,
  getComponents,
  getComponentDefaults,
  sanitize,
  validateSemver
} from '../../util.js';
import { COMPONENT_SCHEMA } from '../../constants.js';

const copy = promisify(ncp);

const copyComponentTemplate = async options => {
  if (options.targetDirectory) {
    return copy(options.templateDirectory, options.targetDirectory, {
      clobber: false
    });
  }
  else {
    return copy(options.templateDirectoryConstellation, options.targetDirectoryConstellation, {
      clobber: false,
      filter: (fileName) => {
        // filter out the file config.json or config.json.mustache
        if (fileName.indexOf("config.json") >= 0) return false;
        else return true;
      }
    });
  }

};

export const compileMustacheTemplates = async (
  componentDirectory,
  {
    componentKey,
    componentName,
    componentLabel,
    library,
    version,
    type,
    subtype,
    description,
    organization,
    allowedApplications
  }, componentType
) => {
  const files = fs.readdirSync(componentDirectory);
  const componentClassName = convertIntoPascalCase(componentKey);

  const isTemplate = type === 'Template';
  const isBool = subtype === 'Boolean';
  const isPhone = subtype === 'Phone';

  if (Array.isArray(subtype) && subtype.length === 1) {
    subtype = subtype.toString();
  }

  let mustacheSubType = subtype;
  let fileSubType = subtype;

  // overrides
  if (typeof mustacheSubType === 'string') {
    // eslint-disable-next-line default-case
    switch (mustacheSubType) {
      case 'FORM-region':
        mustacheSubType = 'FORM';
        fileSubType = 'FORM';
        break;
      case 'DETAILS-region':
        mustacheSubType = 'DETAILS';
        fileSubType = 'DETAILS';
        break;
      case 'Text-Input':
        mustacheSubType = 'Text';
        fileSubType = 'Text';
        break;
      case 'Picklist-Autocomplete':
        mustacheSubType = 'Picklist';
        break;
      case 'Picklist-RadioButtons':
        mustacheSubType = 'Picklist';
        break;
    }
  }

  const isPicklist = subtype === 'Picklist';

  if (allowedApplications.trim() === '') {
    allowedApplications = [];
  } else {
    if (allowedApplications.indexOf(',') !== -1) {
      allowedApplications = allowedApplications.split(',');
    }
    allowedApplications = [].concat(allowedApplications);
  }

  const componentKeyKebab = convertIntoKebabCase(convertIntoPascalCase(componentKey));
  const framework = await getFramework();

  allowedApplications = allowedApplications.filter(el => !!el.trim()).map(el => el.trim());
  files.forEach(file => {

    const filePath = path.join(componentDirectory, file);

    const output = compileMustacheTemplate(filePath, {
      COMPONENT_KEY: componentKey,
      COMPONENT_NAME: componentName,
      COMPONENT_LABEL: componentLabel,
      COMPONENT_CLASS_NAME: componentClassName,
      COMPONENT_CLASS_NAME_KEBAB: componentKeyKebab,
      ORGANIZATION: organization,
      VERSION: version,
      LIBRARY: library,
      ALLOWEDAPPS: JSON.stringify(allowedApplications),
      TYPE: type,
      SUB_TYPE: JSON.stringify(mustacheSubType),
      DESCRIPTION: description || componentLabel,
      IS_TEMPLATE: isTemplate,
      IS_PICKLIST: isPicklist,
      IS_BOOLEAN: isBool,
      IS_PHONE: isPhone
    });
    fs.writeFileSync(filePath, output);

    switch (framework) {
      case "SDK-React":
        fs.renameSync(filePath, filePath.replace('.mustache', ''));
        break;
      case "SDK-Angular":
        let newFilePath = filePath.replace('.mustache', '');
        if (componentType === "component") {
          const typeAng = convertIntoKebabCase(convertIntoPascalCase(fileSubType)).concat(".component");
          newFilePath = newFilePath.replace(typeAng, componentKeyKebab.concat(".component"));
        }

        fs.renameSync(filePath, newFilePath);
        break;
      case "SDK-WebComponents":
        fs.renameSync(filePath, filePath.replace('.mustache', ''));
        break;
    }


  });
};





export const validateCompile = async (
  {
    library,
    organization,
    componentName,
    componentLabel,
    version,
    framework,
    type,
    subtype,
    description,
    allowedApplications
  },
  options,
  onlyCompanion = false
) => {

  let sSubType = subtype;
  if (Array.isArray(subtype)) {
    sSubType = subtype.join("-");
  }

  const typeLC = type.toLowerCase();

  await checkPathAccess(pegaConfigInternalJsonPath);

  framework = await getFramework();

  let pegaConfig = await getPegaConfig();
  let templateParentDir = `./templates/${framework}`;
  if (pegaConfig[DXCB_CONFIG] &&
      pegaConfig[DXCB_CONFIG][CUSTOM_TEMPLATES] &&
      pegaConfig[DXCB_CONFIG][CUSTOM_TEMPLATES][CUSTOM_TEMPLATE_PATH] &&
      pegaConfig[DXCB_CONFIG][CUSTOM_TEMPLATES][CUSTOM_TEMPLATE_PATH] != "") {
    templateParentDir = pegaConfig[DXCB_CONFIG][CUSTOM_TEMPLATES][CUSTOM_TEMPLATE_PATH];
  }

  const templateDir = `${templateParentDir}/${typeLC}/${sSubType}`;
  const templateDirectory = fileURLToPath(new URL(templateDir, import.meta.url));

  const templateDirConstellation = `./templates/Constellation/${typeLC}/${sSubType}`;
  const templateDirectoryConstellation = fileURLToPath(new URL(templateDirConstellation, import.meta.url));

  const componentKey = `${organization}_${library}_${componentName}`;

  let targetDirectory = "";
  switch (framework) {
    case "SDK-React":
      targetDirectory = await getComponentDirectoryPath(join(typeLC, "/",componentKey));
      break;
    case "SDK-Angular":
      let componentKeyAng = convertIntoKebabCase(convertIntoPascalCase(componentKey));
      targetDirectory = await getComponentDirectoryPath(join(typeLC, "/",componentKeyAng));
      break;
    case "SDK-WebComponents":
      break;
  }

  //const targetDirectory = await getComponentDirectoryPath(join(typeLC, "/",componentKey));
  const targetDirectoryConstellation = await getComponentDirectoryPath(join(typeLC, "/",componentKey), CATEGORY_CONSTELLATION);

  const components = await getComponents(false, CATEGORY_CUSTOM, false);

  if (!onlyCompanion) {
    if (components.includes(componentKey)) {
      console.log(chalk.red(`${componentKey} component already exists in ${targetDirectory}`));

      let componentsConstellation = await getComponents(false, CATEGORY_CONSTELLATION, false);
      if (components.includes(componentKey)) {
        console.log(chalk.red(`${componentKey} associated component already exists in ${targetDirectoryConstellation}`));
      }

      return;
    }
    // test for constellation
    const componentsConstellation = await getComponents(false, CATEGORY_CONSTELLATION, false);
    if (componentsConstellation.includes(componentKey)) {
      console.log(chalk.red(`${componentKey} associated component already exists in ${targetDirectoryConstellation}`));
      return;
    }
  }
  else {
    // test for constellation
    const componentsConstellation = await getComponents(false, CATEGORY_CONSTELLATION, false);
    if (componentsConstellation.includes(componentKey)) {
      console.log(chalk.red(`${componentKey} associated component already exists in ${targetDirectoryConstellation}`));
      return;
    }
  }


  if (!onlyCompanion) {
    // component
    await copyComponentTemplate({
      ...options,
      targetDirectory,
      templateDirectory
    });
    await compileMustacheTemplates(targetDirectory, {
      componentKey,
      componentName,
      componentLabel,
      library,
      version,
      type,
      subtype,
      description,
      organization,
      allowedApplications
    }, "component");
  }

  // matching constellation
  await copyComponentTemplate({
    ...options,
    targetDirectoryConstellation,
    templateDirectoryConstellation
  });
  await compileMustacheTemplates(targetDirectoryConstellation, {
    componentKey,
    componentName,
    componentLabel,
    library,
    version,
    type,
    subtype,
    description,
    organization,
    allowedApplications
  }, "associated");

  if (!onlyCompanion) {
    console.log(chalk.green(`created ${componentKey} component in ${targetDirectory}`));
  }

  console.log(chalk.green(`created ${componentKey} associated component in ${targetDirectoryConstellation}`));

};

export default async options => {
  showVersion();

  const framework = await getFramework();

  if (options.params.length >= 12) {
    const type = options.params[3];
    const subtype = options.params[4];
    const componentName = options.params[5];
    const componentLabel = options.params[6];
    const version = options.params[7];
    const library = options.params[8];
    const allowedApplications = options.params[9];
    const description = options.params[10];
    const organization = options.params[11];

    await validateCompile(
      {
        componentName,
        componentLabel,
        library,
        version,
        framework,
        type,
        subtype,
        description,
        allowedApplications,
        organization
      },
      options
    );
  } else {

    await checkPathAccess(pegaConfigJsonPath);

    let data = fs.readFileSync(pegaConfigJsonPath, { encoding: 'utf8' });
    data = data && JSON.parse(data);

    if (!data[DXCB_CONFIG] || !data[DXCB_CONFIG][DXCB_COMPONENT_DEFAULTS]) {
      console.error(
        `${chalk.red.bold('ERROR')} Could not able find component defaults in config.json`
      );
      process.exit(1);
    }

    const componentData = data[DXCB_CONFIG][DXCB_COMPONENT_DEFAULTS];

    const { organization, library} = componentData;

    let componentDefaults = await getComponentDefaults();
    componentDefaults.library = library;


    const questions = [
      {
        name: 'type',
        type: 'rawlist',
        message: 'Enter type of component',
        default: componentDefaults.type,
        choices: COMPONENT_SCHEMA.type
      },
      {
        name: 'subtype',
        type: 'rawlist',
        message: 'Enter subtype of component',
        default: componentDefaults.subtype,
        choices: COMPONENT_SCHEMA.subtype.field,
        when(answers) {
          return answers.type === 'Field';
        }
      },
      {
        name: 'subtype',
        type: 'rawlist',
        message: 'Enter subtype of component',
        default: componentDefaults.subtype,
        choices: COMPONENT_SCHEMA.subtype.template,
        when(answers) {
          return answers.type === 'Template';
        }
      },
      {
        name: 'subtype',
        type: 'rawlist',
        message: 'Enter subtype of component',
        default: [componentDefaults.subtype || COMPONENT_SCHEMA.subtype.widget[0]],
        choices: COMPONENT_SCHEMA.subtype.widget,
        when(answers) {
          return answers.type === 'Widget';
        },
        validate: value => {
          /* value should not be empty */
          if (Array.isArray(value) && value.length) {
            return true;
          }
          return 'Please select subtype';
        }
      },
      {
        name: 'componentName',
        message: 'Enter component name (required, no spaces)',
        validate: value => {
          /* value should not be empty
          It should not have spaces
          It should not start with a number
          Only case-insensitive alphanumeric values are allowed
        */
          if (value && !/^\d/.test(value) && value === sanitize(value)) {
            return true;
          }
          return 'Only alphanumeric values are allowed, starting with alphabets';
        }
      },
      {
        name: 'componentLabel',
        message: 'Enter component label for display (required)',
        validate: value => {
          if (value) {
            return true;
          }
          return 'Please provide value for label';
        }
      },
      {
        name: 'version',
        message: 'Enter component version',
        default: componentDefaults.version,
        validate: value => {
          if (validateSemver(value)) {
            return true;
          }
          return 'Please provide semver compatible version e.g 0.0.1';
        }
      },
      {
        name: 'library',
        message: 'Enter library name (required)',
        default: componentDefaults.library,
        validate: value => {
          /* value should not be empty
            It should not have spaces
            It should not start with a number
            Only case-insensitive alphanumeric values are allowed
          */
          if (value && !/^\d/.test(value) && value === sanitize(value)) {
            return true;
          }
          return 'Only alphanumeric values are allowed, starting with alphabets';
        }
      },
      {
        name: 'allowedApplications',
        message: 'Please enter the application names to be supported (comma-separated). ',
        suffix: 'Keep empty for all applications'
      },
      {
        name: 'description',
        message: 'Enter description for the component (defaults to label)',
        default: componentDefaults.description,
        /* if left blank and no defaults, mustache will use componentLabel, because description is used in app studio and
        shouldn't be blank */
      }
    ];

    await inquirer.prompt(questions).then(async answers => {
      const {
        componentName,
        componentLabel,
        library,
        version,
        framework,
        type,
        subtype,
        description,
        allowedApplications
      } = answers;
      await validateCompile(
        {
          componentName,
          componentLabel,
          library,
          version,
          framework,
          type,
          subtype,
          description,
          allowedApplications,
          organization
        },
        options
      );
    });
  }
};
