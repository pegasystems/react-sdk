import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../types/PConnProps';
interface CaseSummaryProps extends PConnProps {
}
export default function CaseSummary(props: PropsWithChildren<CaseSummaryProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=CaseSummary.d.ts.map