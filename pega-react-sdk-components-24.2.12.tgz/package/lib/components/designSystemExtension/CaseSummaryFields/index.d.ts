export { default } from './CaseSummaryFields';
//# sourceMappingURL=index.d.ts.map