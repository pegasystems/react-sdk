import type { PConnFieldProps } from '../../../types/PConnProps';
interface CheckboxProps extends Omit<PConnFieldProps, 'value'> {
    value?: boolean;
    caption?: string;
    trueLabel?: string;
    falseLabel?: string;
    selectionMode?: string;
    datasource?: any;
    selectionKey?: string;
    selectionList?: any;
    primaryField: string;
    readonlyContextList: any;
    referenceList: string;
    variant?: string;
    hideFieldLabels: boolean;
    additionalProps: any;
    imagePosition: string;
    imageSize: string;
    showImageDescription: string;
    renderMode: string;
    image: string;
    showFieldMessage?: boolean;
    messageConfig?: {
        content?: string;
        visibility?: boolean;
    };
}
export default function CheckboxComponent(props: CheckboxProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=Checkbox.d.ts.map