export type StreamingContextProps = {
    isStreamingMessage?: boolean;
    isStreamingInProgress?: boolean;
};
/** Metadata Context */
export declare const StreamingContext: import("react").Context<StreamingContextProps | undefined>;
//# sourceMappingURL=StreamingContext.d.ts.map