import { ESLint } from 'eslint';
import chalk from 'chalk';
import { getPegaConfig } from '../../util.js'
import { DXCB_CONFIG, DXCB_COMPONENT_DEFAULTS, LINT_SETTING_KEY, LINT_OFF, LINT_SHOW, LINT_BLOCK, LINT_DEFAULT } from '../../constants.js';

//  lintSettings immported from constants.js: a set of the expected values of lint setting from sdk-config.json
//  LINT_OFF: don't run lint
//  LINT_SHOW: run lint, show results, but don't block processing from continuing if there are lint errors/warnings
//  LINT_BLOCK: run lint, show results, block processing from continuing if there are lint errors/warnings

const lintSettings = new Set([LINT_OFF, LINT_SHOW, LINT_BLOCK]);

export const lintComponent = async (dirToLint) => {
  // get setting from sdk-config. If not found or unexpected value, default to LINT_DEFAULT
  const pegaConfig = await getPegaConfig();
  let lintSetting = pegaConfig[DXCB_CONFIG][DXCB_COMPONENT_DEFAULTS][LINT_SETTING_KEY];

  // Check to see if lintSetting is an expected value. Show error if unexpected value encountered
  if (!lintSettings?.has(lintSetting)) {
    console.log(chalk.red(`Invalid or missing ${LINT_SETTING_KEY}: ${lintSetting}. Using \"${LINT_BLOCK}\".`));
    lintSetting = LINT_DEFAULT;
  }

  // console.log("in dx-component-builder-sdk: lintComponent - dirToLint: " + dirToLint);
  // console.log(chalk.green(` linting ${dirToLint} - setting: ${lintSetting}`));

  let resultText = undefined;

  if (lintSetting !== LINT_OFF) {
    // 1. Create an instance.
    const eslint = new ESLint();

    // 2. Lint file(s) .
    const results = await eslint.lintFiles([dirToLint]);

    // 3. Format results.
    const formatter = await eslint.loadFormatter("stylish");
    resultText = formatter.format(results);

    // 4. Output results.
    // console.log("lint results[");
    // results.forEach(function (result) { console.log(JSON.stringify(result)) });
    // console.log("]");
    // console.log("lint resultText[" + resultText + "]");

    if (resultText.length > 0) {
      if (lintSetting === LINT_SHOW) {
        // Config setting says to allow processing to continue. So, show lint output but continue
        console.log(chalk.yellow(`  Lint: `));
        console.log(`${resultText}`);
        console.log(chalk.yellow(`  Continuing...`));
      } else {
        // Config setting (at this point, assumed to be "block") says to NOT allow processing to continue.
        //  So, throw error!
        console.log(chalk.red(`  Lint errors/warnings. Processing blocked.`));
        throw new Error( "Lint:\n" + resultText );
      }
    }
  } else {
    console.log(chalk.green(`  Lint is off.`));
  }
  // Indicate linting is complete
  if ((lintSetting !== LINT_OFF) && resultText) {
    console.log(chalk.green(` linting complete...`));
  }

};

// inspired by https://eslint.org/docs/latest/developer-guide/nodejs-api

export default lintComponent;
