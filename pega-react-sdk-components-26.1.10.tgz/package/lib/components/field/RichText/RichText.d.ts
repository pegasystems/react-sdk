import type { PConnFieldProps } from '../../../types/PConnProps';
import './RichText.css';
interface RichTextProps extends PConnFieldProps {
    additionalProps?: object;
}
export default function RichText(props: RichTextProps): any;
export {};
//# sourceMappingURL=RichText.d.ts.map