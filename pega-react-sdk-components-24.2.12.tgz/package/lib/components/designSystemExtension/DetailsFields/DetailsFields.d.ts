interface DetailsFieldsProps {
    fields: any[];
}
export default function DetailsFields(props: DetailsFieldsProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=DetailsFields.d.ts.map