import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../../types/PConnProps';
interface OneColumnProps extends PConnProps {
}
export default function OneColumn(props: PropsWithChildren<OneColumnProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=OneColumn.d.ts.map