export { default } from './DynamicTabs';
