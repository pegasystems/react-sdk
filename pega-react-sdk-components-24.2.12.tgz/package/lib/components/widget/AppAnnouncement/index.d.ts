export { default } from './AppAnnouncement';
//# sourceMappingURL=index.d.ts.map