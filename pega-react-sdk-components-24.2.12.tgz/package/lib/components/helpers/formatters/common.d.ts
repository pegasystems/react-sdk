export declare function getLocale(locale?: string): string | undefined;
export declare function getCurrentTimezone(timezone?: string): string;
//# sourceMappingURL=common.d.ts.map