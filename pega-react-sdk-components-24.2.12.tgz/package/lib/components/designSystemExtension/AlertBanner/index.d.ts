export { default } from './AlertBanner';
//# sourceMappingURL=index.d.ts.map