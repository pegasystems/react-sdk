import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../types/PConnProps';
import './AppShell.css';
interface AppShellProps extends PConnProps {
    showAppName: boolean;
    pages: {
        pxPageViewIcon: string;
        pyClassName: string;
        pyLabel: string;
        pyRuleName: string;
        pyURLContent: string;
    }[];
    caseTypes?: object[];
    portalTemplate: string;
    portalName: string;
    portalLogo: string;
    navDisplayOptions: {
        alignment: string;
        position: string;
    };
    httpMessages: string[];
    pageMessages: string[];
}
export default function AppShell(props: PropsWithChildren<AppShellProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=AppShell.d.ts.map