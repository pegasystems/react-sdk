import type { PConnFieldProps } from '../../../types/PConnProps';
import './Location.css';
interface LocationProps extends PConnFieldProps {
    coordinates?: string;
    onlyCoordinates?: boolean;
    showMap?: boolean;
    showMapReadOnly?: boolean;
}
export default function Location(props: LocationProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=Location.d.ts.map