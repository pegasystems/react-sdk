import type { PConnFieldProps } from '../../../types/PConnProps';
interface DateProps extends PConnFieldProps {
    showFieldMessage?: boolean;
    messageConfig?: {
        content?: string;
        visibility?: boolean;
    };
    variant?: string;
}
export default function Date(props: DateProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=Date.d.ts.map