/// <reference types="react" />
declare const SimpleViewContainer: (props: any) => import("react").CElement<{
    getPConnect: () => import("@pega/pcore-pconnect-typedefs/interpreter/c11n-env").C11nEnv;
}, import("react").Component<{
    getPConnect: () => import("@pega/pcore-pconnect-typedefs/interpreter/c11n-env").C11nEnv;
}, any, any>> | null;
export declare const withSimpleViewContainerRenderer: (Component: any, options?: any) => (props: any) => import("react/jsx-runtime").JSX.Element;
export default SimpleViewContainer;
//# sourceMappingURL=SimpleView.d.ts.map