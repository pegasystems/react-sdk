import { type ReactNode } from 'react';
import type { PConnProps } from '../../../types/PConnProps';
import './NavBar.css';
interface NavBarProps extends PConnProps {
    appName?: string;
    pages?: any[];
    caseTypes: any[];
    pConn?: any;
    agent?: {
        id: string;
        name: string;
        icon: ReactNode;
        active: boolean;
        onClick: () => void;
    };
}
export default function NavBar(props: NavBarProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=NavBar.d.ts.map