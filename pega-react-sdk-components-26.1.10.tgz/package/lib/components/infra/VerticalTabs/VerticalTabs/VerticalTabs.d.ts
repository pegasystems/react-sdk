import React from 'react';
interface VerticalTabsProps {
    tabconfig: any[];
}
export default function VerticalTabs(props: VerticalTabsProps): React.JSX.Element;
export {};
//# sourceMappingURL=VerticalTabs.d.ts.map