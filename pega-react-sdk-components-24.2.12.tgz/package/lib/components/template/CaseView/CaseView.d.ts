import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../types/PConnProps';
interface CaseViewProps extends PConnProps {
    icon: string;
    subheader: string;
    header: string;
    showIconInHeader: boolean;
    caseInfo: any;
    lastUpdateCaseTime: any;
}
export default function CaseView(props: PropsWithChildren<CaseViewProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=CaseView.d.ts.map