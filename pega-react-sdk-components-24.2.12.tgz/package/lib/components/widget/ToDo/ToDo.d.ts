import { PConnProps } from '../../../types/PConnProps';
import './ToDo.css';
interface ToDoProps extends PConnProps {
    datasource?: any;
    myWorkList?: any;
    caseInfoID?: string;
    headerText?: string;
    itemKey?: string;
    showTodoList?: boolean;
    type?: string;
    context?: string;
    isConfirm?: boolean;
}
export default function ToDo(props: ToDoProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=ToDo.d.ts.map