import path from 'path';
import fs from 'node:fs';

import chalk from 'chalk';
import inquirer from 'inquirer';

import { checkPathAccess, showVersion } from '../../util.js';
import { TOKEN_PATH, TOKEN_URL_V1, AUTHORIZE_URL_V1, LP_TOKEN_URL, LP_AUTHORIZE_URL, SDK_CONFIG_JSON_FILENAME,
  SERVER_CONFIG, DXCB_CONFIG, DXCB_PUBLISH_ACCESS, SERVER_TYPE, SERVER_REST_URL, LP_SERVER_REST_URL } from '../../constants.js';

import { getAuthQuestions } from './helper.js';
import PegaAuth from '../../auth.js';

const pegaConfigJsonPath = path.join(path.resolve(), SDK_CONFIG_JSON_FILENAME);
let server = null;

const generateAccessToken = async config => {

  let authSuccess = false;
  const { serverType, authService, isolationId, grantType, clientId, clientSecret, user, password, legacyTLS } = config;
  // Try to gracefully deal with missing trailing slashes for server (and later conditionally for redirectUri)
  const server = config.server.endsWith('/') ? config.server : `${config.server}/`;

  return new Promise((resolve, reject) => {
    const sTokenUri = `${server}${serverType === 'infinity' ? TOKEN_URL_V1 : LP_TOKEN_URL}`;
    const sAuthorizeUri = `${server}${serverType === 'infinity' ? AUTHORIZE_URL_V1 : LP_AUTHORIZE_URL}`;
    // console.log(`grantType: ${config.grantType}`);
    const browserAuthSuccessMarkup = `<div style="width: 300px; padding: 10px;">
    <svg xmlns="http://www. w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 311 68" version="1.1">
    <title>Logo</title>
    <defs/>
    <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
        <g id="Logo">
            <g id="pega_logo_horizontal_positive_rgb">
                <path d="M136.36,17.098 L136.173,17.009 C136.154,16.998 133.96,16.01 132.245,17.815 L132.026,18.046 L135.539,19.768 L136.36,17.098 Z M152.441,36.389 C152.441,36.389 150.91,39.13 150.224,40.143 C149.535,41.164 147.38,41.798 145.517,40.908 C144.665,40.503 136.694,35.854 133.644,36.12 C118.205,37.466 113.999,31.105 113.503,30.527 C113.005,29.949 112.077,30.218 112.74,31.355 C116.127,37.163 126.15,39.856 126.15,39.856 C128.771,46.172 129.085,50.597 129.085,50.597 C126.489,48.574 123.687,46.869 120.714,45.453 C112.768,40.121 100.329,33.518 83.207,29.379 C84.191,15.797 91.044,-3.837 123.092,0.806 C123.092,0.806 129.522,1.86 133.809,4.824 C133.809,4.824 132.779,5.904 131.425,7.256 C130.071,8.605 131.569,9.471 131.569,9.471 L138.338,14.792 C138.417,17.607 138.533,18.396 140.651,20.944 C142.769,23.487 151.004,32.112 152.081,33.266 C153.329,34.6 152.441,36.389 152.441,36.389 Z M78.633,9.915 C76.938,16.897 77.068,23.049 77.939,28.221 C76.33,27.901 74.697,27.594 73.014,27.32 C37.94,21.612 27.361,38.899 31.455,52.916 C19.86,57.274 8.963,62.263 0.214,67.162 C13.98,34.146 43.896,5.087 69.145,1.268 C77.389,0.181 79.708,5.529 78.633,9.915 L78.633,9.915 Z" id="Fill-1" fill="#1F2555"/>
                <path d="M83.492,40.09 C97.157,39.01 110.054,40.381 120.713,45.453 C112.768,40.121 100.329,33.518 83.206,29.379 C82.864,34.111 83.23,38.107 83.492,40.09 Z M81.52,40.262 C66.209,41.723 48.105,46.663 31.455,52.916 C27.361,38.899 37.941,21.612 73.014,27.32 C74.697,27.594 76.33,27.901 77.938,28.221 C78.77,33.166 80.276,37.228 81.52,40.262 L81.52,40.262 Z" id="Fill-2" fill="#00A6A7"/>
                <path d="M286.63,35.039 L291.379,23.446 L296.129,35.039 L286.63,35.039 Z M287.854,14 L272.536,50 L280.553,50 L283.819,41.985 L298.938,41.985 L302.204,50 L310.427,50 L295.108,14 L287.854,14 Z M188.647,26.704 C188.647,29.787 186.335,32.153 182.375,32.153 L176.1,32.153 L176.1,21.149 L182.219,21.149 C186.181,21.149 188.647,23.052 188.647,26.601 L188.647,26.704 Z M182.889,14 L168.18,14 L168.18,50 L176.1,50 L176.1,39.2 L182.115,39.2 C190.19,39.2 196.673,34.878 196.673,26.547 L196.673,26.444 C196.673,19.09 191.48,14 182.889,14 Z M239.764,18.02 C235.989,21.708 234.075,26.376 234.075,31.896 C234.075,37.421 235.953,42.054 239.663,45.675 C243.366,49.292 248.022,51.123 253.503,51.123 C259.992,51.123 265.064,49.159 268.587,45.284 L268.769,45.08 L268.769,28.556 L253.112,28.556 L253.112,35.244 L261.279,35.244 L261.279,41.993 C259.164,43.252 256.525,43.891 253.429,43.891 C250.221,43.891 247.454,42.792 245.203,40.62 C242.958,38.458 241.819,35.527 241.819,31.926 C241.819,28.322 242.992,25.379 245.304,23.18 C247.624,20.972 250.538,19.852 253.966,19.852 C255.769,19.852 257.366,20.074 258.711,20.512 C259.973,20.922 261.251,21.667 262.517,22.712 L266.897,17.183 C264.586,15.147 260.427,12.467 253.503,12.467 C248.162,12.467 243.539,14.336 239.764,18.02 Z M210.336,35.604 L225.842,35.604 L225.842,28.556 L210.336,28.556 L210.336,21.042 L229.623,21.042 L229.623,14 L202.466,14 L202.466,50 L229.879,50 L229.879,42.955 L210.336,42.955 L210.336,35.604 L210.336,35.604 Z" id="Fill-3" fill="#1F2555"/>
            </g>
        </g>
    </g>
    </svg>
    </div>
    <div style="font-size: 2em; font-family: Arial; padding: 10px">
    Authentication is complete!!
    </div>
    <div style="font-size: 13m; font-family: Arial; padding: 10px">
    This browser tab or window may be closed.
    </div>
    <div style="padding: 10px;">
    </div>`;

    const authCodeConfig = grantType === 'authCode' ? {
      authorizeUri: sAuthorizeUri,
      redirectUri: config.redirectUri.endsWith('/') ? config.redirectUri : `${config.redirectUri}/`,
      cert: config.cert,
      key: config.key,
      winTitle: 'DX Component Dev',
      winBodyHtml: browserAuthSuccessMarkup
    } : {};

    // Build auth config structure
    const authConfig = {
      serverType: serverType,
      authService: authService,
      grantType: grantType,
      tokenUri: sTokenUri,
      clientId: clientId,
      clientSecret: clientSecret,
      ignoreInvalidCerts: true,
      useNodeFetch:true,
      ...authCodeConfig
    };
    if (serverType === 'infinity') {
      if (grantType !== 'clientCreds' && user && password) {
        authConfig.userIdentifier = user;
        authConfig.password = Buffer.from(password).toString('base64');
      }
    }
    if (legacyTLS) {
      authConfig.legacyTLS = true;
    }
    if (serverType === 'launchpad') {
      authConfig.isolationId = isolationId;
      authConfig.noPKCE = true;
    }

    try {
      const auth = new PegaAuth(authConfig);
      if (grantType === 'authCode') {
        console.log(`${chalk.green('Awaiting authorization to complete (Ctrl-C to exit).  You may need to enter credentials within your default browser.')}`);
      }
      // console.log(`authConfig: ${JSON.stringify(authConfig)}`);

      auth.login()
        .then((token) => {
          if (token?.token_type) {
            fs.writeFile(TOKEN_PATH, JSON.stringify(token), err => {
              if (err) {
                console.error(err);
                return reject(authSuccess);
              }
              console.log(`${chalk.bold.green('Authenticated successfully !!')}`);
              authSuccess = true;
              return resolve(authSuccess);
            });
          } else {
            console.log(`${chalk.bold.red('Authentication failed:' + JSON.stringify(token.errors ? token.errors : token))}`);
            return reject(authSuccess);
          }
        })
        .catch((e) => {
          console.log(`${chalk.bold.red('Authentication failed:' + e)}`);
          return reject(authSuccess);
        });
    } catch(e) {
      console.log(`Authentication failed: Problem initializing OAuth library`);
      return reject(authSuccess);
    }
  });
};

export default async options => {

  let authOK = false;

  showVersion();

  await checkPathAccess(pegaConfigJsonPath);

  let cfgData = fs.readFileSync(pegaConfigJsonPath, { encoding: 'utf8' });
  let data = null;
  if (cfgData) {
    try {
      data = JSON.parse(cfgData);
    } catch (e) {
      const msg = `Invalid JSON within ${SDK_CONFIG_JSON_FILENAME}`;
      console.log(`${chalk.red(msg)}`);
      process.exit(1);
    }
  }

  if (!data[SERVER_CONFIG] || !data[SERVER_CONFIG][SERVER_REST_URL]) {
    console.error(
      `${chalk.red.bold('ERROR')} ${SERVER_CONFIG}.${SERVER_REST_URL} property not found within ${SDK_CONFIG_JSON_FILENAME}`
    );
    process.exit(1);
  }

 // Note: serverConfig below is actually dxcbConfig.
  const serverConfig = data[DXCB_CONFIG][DXCB_PUBLISH_ACCESS];
  serverConfig.serverType = data[SERVER_CONFIG][SERVER_TYPE] || "infinity";
  serverConfig.server = data[SERVER_CONFIG][serverConfig.serverType === "infinity" ? SERVER_REST_URL : LP_SERVER_REST_URL];
  serverConfig.authService = data.authConfig?.authService || 'pega';
  const isPwdNonEmpty = serverConfig['password'] ? true : false;
  if( data[SERVER_CONFIG]['legacyTLS'] ) {
    serverConfig.legacyTLS = true;
  }

  const questions = await getAuthQuestions(serverConfig);
  const answers = await inquirer.prompt(questions);
  const aProps = ['serverType','server','isolationId','clientId','grantType','clientSecret','user','password'];
  const isLaunchPad = answers.serverType === "launchpad";
  let bWriteUpdate = false;
  for (let i = 0; i < aProps.length; i += 1) {
    const prop = aProps[i];
    const configValue = serverConfig[prop];
    const answerValue = answers[prop];
    // Treat an empty serverConfig property value as same as an undefined answer response
    if (configValue !== answerValue && !(configValue === '' && answerValue === undefined)) {
      // console.log(`property ${prop} changed from ${configValue} to ${answerValue}`);
      serverConfig[prop] = answerValue;
      if (prop !== 'password' || isPwdNonEmpty) {
        bWriteUpdate = true;
      }
      if (prop === 'server') {
        data[SERVER_CONFIG][isLaunchPad ? LP_SERVER_REST_URL : SERVER_REST_URL] = answers.server;
      }
    }
  }

  try {
    authOK = await generateAccessToken(serverConfig);
  } catch (e) {
    console.log(`${chalk.bold.red('Authentication failed:' + JSON.stringify(e))}`);
  }

  delete serverConfig.serverType;
  delete serverConfig.server;
  if( serverConfig.legacyTLS ) {
    delete serverConfig.legacyTLS;
  }

  if (authOK & bWriteUpdate) {
    // Don't write password value (unless it already had a value)
    if (!isPwdNonEmpty) {
      serverConfig['password'] = '';
    }
    console.log(`${chalk.green('Writing updated config...')}`);
    let updCfg = null;
    try {
      updCfg = JSON.stringify(data, null, 2);
      // console.log(`updated config: ${updCfg}`);
      fs.writeFileSync(pegaConfigJsonPath, updCfg, err => {
        if (err) throw err;
      });
    } catch (e) {

    }
  }

  process.exit();

};
