export { default } from './ModalViewContainer';
//# sourceMappingURL=index.d.ts.map