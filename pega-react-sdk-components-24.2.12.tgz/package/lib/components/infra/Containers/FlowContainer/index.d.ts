export { default } from './FlowContainer';
//# sourceMappingURL=index.d.ts.map