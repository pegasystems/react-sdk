import type { PConnFieldProps } from '../../../types/PConnProps';
interface AutoCompleteProps extends PConnFieldProps {
    displayMode?: string;
    deferDatasource?: boolean;
    datasourceMetadata?: any;
    status?: string;
    onRecordChange?: any;
    additionalProps?: object;
    listType: string;
    parameters?: any;
    datasource: any;
    columns: any[];
    showFieldMessage?: boolean;
    messageConfig?: {
        content?: string;
        visibility?: boolean;
    };
    variant?: string;
    showCreateNew?: boolean;
    onCreateNew?: () => void;
    createNewLabel?: string;
    createNewRecord?: () => Promise<unknown>;
    contextClass?: string;
    referenceType?: string;
    allowCreatingRecords?: boolean;
}
export default function AutoComplete(props: AutoCompleteProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=AutoComplete.d.ts.map