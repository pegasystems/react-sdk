import { PConnProps } from '../../../../types/PConnProps';
interface DetailsTwoColumnProps extends PConnProps {
    showLabel: boolean;
    label: string;
    showHighlightedData: boolean;
}
export default function DetailsTwoColumn(props: DetailsTwoColumnProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=DetailsTwoColumn.d.ts.map