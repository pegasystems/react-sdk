export { default } from './SimpleTableManual';
