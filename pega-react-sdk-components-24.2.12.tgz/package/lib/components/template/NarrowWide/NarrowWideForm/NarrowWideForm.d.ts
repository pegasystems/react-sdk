import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../../types/PConnProps';
import './NarrowWideForm.css';
interface NarrowWideFormProps extends PConnProps {
}
export default function NarrowWideForm(props: PropsWithChildren<NarrowWideFormProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=NarrowWideForm.d.ts.map