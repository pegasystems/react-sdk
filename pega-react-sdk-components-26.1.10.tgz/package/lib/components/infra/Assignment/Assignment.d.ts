import React, { type PropsWithChildren } from 'react';
import type { PConnProps } from '../../../types/PConnProps';
interface AssignmentProps extends PConnProps {
    itemKey: string;
    isInModal: boolean;
    banners: any[];
    actionButtons: any[];
}
export default function Assignment(props: PropsWithChildren<AssignmentProps>): React.JSX.Element;
export {};
//# sourceMappingURL=Assignment.d.ts.map