interface VerticalTabsProps {
    tabconfig: any[];
}
export default function VerticalTabs(props: VerticalTabsProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=VerticalTabs.d.ts.map