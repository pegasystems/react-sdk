export default function useInit(props: any): void;
//# sourceMappingURL=hooks.d.ts.map