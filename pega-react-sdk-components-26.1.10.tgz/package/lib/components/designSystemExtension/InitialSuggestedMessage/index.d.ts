export { default } from './InitialSuggestedMessage';
//# sourceMappingURL=index.d.ts.map