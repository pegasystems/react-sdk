# The **Template** directory

The **SDK-WebComponents/Template** directory contains the template code for the template components you want to use with the **WebComponents SDK**.

