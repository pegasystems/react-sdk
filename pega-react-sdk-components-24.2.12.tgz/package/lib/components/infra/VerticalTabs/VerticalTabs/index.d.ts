export { default } from './VerticalTabs';
//# sourceMappingURL=index.d.ts.map