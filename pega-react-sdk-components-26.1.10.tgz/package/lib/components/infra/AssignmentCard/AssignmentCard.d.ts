import { type PropsWithChildren } from 'react';
import type { PConnProps } from '../../../types/PConnProps';
interface AssignmentCardProps extends PConnProps {
    actionButtons: any;
    onButtonPress: any;
}
export default function AssignmentCard(props: PropsWithChildren<AssignmentCardProps>): import("react").JSX.Element;
export {};
//# sourceMappingURL=AssignmentCard.d.ts.map