export { default } from './Time';
