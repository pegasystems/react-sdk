export { default } from './Currency';
//# sourceMappingURL=index.d.ts.map