import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../types/PConnProps';
interface AssignmentCardProps extends PConnProps {
    actionButtons: any;
    onButtonPress: any;
}
export default function AssignmentCard(props: PropsWithChildren<AssignmentCardProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=AssignmentCard.d.ts.map