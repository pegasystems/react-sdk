export declare const isContainerInitialized: (pConnect: any) => boolean | undefined;
export declare const configureBrowserBookmark: (pConnect: any) => void;
//# sourceMappingURL=container-helpers.d.ts.map