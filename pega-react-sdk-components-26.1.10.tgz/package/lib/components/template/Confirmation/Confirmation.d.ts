import { type PropsWithChildren } from 'react';
import type { PConnProps } from '../../../types/PConnProps';
interface ConfirmationProps extends PConnProps {
    datasource: {
        source: any;
    };
    label: string;
    showLabel: boolean;
    showTasks: boolean;
}
export default function Confirmation(props: PropsWithChildren<ConfirmationProps>): import("react").JSX.Element | null;
export {};
//# sourceMappingURL=Confirmation.d.ts.map