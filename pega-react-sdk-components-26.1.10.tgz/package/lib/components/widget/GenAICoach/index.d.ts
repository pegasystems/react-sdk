export { default } from './GenAICoach';
//# sourceMappingURL=index.d.ts.map