export { default } from './NarrowWide';
