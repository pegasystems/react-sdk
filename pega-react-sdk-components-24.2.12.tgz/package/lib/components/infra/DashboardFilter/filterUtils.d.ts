/** This file contains various utility methods to generate filter components, regionLayout data, filter expressions, etc.  */
export declare const createFilter: (value: any, fieldId: any, comparator?: string) => {
    condition: {
        lhs: {
            field: any;
        };
        comparator: string;
        rhs: {
            value: any;
        };
    };
};
export declare const combineFilters: (filterList: any, existingFilters: any) => any;
export declare const createFilterComponent: (getPConnect: any, filterMeta: any, index: any) => import("react/jsx-runtime").JSX.Element;
export declare const buildFilterComponents: (getPConnect: any, allFilters: any) => any;
export declare const convertDateToGMT: (value: any) => any;
export declare const getFilterExpression: (filterValue: any, name: any, metadata: any) => "" | {
    condition: {
        lhs: {
            field: any;
        };
        comparator: string;
        rhs: {
            value: any;
        };
    };
} | null;
/**
 * Returns ConfigurableLayout mapped content. With pre-populated default layout configs.
 * @returns {object[]} ConfigurableLayout content.
 */
export declare function getLayoutDataFromRegion(regionData: any): any;
export declare const getFormattedDate: (date: any) => any;
//# sourceMappingURL=filterUtils.d.ts.map