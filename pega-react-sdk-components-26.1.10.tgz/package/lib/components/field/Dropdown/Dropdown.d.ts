import type { PConnFieldProps } from '../../../types/PConnProps';
interface DropdownProps extends PConnFieldProps {
    datasource?: any[];
    onRecordChange?: any;
    fieldMetadata?: any;
    listType: string;
    deferDatasource?: boolean;
    datasourceMetadata?: any;
    parameters?: any;
    columns: any[];
    showFieldMessage?: boolean;
    messageConfig?: {
        content?: string;
        visibility?: boolean;
    };
    variant?: string;
}
export default function Dropdown(props: DropdownProps): import("react").JSX.Element | null;
export {};
//# sourceMappingURL=Dropdown.d.ts.map