import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../types/PConnProps';
import 'react-datepicker/dist/react-datepicker.css';
interface DashboardFilterProps extends PConnProps {
    name: string;
    filterProp: string;
    type?: string;
    metadata?: any;
}
export default function DashboardFilter(props: PropsWithChildren<DashboardFilterProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=DashboardFilter.d.ts.map