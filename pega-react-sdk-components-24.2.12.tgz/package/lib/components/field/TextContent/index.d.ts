export { default } from './TextContent';
//# sourceMappingURL=index.d.ts.map