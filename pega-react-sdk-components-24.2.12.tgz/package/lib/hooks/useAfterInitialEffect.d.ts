import { EffectCallback, DependencyList } from 'react';
/**
 * @example useAfterInitialEffect(cb, dependencies);
 * @param cb The function that should be executed whenever this hook is called. [React EffectCallback](https://reactjs.org/docs/hooks-reference.html#useeffect)
 * @param dependencies A list of variables or functions that will initiate this hook when they are updated.
 */
declare const useAfterInitialEffect: (cb: EffectCallback, dependencies: DependencyList) => void;
export default useAfterInitialEffect;
//# sourceMappingURL=useAfterInitialEffect.d.ts.map