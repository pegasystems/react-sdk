import path from 'path';
import fs from 'fs';
import { stat } from 'fs/promises';

import { BUILD_CONFIG_JSON_FILENAME, CATEGORY_CUSTOM } from '../../constants.js';
import { getComponentDirectoryPath, getFramework, removeComponentPrefix } from '../../util.js';

import buildReactComponent from './builderReact/index.js';
import buildAngularComponent from './builderAngular/index.js';
import buildAssociatedComponent from './builderAssociated/index.js';

const extensions = ['ts', 'tsx', 'js', 'jsx'];

export const bundleAssociatedComponent = async (componentKey, sourceMap, devBuild, category = CATEGORY_CUSTOM) => {
  const componentDirectory = await getComponentDirectoryPath(componentKey, category);

  const idx = (
    await Promise.all(
      extensions.map(ext =>
        stat(path.join(componentDirectory, `index.${ext}`))
          .then(() => true)
          .catch(() => false)
      )
    )
  ).findIndex(exists => exists);

  if (idx === -1) throw new Error('Index file not found.');

  // remove sub folder, component goes in dist directory without it
  if (componentKey.indexOf("/") >=0) {
    const arKey = componentKey.split("/");
    componentKey = arKey[arKey.length - 1];
  }

  const inputFile = path.join(componentDirectory, `index.${extensions[idx]}`);
  const outputFile = `${componentKey}.js`;

  let buildConfig = {};

  if (fs.existsSync(BUILD_CONFIG_JSON_FILENAME)) {
    buildConfig = JSON.parse(fs.readFileSync(BUILD_CONFIG_JSON_FILENAME, 'utf8'));
  }

  let externals = buildConfig.externals || [];
  externals = {
    react: 'React',
    'react-dom': 'ReactDOM',
    PCore: 'PCore',
    ...buildConfig.externals
  };

  let globals = buildConfig.globals || {};

  const defaultGlobals = {
    react: 'React',
    'react-dom': 'ReactDOM',
    PCore: 'PCore',
    ...buildConfig.globals
  };

  globals = { ...globals, ...defaultGlobals };
  await buildAssociatedComponent({
    inputFile,
    outputFile,
    componentKey,
    externals,
    globals,
    sourceMap,
    devBuild
  });
};

export const bundleReactComponent = async (componentKey, sourceMap, devBuild, category = CATEGORY_CUSTOM) => {
  const componentDirectory = await getComponentDirectoryPath(componentKey, category);

  const idx = (
    await Promise.all(
      extensions.map(ext =>
        stat(path.join(componentDirectory, `index.${ext}`))
          .then(() => true)
          .catch(() => false)
      )
    )
  ).findIndex(exists => exists);

  if (idx === -1) throw new Error('Index file not found.');

  // remove sub folder, component goes in dist directory without it
  if (componentKey.indexOf("/") >=0) {
    const arKey = componentKey.split("/");
    componentKey = arKey[arKey.length - 1];
  }

  const inputFile = path.join(componentDirectory, `index.${extensions[idx]}`);
  const outputFile = `${componentKey}.js`;

  let buildConfig = {};

  if (fs.existsSync(BUILD_CONFIG_JSON_FILENAME)) {
    buildConfig = JSON.parse(fs.readFileSync(BUILD_CONFIG_JSON_FILENAME, 'utf8'));
  }

  let externals = buildConfig.externals || [];
  externals = {
    react: 'React',
    'react-dom': 'ReactDOM',
    PCore: 'PCore',
    ...buildConfig.externals
  };

  let globals = buildConfig.globals || {};

  const defaultGlobals = {
    react: 'React',
    'react-dom': 'ReactDOM',
    PCore: 'PCore',
    ...buildConfig.globals
  };

  globals = { ...globals, ...defaultGlobals };
  await buildReactComponent({
    inputFile,
    outputFile,
    componentKey,
    externals,
    globals,
    sourceMap,
    devBuild
  });
};

export const bundleAngularComponent = async (componentKey, sourceMap, devBuild, category = CATEGORY_CUSTOM) => {
  const componentDirectory = await getComponentDirectoryPath(componentKey, category);

  componentKey = removeComponentPrefix(componentKey);

  const idx = (
    await Promise.all(
      extensions.map(ext =>
        stat(path.join(componentDirectory, `${componentKey}.component.${ext}`))
          .then(() => true)
          .catch(() => false)
      )
    )
  ).findIndex(exists => exists);


  if (idx === -1) throw new Error('Index file not found.');

  // remove sub folder, component goes in dist directory without it
  // if (componentKey.indexOf("/") >=0) {
  //   const arKey = componentKey.split("/");
  //   componentKey = arKey[arKey.length - 1];
  // }

  const inputFile = path.join(componentDirectory, `${componentKey}.component.${extensions[idx]}`);
  const outputFile = `${componentKey}.js`;

  let buildConfig = {};

  if (fs.existsSync(BUILD_CONFIG_JSON_FILENAME)) {
    buildConfig = JSON.parse(fs.readFileSync(BUILD_CONFIG_JSON_FILENAME, 'utf8'));
  }

  let externals = buildConfig.externals || [];
  externals = {
    PCore: 'PCore',
    ...buildConfig.externals
  };

  let globals = buildConfig.globals || {};

  const defaultGlobals = {
    PCore: 'PCore',
    ...buildConfig.globals
  };

  globals = { ...globals, ...defaultGlobals };
  await buildAngularComponent({
    inputFile,
    outputFile,
    componentKey,
    externals,
    globals,
    sourceMap,
    devBuild
  });
};
