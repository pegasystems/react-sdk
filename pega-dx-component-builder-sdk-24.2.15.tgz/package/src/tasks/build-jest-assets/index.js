import fs from 'fs';
import path from 'path';
import { join } from 'path';
import inquirer from 'inquirer';
import { Listr } from 'listr2';
import chalk from 'chalk';

import { showVersion, getSubComponents, checkPathAccess, getComponents, getFramework, getListOfDirectories } from '../../util.js';
import createAll from '../create-all/index.js';
import create from '../create/index.js';
import overrideAll from '../override-all/index.js';
import override from '../override/index.js';
import deleteAll from '../delete-all/index.js';

import { JEST_ASSETS_PATH, JEST_CREATE_PATH, JEST_CREATE_ALL_PATH, JEST_ASSETS_SDK_A,
  JEST_ASSETS_SDK_R, SDK_CONFIG_JSON_FILENAME,
  REACT_COMPONENTS_DIRECTORY_PATH, ANGULAR_COMPONENTS_DIRECTORY_PATH } from '../../constants.js';
import { dir } from 'console';


const getBuildAssetsQuestions = async ()  => {
  const message = "\n**IMPORTANT** Building Jest Assets will remove any local components in your components directory!\n";
  console.log(`${chalk.green.bold(message)}`);

  return [
    {
      name: 'buildAssets',
      type: 'confirm',
      message: 'Generate Jest Assets ?',
      default: false
    }
  ];
};




const deleteTestDirectory = async(dirPath) => {

  try {
    fs.rmSync(dirPath, { recursive: true });
    // console.log(`${chalk.red.bold(dirPath)} is deleted from assets`);
  } catch (err) {
    console.log('no directory');
    throw new Error(`No such directory ${dirPath}`);
  }
}

const copyAssets = async(destinationPath) => {
  const currentDirectory = process.cwd();
  const framework = await getFramework();

  const SDK_DIR = framework === "SDK-React" ? REACT_COMPONENTS_DIRECTORY_PATH : ANGULAR_COMPONENTS_DIRECTORY_PATH;

  const srcDir = join(currentDirectory, SDK_DIR );



  fs.cpSync(srcDir, destinationPath, { recursive: true});
}

const deleteAssets = async() => {
  let args  = [ '','', '', 'Local', 'custom', 'Y'];
  let myOptions = {};
  myOptions["params"] = args;

  await deleteAll(myOptions);

  args  = [ '','', '', 'Local', 'override', 'Y'];
  myOptions = {};
  myOptions["params"] = args;

  await deleteAll(myOptions);

}

const createJestAssets = async() => {

  const framework = await getFramework();

  // initially delete local assets
  await deleteAssets();

  let args  = [ '','', '', 'My', '0.0.1', 'DXIL', '', 'Pega'];
  let myOptions = {};
  myOptions["params"] = args;

  await createAll(myOptions);
  await overrideAll();


  const jestAssetFrameworkPath = framework === "SDK-React" ? JEST_ASSETS_SDK_R: JEST_ASSETS_SDK_A;

  // create All
  // get current test assets and delete them
  let createAllPath = path.join(path.resolve(), JEST_ASSETS_PATH, jestAssetFrameworkPath, JEST_CREATE_ALL_PATH);
  const fileDirList = await getListOfDirectories(createAllPath);

  for (const index in fileDirList) {
    const directoryToDelete = fileDirList[index];
    // console.log(chalk.bold.green("Deleting: " + componentToDelete));
    // eslint-disable-next-line no-await-in-loop
    await deleteTestDirectory(path.join(createAllPath, directoryToDelete));
  }



  await copyAssets(createAllPath);
  await deleteAssets();

  // create
  args  = [ '','', '', 'Field', 'Text', 'MyTestText', 'My Test Text', '0.0.1','DXIL', '', 'My Test Text Description', 'Pega'];
  myOptions = {};
  myOptions["params"] = args;

  await create(myOptions);
  await overrideAll();

  // get current test assets and delete them
  let createPath = path.join(path.resolve(), JEST_ASSETS_PATH, jestAssetFrameworkPath, JEST_CREATE_PATH);
  const fileDirList2 = await getListOfDirectories(createPath);

  for (const index in fileDirList2) {
    const directoryToDelete = fileDirList2[index];
    // console.log(chalk.bold.green("Deleting: " + componentToDelete));
    // eslint-disable-next-line no-await-in-loop
    await deleteTestDirectory(path.join(createPath, directoryToDelete));
  }



  await copyAssets(createPath);
  await deleteAssets();


}


export default async options => {
  showVersion();

  const questions = await getBuildAssetsQuestions();
  const answers = await inquirer.prompt(questions);
  const {  buildAssets } = answers;

  if (buildAssets) {

    await createJestAssets(false);

  }


};
