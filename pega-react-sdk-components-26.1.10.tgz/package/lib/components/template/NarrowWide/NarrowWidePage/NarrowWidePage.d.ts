import type { PropsWithChildren, ReactElement } from 'react';
import type { GenAICoach } from '../../../widget/GenAICoach/GenAICoach.types';
import type { PConnProps } from '../../../../types/PConnProps';
interface NarrowWidePageProps extends PConnProps {
    title: string;
    templateCol: string;
    icon: string;
    coaches?: GenAICoach[];
    localeReference?: string;
}
export default function NarrowWidePage(props: PropsWithChildren<NarrowWidePageProps>): string | number | bigint | boolean | import("react").JSX.Element | Iterable<import("react").ReactNode> | Promise<string | number | bigint | boolean | import("react").ReactPortal | ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | Iterable<import("react").ReactNode> | null | undefined> | null | undefined;
export {};
//# sourceMappingURL=NarrowWidePage.d.ts.map