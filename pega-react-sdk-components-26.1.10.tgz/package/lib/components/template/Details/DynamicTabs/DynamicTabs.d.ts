import React from 'react';
import type { PConnProps } from '../../../../types/PConnProps';
interface DynamicTabsProps extends PConnProps {
    showLabel: boolean;
    label: string;
    referenceList?: any[];
}
declare function DynamicTabs(props: DynamicTabsProps): React.JSX.Element;
export default DynamicTabs;
//# sourceMappingURL=DynamicTabs.d.ts.map