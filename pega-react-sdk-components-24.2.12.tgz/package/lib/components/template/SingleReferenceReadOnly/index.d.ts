export { default } from './SingleReferenceReadOnly';
//# sourceMappingURL=index.d.ts.map