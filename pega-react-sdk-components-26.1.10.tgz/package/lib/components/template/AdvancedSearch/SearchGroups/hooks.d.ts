/**
 * This hook registers a callback for the whenever list view component is ready
 * then makes a call to get the data using the search fields pre-filled with cache data.
 */
export declare function useCacheWhenListViewReady(cache: {
    searchFields: unknown;
}, viewName: string, useCache: boolean, getFilterData: (params: {
    isCalledFromCache: boolean;
}) => void, searchSelectCacheKey: string): void;
//# sourceMappingURL=hooks.d.ts.map