export declare const isContentBinary: (headers: any) => any;
export declare const isContentBase64: (headers: any) => any;
export declare const fileDownload: (data: any, fileName: any, ext: any, headers: any) => void;
export declare const fileDownloadVar: (content: any, type: any, name: any, extension: any) => void;
export declare const useFileDownload: (context: any) => ({ ID, name, extension, type, category, responseType }: any) => void;
export declare const getIconFromFileType: (fileType: any) => string;
export declare const validateMaxSize: (fileObj: any, maxSizeInMB: string) => boolean;
export declare const isFileUploadedToServer: (file: any) => any;
//# sourceMappingURL=attachmentHelpers.d.ts.map