import type { PropsWithChildren } from 'react';
import type { PConnProps } from '../../../../types/PConnProps';
import './NarrowWide.css';
interface NarrowWideProps extends PConnProps {
    a: any;
    b: any;
    title?: string;
    cols?: string;
    icon?: string;
}
export default function NarrowWide(props: PropsWithChildren<NarrowWideProps>): import("react").JSX.Element;
export {};
//# sourceMappingURL=NarrowWide.d.ts.map