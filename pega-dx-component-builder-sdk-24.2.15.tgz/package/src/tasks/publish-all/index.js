import inquirer from 'inquirer';
import { Listr } from 'listr2';
import chalk from 'chalk';

import validate from '../validator/index.js';
import { getComponentDirectoryPath, showVersion, getOptionsCategory, getComponentsObj, getFramework, getLocalComponentKeyFromConfig, convertIntoKebabCase, convertIntoPascalCase } from '../../util.js';
import { bundleReactComponent, bundleAngularComponent, bundleAssociatedComponent} from '../bundle/index.js';
import { updateComponentMap  } from '../map/map.js';
import { lintComponent } from '../linter/index.js';
import { CATEGORY_CONSTELLATION, CATEGORY_CUSTOM } from '../../constants.js';


import { getPublishComponentQuestions,
  publishComponentToServer,
  zipComponent,
  getBuildCategory,
  mapConfigJsonToCompanion,
  removeCompanionConfigJson,
  cleanUp
 } from './helper.js';


export function getCustomTasks(componentKey, category, sourceMap, devBuild, content, options, framework, associatedComponentKey) {
  const sDevBuild = devBuild ? '(dev build)' : '';
  const sFramework = framework.split("-")[1];

  // eslint-disable no-unneeded-ternary,no-nested-ternary
  const doFetch = options.params.length >= 8 ? options.params[7] !== 'noFetch' : true;


  return new Listr(
    [

      {
        title: 'Validate config schema',
        task: async () => {
          await validate(componentKey, category);
        }
      },
      {
        title: `Lint ${sFramework} component`,
        task: async () => {
          const targetDirectory = await getComponentDirectoryPath(componentKey, category);
          // console.log(`in buildComponent Lint component task: componentKey: ${componentKey} targetDirectory: ${targetDirectory}`);
          await lintComponent(targetDirectory);
        }
      },
      {
        title: 'Update component map',
        task: async () => {
            await updateComponentMap(componentKey);
        }
      },
      {
        title: 'Lint associated component',
        task: async () => {
          const targetDirectory = await getComponentDirectoryPath(associatedComponentKey, CATEGORY_CONSTELLATION);
          // console.log(`in buildComponent Lint component task: componentKey: ${componentKey} targetDirectory: ${targetDirectory}`);
          await lintComponent(targetDirectory);
        }
      },
      {
        title: 'Map config to associated component',
        task: async () => {
          await mapConfigJsonToCompanion(componentKey);
        }
      },
      {
        title: `Bundle React component ${sDevBuild}`,
        task: async () => await bundleReactComponent(componentKey, sourceMap, devBuild, category),
        skip: () => (options.skipBundle ? 'Skipped bundling component' : undefined),
        enabled: ok => framework === "SDK-React"
      },
      {
        title: `Bundle Angular component ${sDevBuild}`,
        task: async () => await bundleAngularComponent(componentKey, sourceMap, devBuild, category),
        skip: () => (options.skipBundle ? 'Skipped bundling component' : undefined),
        enabled: ok => framework === "SDK-Angular"
      },
      {
        title: `Bundle associated component ${sDevBuild}`,
        task: async () => await bundleAssociatedComponent(associatedComponentKey, sourceMap, devBuild, CATEGORY_CONSTELLATION),
        skip: () => (options.skipBundle ? 'Skipped bundling component' : undefined)
      },
      {
        title: 'Zip associated component',
        task: async () => {
          const output = await zipComponent(associatedComponentKey, CATEGORY_CONSTELLATION);
          content = { ...content, ...output, componentKey : associatedComponentKey };
        }
      },
      {
        title: 'Publish associated component',
        task: async () => {
          await publishComponentToServer(content, doFetch);
        }
      },
      {
        title: 'Clean up associated component',
        task: async () => {
          await removeCompanionConfigJson(associatedComponentKey);
        }
      }
    ],
    {
      exitOnError: true
    }
  );

}

export function getOverrideTasks(componentKey, category, sourceMap, devBuild, content, options, framework) {
  const sDevBuild = devBuild ? '(dev build)' : '';
  const sFramework = framework.split("-")[1];

  // eslint-disable no-unneeded-ternary,no-nested-ternary
  const doFetch = options.params.length >= 8 ? options.params[7] !== 'noFetch' : true;


  return new Listr(
    [
      {
        title: 'Validate config schema',
        task: async () => {
          await validate(componentKey, category);
        }
      },
      {
        title: `Lint ${sFramework} component`,
        task: async () => {
          const targetDirectory = await getComponentDirectoryPath(componentKey, category);
          // console.log(`in buildComponent Lint component task: componentKey: ${componentKey} targetDirectory: ${targetDirectory}`);
          await lintComponent(targetDirectory);
        }
      },
      {
        title: `Bundle React component ${sDevBuild}`,
        task: async () => await bundleReactComponent(componentKey, sourceMap, devBuild, category),
        skip: () => (options.skipBundle ? 'Skipped bundling component' : undefined),
        enabled: ok => framework === "SDK-React"
      },
      {
        title: `Bundle Angular component ${sDevBuild}`,
        task: async () => await bundleAngularComponent(componentKey, sourceMap, devBuild, category),
        skip: () => (options.skipBundle ? 'Skipped bundling component' : undefined),
        enabled: ok => framework === "SDK-Angular"
      },
      {
        title: 'Update component map',
        task: async () => {
            await updateComponentMap(componentKey, category);
        }
      },
      {
        title: 'Zip component config',
        task: async () => {
          const output = await zipComponent(componentKey, category);
          content = { ...content, ...output, componentKey };
        }
      },
      {
        title: 'Publish component config',
        task: async () => {
          await publishComponentToServer(content, doFetch);
        }
      }
    ],
    {
      exitOnError: true
    }
  );

}


export default async options => {
  showVersion();

  let componentKey;
  let sourceMap;
  let devBuild;
  let content;
  let category;
  let components;

  const framework = await getFramework();

  if (options.params.length >= 7) {
    category = options.params[3];
    const rulesetName = options.params[4];
    const rulesetVersion = options.params[5];
    const dBuild = options.params[6];
    devBuild = dBuild === 'Y' || dBuild === 'y' || dBuild === true || dBuild === 'true';

    content = { componentKey, rulesetName, rulesetVersion, devBuild };

    components = await getComponentsObj(false, category);

    // end if find no components
    if (components.length == 0) {
      console.log(chalk.redBright("No components to publish"));
      process.exit(1);
    }

  } else {
    const catQuestion = await getBuildCategory(options);
    const catAnswers = await inquirer.prompt(catQuestion);


    category = catAnswers.category;
    if (category == null) {
      category = getOptionsCategory(options);
    }

    components = await getComponentsObj(false, category);

    // end if find no componets
    if (components.length == 0) {
      console.log(chalk.redBright("No components to publish"));
      process.exit(1);
    }

    const questions = await getPublishComponentQuestions(category);
    const answers = await inquirer.prompt(questions);
    ({sourceMap, devBuild } = answers);

    content = {
      ...answers
    };
  }

  if (category === CATEGORY_CUSTOM) {

    for (const component of components) {
        let componentKey = component.value;
        const componentKeyName = component.name;
        console.log(chalk.bold.green(`Publishing: ${componentKeyName}`));

        let associatedComponentKey = componentKey;

        switch (framework) {
          case "SDK-Angular":
            // componentKey is in Pascal case, which is associated, need to convert to Kabab case
            let arComp = componentKey.split("/");
            arComp[1] = convertIntoKebabCase(convertIntoPascalCase(arComp[1]));
            componentKey = arComp.join("/");
            break;
          case "SDK-React":
            break;
          case "SDK-WebComponents":
            break;
        }

        let myCustomTasks = getCustomTasks(componentKey, category, sourceMap, devBuild, content, options, framework, associatedComponentKey);

        await myCustomTasks.run().catch(err => {
          console.log(chalk.bold.red(err.toString()));
          process.exit(1);
        });
      }

  }
  else {

    for (const component of components) {
      const componentKey = component.value;
      const componentKeyName = component.name;
      console.log(chalk.bold.green(`Publishing: ${componentKeyName}`));

      let myOverrideTasks = getOverrideTasks(componentKey, category, sourceMap, devBuild, content, options, framework);

      await myOverrideTasks.run().catch(err => {
        console.log(chalk.bold.red(err.toString()));
      });
    }

  }


  // once done, remove leftover directories
  await cleanUp();


  return true;
};
