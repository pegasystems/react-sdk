# The **Field** directory

The **SDK-Angular/Field** directory contains the template code for the field components you want to use with the **Angular SDK**.

