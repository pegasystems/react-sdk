import { PConnProps } from '../../../../types/PConnProps';
interface ViewContainerProps extends PConnProps {
    name?: string;
    loadingInfo?: any;
    routingInfo?: any;
    mode?: string;
    limit?: number;
}
export default function ViewContainer(props: ViewContainerProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=ViewContainer.d.ts.map