export { default } from './LeftAlignVerticalTabs';
//# sourceMappingURL=index.d.ts.map