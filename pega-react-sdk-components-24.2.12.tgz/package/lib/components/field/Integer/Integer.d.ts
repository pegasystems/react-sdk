import { PConnFieldProps } from '../../../types/PConnProps';
interface IntegerProps extends PConnFieldProps {
}
export default function Integer(props: IntegerProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Integer.d.ts.map