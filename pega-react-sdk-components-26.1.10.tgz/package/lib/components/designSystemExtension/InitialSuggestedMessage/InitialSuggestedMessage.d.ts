import type { InitialSuggestedMessageProps } from '../GenAICoachContent/GenAICoach.types';
export default function InitialSuggestedMessage(props: InitialSuggestedMessageProps): import("react").JSX.Element;
//# sourceMappingURL=InitialSuggestedMessage.d.ts.map