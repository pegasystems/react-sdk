export { default } from './TwoColumnTab';
