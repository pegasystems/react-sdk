import { PConnFieldProps } from '../../../types/PConnProps';
interface URLComponentProps extends PConnFieldProps {
}
export default function URLComponent(props: URLComponentProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=URL.d.ts.map