export { default } from './WssQuickCreate';
//# sourceMappingURL=index.d.ts.map