module.exports = {
  verbose: true,
  roots: ['./tests'],
  moduleFileExtensions: ['js', 'jsx', 'ts', 'tsx'],
  testEnvironment: 'jsdom',
  transform: {
    '^.+\\.[t|j]sx?$': 'babel-jest'
  },
  collectCoverage: true,
  haste: {
    retainAllFiles: true
  },
  testPathIgnorePatterns: [],
  transformIgnorePatterns: [],
  modulePathIgnorePatterns: [],
  coveragePathIgnorePatterns: [],
  collectCoverageFrom: ['./src/*.js'],
  coverageThreshold: {
    global: {
      statements: 79,
      branches: 74,
      functions: 81,
      lines: 80
    }
  }
};
