declare const connectToState: (mapStateToProps?: () => void) => (Component: any) => (ownProps?: {}) => import("react").JSX.Element;
export default connectToState;
//# sourceMappingURL=state-utils.d.ts.map