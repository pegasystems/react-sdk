import path from 'path';
import fs from 'fs';
import { promisify } from 'util';
import { join } from 'path';

import inquirer from 'inquirer';
import ncp from 'ncp';
import chalk from 'chalk';
import { updateComponentMap  } from '../map/map.js';

import {
  checkPathAccess, 
  showVersion, 
  getFramework,
  getPegaConfig,
  getComponentDirectoryPath,
  getComponents,
  getComponentDefaults,
  convertIntoKebabCase
} from '../../util.js';

import { COMPONENT_SCHEMA, 
  CATEGORY_OVERRIDE, 
  SDK_CONFIG_JSON_FILENAME, 
  DXCB_CONFIG, 
  DXCB_COMPONENT_DEFAULTS,
  CUSTOM_TEMPLATES,
  OVERRIDE_TEMPLATE_PATH,
  OVERRIDE_REACT_LIB_PATH,
  OVERRIDE_ANGULAR_LIB_PATH } from '../../constants.js';
import { compileMustacheTemplates } from '@pega/dx-component-builder-sdk/src/tasks/create/index.js';

const pegaConfigJsonPath = path.join(path.resolve(), SDK_CONFIG_JSON_FILENAME);

const copy = promisify(ncp);

const copyComponentTemplate = async options => {
  return copy(options.overrideDirectory, options.targetDirectory, {
    clobber: false
  });
};


const checkAndCreateConfigComponentKey = async (targetDirectory) => {

  const configFile = path.join(targetDirectory, "config-ext.json");
  try {
    const configData = fs.readFileSync(path.resolve(configFile), 'utf8');
    let configObj = JSON.parse(configData);

    let writeUpdate = false;
    if (!configObj.componentKey || !configObj.label) {
      const name = configObj.name;

      if (!configObj.componentKey) {
        const componentKey = name;
        configObj = { componentKey, ...configObj };
      }

      if (!configObj.label) {
        const label = name;
        configObj = { label, ...configObj };
      }


      // stringify "4", makes the json string look like JSON in the file, formated instead of a single line
      const configContent = JSON.stringify(configObj, null, 4);

      // update file
      fs.writeFileSync(configFile, configContent, { encoding: 'utf8' });
    }

  }
  catch (err) {
    // no config-ext.json file, so no update, which is ok
    const arPaths = targetDirectory.split("/");
    const compName = arPaths[arPaths.length-1] ;
    console.log(chalk.yellow(`Component ${compName} has no config file for extension.`));
  }
}


const getListAvailableComponents = async (type) => {
  const components = await getComponents(false, CATEGORY_OVERRIDE);
  let fullList;
  const framework = await getFramework();
  switch (framework) {
    case "SDK-Angular":
      fullList = COMPONENT_SCHEMA.overrideAngularComponent[type];
      break;
    case "SDK-React":
      fullList = COMPONENT_SCHEMA.overrideReactComponent[type];
      break;
    case "SDK-WebComponents":
      fullList = COMPONENT_SCHEMA.overrideWCComponent[type];
      break;
  }
  let availList = [];
  for (var el in fullList) {

    let listEl = fullList[el].value;

    if (listEl.indexOf("/") >=0) {
      const arKey = listEl.split("/");
      listEl = arKey[arKey.length - 1];
    }

    if (components.includes(listEl)) {
      // currently don't show, because too many separators inquirer flaky
      //availList.push(new inquirer.Separator("** " + fullList[el].name));
    }
    else {
      availList.push(fullList[el]);
    }
  }

  return availList;
}

const adjustAngularComponentName = (componentName) => {
  if (componentName.indexOf("/") >= 0) {
    componentName = componentName.split("/")[1];
  }

  return componentName;
}

const adjustAngularKebabCase = (componentName) => {
  componentName = componentName.replaceAll("/-", "/");
  return componentName;
}

const validateCompile = async (
  {
    componentName, 
    type
  },
  options
) => {

  let pegaConfig =
  await getPegaConfig();

  // will need to put a case statement here checking framework
  const framework = await getFramework();
  let templateParentDir = "";

  let originalComponentName = componentName;

  switch (framework) {
    case "SDK-Angular":
      templateParentDir = OVERRIDE_ANGULAR_LIB_PATH;
      // componentName = adjustAngularComponentName(componentName);
      componentName = convertIntoKebabCase(componentName);
      componentName = adjustAngularKebabCase(componentName);
      break;
    case "SDK-React":
      templateParentDir = OVERRIDE_REACT_LIB_PATH;
      break;
    case "SDK-WebComponents":
      break;
  }

  if (componentName === "") {
    console.log(chalk.red(`${originalComponentName} component doesn't exist`));
    return;
  }

  if (pegaConfig[DXCB_CONFIG] &&
    pegaConfig[DXCB_CONFIG][CUSTOM_TEMPLATES] &&
    pegaConfig[DXCB_CONFIG][CUSTOM_TEMPLATES][OVERRIDE_TEMPLATE_PATH] && 
    pegaConfig[DXCB_CONFIG][CUSTOM_TEMPLATES][OVERRIDE_TEMPLATE_PATH] != "") {
    templateParentDir = pegaConfig[DXCB_CONFIG][CUSTOM_TEMPLATES][OVERRIDE_TEMPLATE_PATH];
  }

  // componentName has sub directory if components are in a sub directory of main "type"
  const overrideDirectory = `${templateParentDir}/${type}/${componentName}`;

  await checkPathAccess(overrideDirectory);

  let componentKey = componentName;
  if (componentKey.indexOf("/") >= 0) {
    componentKey = componentKey.split("/")[1];
  }
  const typeLC = type.toLowerCase();
  const targetDirectory = await getComponentDirectoryPath(join(typeLC, "/",componentKey), CATEGORY_OVERRIDE);

  const components = await getComponents(false, CATEGORY_OVERRIDE);
  if (components.includes(componentKey)) {
    console.log(chalk.red(`${componentKey} component already exists in ${targetDirectory}`));
    return;
  }

  await copyComponentTemplate({
    ...options,
    targetDirectory,
    overrideDirectory
  });

  await checkAndCreateConfigComponentKey(targetDirectory);


  console.log(chalk.green(`> Created ${componentKey} component in ${targetDirectory}`));

  const componentKeyWithType = join(type, componentKey);
  await updateComponentMap(componentKeyWithType, CATEGORY_OVERRIDE);

  console.log(chalk.green(`> Added ${componentKeyWithType} to map`));

};

const buildOverrideComponents = async (type, compList, options) => {
  if (compList.length > 0) {
    for (var index in compList) {
      let componentName = compList[index].value;
      await validateCompile(
        {
          componentName,
          type
        },
        options
      );
    }
  }
  else {
    console.log(chalk.green(`> All ${type} components have already been created.`));
  }


}

export default async options => {
  showVersion();

  await checkPathAccess(pegaConfigJsonPath);

  let data = fs.readFileSync(pegaConfigJsonPath, { encoding: 'utf8' });
  data = data && JSON.parse(data);

  if (!data[DXCB_CONFIG] || !data[DXCB_CONFIG][DXCB_COMPONENT_DEFAULTS]) {
    console.error(
      `${chalk.red.bold('ERROR')} Could not able find components defaults path in config.json`
    );
    process.exit(1);
  }

  const componentData = data[DXCB_CONFIG][DXCB_COMPONENT_DEFAULTS];

  const { organization, library} = componentData;

  let componentDefaults = await getComponentDefaults();
  componentDefaults.library = library;

  const fieldList = await getListAvailableComponents("field");
  const desList = await getListAvailableComponents("designSystemExtension");
  const templateList = await getListAvailableComponents("template");
  const widgetList = await getListAvailableComponents("widget");
  const infraList = await getListAvailableComponents("infra");

 
  await buildOverrideComponents("field", fieldList, options);
  await buildOverrideComponents("template", templateList, options);
  await buildOverrideComponents("widget", widgetList, options);
  await buildOverrideComponents("designSystemExtension", desList, options);
  await buildOverrideComponents("infra", infraList, options);

 

};


