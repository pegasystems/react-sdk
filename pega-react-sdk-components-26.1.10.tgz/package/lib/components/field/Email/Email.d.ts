import type { PConnFieldProps } from '../../../types/PConnProps';
interface EmailProps extends PConnFieldProps {
    showFieldMessage?: boolean;
    messageConfig?: {
        content?: string;
        visibility?: boolean;
    };
    variant?: string;
}
export default function Email(props: EmailProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=Email.d.ts.map