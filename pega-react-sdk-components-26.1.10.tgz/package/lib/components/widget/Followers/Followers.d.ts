import type { PropsWithChildren } from 'react';
import type { PConnProps } from '../../../types/PConnProps';
interface FollowersProps extends PConnProps {
}
export default function Followers(props: PropsWithChildren<FollowersProps>): import("react").JSX.Element;
export {};
//# sourceMappingURL=Followers.d.ts.map