import { PConnProps } from '../../../types/PConnProps';
import './WssNavBar.css';
interface WssNavBarProps extends PConnProps {
    appInfo: any;
    navLinks: any[];
    operator: {
        currentUserInitials: string;
    };
    navDisplayOptions: {
        alignment: string;
        position: string;
    };
    portalName: string;
    imageSrc: string;
    fullImageSrc: string;
    appName: any;
}
export default function WssNavBar(props: WssNavBarProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=WssNavBar.d.ts.map