import { PConnFieldProps } from '../../../types/PConnProps';
interface TimeProps extends PConnFieldProps {
}
export default function Time(props: TimeProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Time.d.ts.map