import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../../types/PConnProps';
interface TwoColumnProps extends PConnProps {
    templateCol?: string;
}
export default function TwoColumn(props: PropsWithChildren<TwoColumnProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=TwoColumn.d.ts.map