import './WssQuickCreate.css';
interface WssQuickCreateProps {
    heading: string;
    actions?: any[];
}
export default function WssQuickCreate(props: WssQuickCreateProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=WssQuickCreate.d.ts.map