import { PConnProps } from '../../../../types/PConnProps';
interface OneColumnPageProps extends PConnProps {
}
export default function OneColumnPage(props: OneColumnPageProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=OneColumnPage.d.ts.map