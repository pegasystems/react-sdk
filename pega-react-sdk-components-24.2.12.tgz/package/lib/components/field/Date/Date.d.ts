import { PConnFieldProps } from '../../../types/PConnProps';
interface DateProps extends PConnFieldProps {
}
export default function Date(props: DateProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Date.d.ts.map