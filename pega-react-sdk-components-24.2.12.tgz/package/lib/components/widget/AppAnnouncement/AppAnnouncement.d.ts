import { PConnProps } from '../../../types/PConnProps';
interface AppAnnouncementProps extends PConnProps {
    header?: string;
    description?: string;
    datasource?: any;
    whatsnewlink?: string;
}
export default function AppAnnouncement(props: AppAnnouncementProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=AppAnnouncement.d.ts.map