export { default } from './NarrowWidePage';
//# sourceMappingURL=index.d.ts.map