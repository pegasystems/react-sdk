import type { PConnFieldProps } from '../../../types/PConnProps';
interface TextAreaProps extends PConnFieldProps {
    fieldMetadata?: any;
    showFieldMessage?: boolean;
    messageConfig?: {
        content?: string;
        visibility?: boolean;
    };
    variant?: string;
}
export default function TextArea(props: TextAreaProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=TextArea.d.ts.map