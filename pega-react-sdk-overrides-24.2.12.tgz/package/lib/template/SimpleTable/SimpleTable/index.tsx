export { default } from './SimpleTable';
