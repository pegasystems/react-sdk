import { PConnFieldProps } from '../../../types/PConnProps';
interface DecimalProps extends PConnFieldProps {
    currencyISOCode?: string;
    decimalPrecision?: number;
    showGroupSeparators?: boolean;
    formatter?: string;
}
export default function Decimal(props: DecimalProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Decimal.d.ts.map