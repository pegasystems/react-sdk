export { default } from './Region';
//# sourceMappingURL=index.d.ts.map