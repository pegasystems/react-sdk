export { default } from './DateTime';
//# sourceMappingURL=index.d.ts.map