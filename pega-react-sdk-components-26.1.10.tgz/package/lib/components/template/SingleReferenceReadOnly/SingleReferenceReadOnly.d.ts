import type { PConnProps } from '../../../types/PConnProps';
interface SingleReferenceReadOnlyProps extends PConnProps {
    config: any;
    displayAs?: string;
    ruleClass?: string;
    label?: string;
    displayMode?: string;
    type: string;
    referenceType?: string;
    hideLabel?: boolean;
    dataRelationshipContext?: string;
}
export default function SingleReferenceReadOnly(props: SingleReferenceReadOnlyProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=SingleReferenceReadOnly.d.ts.map