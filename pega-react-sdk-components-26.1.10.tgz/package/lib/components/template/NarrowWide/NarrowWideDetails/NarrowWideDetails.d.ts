import type { PConnProps } from '../../../../types/PConnProps';
interface NarrowWideDetailsProps extends PConnProps {
    showLabel?: boolean;
    label: string;
    showHighlightedData?: boolean;
}
export default function NarrowWideDetails(props: NarrowWideDetailsProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=NarrowWideDetails.d.ts.map