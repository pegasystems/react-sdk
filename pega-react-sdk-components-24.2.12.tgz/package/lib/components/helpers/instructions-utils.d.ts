declare const updateNewInstuctions: (c11nEnv: any, selectionList: any) => void;
declare const insertInstruction: (c11nEnv: any, selectionList: any, selectionKey: any, primaryField: any, item: any) => void;
declare const deleteInstruction: (c11nEnv: any, selectionList: any, selectionKey: any, item: any) => void;
export { updateNewInstuctions, insertInstruction, deleteInstruction };
//# sourceMappingURL=instructions-utils.d.ts.map