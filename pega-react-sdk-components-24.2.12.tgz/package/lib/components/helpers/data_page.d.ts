export declare const getDataPage: (dataPageName: any, parameters: any, context: any) => Promise<unknown>;
//# sourceMappingURL=data_page.d.ts.map