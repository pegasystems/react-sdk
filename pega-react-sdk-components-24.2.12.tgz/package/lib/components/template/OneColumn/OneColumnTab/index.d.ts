export { default } from './OneColumnTab';
//# sourceMappingURL=index.d.ts.map