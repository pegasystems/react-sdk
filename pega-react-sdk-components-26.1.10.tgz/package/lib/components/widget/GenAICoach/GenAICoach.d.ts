import type { PConnProps } from '../../../types/PConnProps';
import type { GenAICoach as GenAICoachConfig } from './GenAICoach.types';
interface GenAICoachProps extends PConnProps {
    coaches?: GenAICoachConfig[];
    isPortalAgent?: boolean;
}
export default function GenAICoach(props: GenAICoachProps): import("react").JSX.Element | null;
export {};
//# sourceMappingURL=GenAICoach.d.ts.map