export { default } from './Email';
//# sourceMappingURL=index.d.ts.map