/**
 * @example useFocusFirstField(id, children);
 * Focuses first editable field in the view.
 */
declare const useFocusFirstField: (id: any, children: any) => void;
export default useFocusFirstField;
//# sourceMappingURL=useFocusFirstField.d.ts.map