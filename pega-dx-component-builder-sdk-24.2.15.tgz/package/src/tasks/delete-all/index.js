import inquirer from 'inquirer';

import {
  deleteLocalComponents,
  SOURCE_OF_COMPONENT_TYPES,
  deleteServerComponents,
  getDeleteComponentsQuestions
} from './helper.js';

import { showVersion, getOptionsCategory } from '../../util.js';

const deleteComponentsFn = async (sourceOfComponents, answers, options) => {

  let category;
  if (answers != null) {
    category = answers.category;
  }
  else {
    category = options.params[4];
  }

  switch (sourceOfComponents) {
    case SOURCE_OF_COMPONENT_TYPES.LOCAL: {
      await deleteLocalComponents(sourceOfComponents, category, options);
      break;
    }
    case SOURCE_OF_COMPONENT_TYPES.SERVER: {
      await deleteServerComponents(sourceOfComponents, answers, options);
      break;
    }
    default: {
      console.log('Source of components needs to be either Local or Server');
      break;
    }
  }
};

export default async options => {
  showVersion();

  let sourceOfComponentsOption = SOURCE_OF_COMPONENT_TYPES.LOCAL;
  if (options.params[3] === SOURCE_OF_COMPONENT_TYPES.LOCAL) {
    sourceOfComponentsOption = options.params[3];
    await deleteComponentsFn(sourceOfComponentsOption, null, options);
  } else if (options.params[3] === SOURCE_OF_COMPONENT_TYPES.SERVER) {
    sourceOfComponentsOption = options.params[3];
    const questions = await getDeleteComponentsQuestions(options, sourceOfComponentsOption);
    const answers = await inquirer.prompt(questions);
    await deleteComponentsFn(sourceOfComponentsOption, answers, options);
  } else {
    const questions = await getDeleteComponentsQuestions(options);
    let answers = await inquirer.prompt(questions);
    const categoryType = getOptionsCategory(options);
    let { sourceOfComponents, category } = answers;
    if (!sourceOfComponents) {
      sourceOfComponents = SOURCE_OF_COMPONENT_TYPES.LOCAL
    }
    if (categoryType != null) {
      answers.category = categoryType;
    }
    await deleteComponentsFn(sourceOfComponents, answers, options);
  }
};
