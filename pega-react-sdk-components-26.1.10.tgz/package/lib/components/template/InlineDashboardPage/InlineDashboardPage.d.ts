import { type PropsWithChildren } from 'react';
import type { GenAICoach } from '../../widget/GenAICoach/GenAICoach.types';
import type { PConnProps } from '../../../types/PConnProps';
interface InlineDashboardPageProps extends PConnProps {
    title: string;
    icon?: string;
    filterPosition?: string;
    coaches?: GenAICoach[];
    localeReference?: string;
}
export default function InlineDashboardPage(props: PropsWithChildren<InlineDashboardPageProps>): string | number | bigint | boolean | import("react").JSX.Element | Iterable<import("react").ReactNode> | Promise<string | number | bigint | boolean | import("react").ReactPortal | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | Iterable<import("react").ReactNode> | null | undefined> | null | undefined;
export {};
//# sourceMappingURL=InlineDashboardPage.d.ts.map