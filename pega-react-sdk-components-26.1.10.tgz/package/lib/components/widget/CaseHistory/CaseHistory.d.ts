import type { PConnProps } from '../../../types/PConnProps';
interface CaseHistoryProps extends PConnProps {
}
export default function CaseHistory(props: CaseHistoryProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=CaseHistory.d.ts.map