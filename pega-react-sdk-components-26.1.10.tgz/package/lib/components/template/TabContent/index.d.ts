export { default } from './TabContent';
//# sourceMappingURL=index.d.ts.map