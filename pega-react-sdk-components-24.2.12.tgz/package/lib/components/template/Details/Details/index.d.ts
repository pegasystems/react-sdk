export { default } from './Details';
//# sourceMappingURL=index.d.ts.map