export { default } from './LeftAlignVerticalTabs';
