export { default } from './SelectableCard';
//# sourceMappingURL=index.d.ts.map