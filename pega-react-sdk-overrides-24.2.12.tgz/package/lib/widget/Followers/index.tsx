export { default } from './Followers';
