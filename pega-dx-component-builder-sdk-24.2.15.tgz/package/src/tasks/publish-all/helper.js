import fs from 'fs';
import path from 'path';

import fetch from 'node-fetch';
import AdmZip from 'adm-zip';
import chalk from 'chalk';

import {
  constructCompleteUrl,
  getComponentDirectoryPath,
  getComponentsObj,
  validateRulesetVersion,
  getPegaServerConfig,
  getOptionsCategory,
  getLocalComponentKeyFromConfig,
  getFramework,
  getHttpsAgent
} from '../../util.js';

import { PUBLISH_COMPONENT_SERVICE_REST_ENDPOINT,
  TOKEN_PATH,
  COMPONENT_SCHEMA,
  CATEGORY_CONSTELLATION,
  CATEGORY_CUSTOM } from '../../constants.js';


export const mapConfigJsonToCompanion = async ( componentKey ) => {
  const srcDirectory = await getComponentDirectoryPath(componentKey, CATEGORY_CUSTOM);
  let configContent = fs.readFileSync(`${srcDirectory}/config.json`, { encoding: 'utf8' });
  const framework = await getFramework();

  let associatedComponentKey = componentKey;

  switch (framework) {
    case "SDK-Angular":
      let arComp = associatedComponentKey.split("/");
      const componentKeyPascal = await getLocalComponentKeyFromConfig(associatedComponentKey);
      arComp[1] = componentKeyPascal;
      associatedComponentKey = arComp.join("/")
      break;
    case "SDK-React":
      break;
    case "SDK-WebComponents":
      break;
  }

  const companionDirectory = await getComponentDirectoryPath(associatedComponentKey, CATEGORY_CONSTELLATION);

  fs.writeFileSync(`${companionDirectory}/config.json`, configContent, { encoding: 'utf8' });

}

export const removeCompanionConfigJson = async ( componentKey ) => {
  const companionDirectory = await getComponentDirectoryPath(componentKey, CATEGORY_CONSTELLATION);

  fs.rmSync(`${companionDirectory}/config.json`, { force: true });
}


export const getBuildCategory = async (options) => {
  const categoryType = getOptionsCategory(options);

  return [
    {
      name: 'category',
      type: 'rawlist',
      message: 'Category of components ?',
      choices: COMPONENT_SCHEMA.category,
      when() {
        return !options.params[4] && categoryType == null;
      }
    }
  ];
};

export const getPublishComponentQuestions = async (category) => {

  const defaultPegaConfig = await getPegaServerConfig();

  return [
    {
      name: 'rulesetName',
      message: 'Enter ruleset name',
      default: defaultPegaConfig.rulesetName,
      validate: value => {
        if (value.trim()) {
          return true;
        }
        return 'Ruleset name cannot be empty';
      }
    },
    {
      name: 'rulesetVersion',
      message: 'Enter ruleset version',
      default: defaultPegaConfig.rulesetVersion,
      validate: value => {
        if (validateRulesetVersion(value)) {
          return true;
        }
        return 'Please provide compatible version e.g 01-01-01';
      }
    },
    {
      name: 'sourceMap',
      message: 'Generate source map ?',
      default: defaultPegaConfig.sourceMap,
      when: () => false && !process.env.SOURCE_MAP
    },
    {
      name: 'devBuild',
      type: 'confirm',
      message: 'Generate development build ?',
      default: defaultPegaConfig.devBuild
    }
  ];
};

export const zipComponent = async (componentKey, category = CATEGORY_CUSTOM) => {
  const srcDirectory = await getComponentDirectoryPath(componentKey, category);

  // build temp directory doesn't have sub folder
  if (componentKey.indexOf("/") >=0) {
    const arKey = componentKey.split("/");
    componentKey = arKey[arKey.length - 1];
  }

  const buildDirectory = await path.join(path.resolve(), 'dist/components', componentKey);
  const configJson = `${srcDirectory}/config.json`;
  const configExtJson = `${srcDirectory}/config-ext.json`;
  const localizationJson = `${srcDirectory}/localizations.json`;

  const zip = new AdmZip();


  if (category === CATEGORY_CUSTOM || category == CATEGORY_CONSTELLATION) {
    zip.addLocalFolder(srcDirectory, 'src/');
    zip.addLocalFile(configJson);
    if (fs.existsSync(localizationJson)) {
      zip.addLocalFile(localizationJson);
    }
  }
  else {
    // check to see if have file
    if (fs.existsSync(configExtJson)) {
      zip.addLocalFile(configExtJson);
    }

  }

  if (category === CATEGORY_CUSTOM || category === CATEGORY_CONSTELLATION) {
    zip.addLocalFolder(buildDirectory);
  }
  const zipContent = zip.toBuffer().toString('base64');

  let configContent = "{ }";
  if (category === CATEGORY_CUSTOM || category === CATEGORY_CONSTELLATION) {
    configContent = Buffer.from(fs.readFileSync(`${srcDirectory}/config.json`)).toString();

    // cleanup will remove this directory

  }
  else {
    if (fs.existsSync(configExtJson)) {
      configContent = Buffer.from(fs.readFileSync(`${srcDirectory}/config-ext.json`)).toString();

      // cleanup will remove this directory

    }
    else {
      const tempConfig = { "componentKey" : ""};
      if (componentKey.indexOf("/") >= 0) {
        componentKey = componentKey.split("/")[1];
      }
      tempConfig.componentKey = `${componentKey}`;

      configContent = JSON.stringify(tempConfig);
    }

  }

  return { zipContent, configContent };
};

export const cleanUp = async () => {

  if (fs.existsSync('dist/components')) {
    fs.rm('dist/components', { recursive: true }, err => {
      if (err) {
        throw err;
      }
    });
  }

  if (fs.existsSync('lib')) {
    fs.rm('lib', { recursive: true }, err => {
      if (err) {
        throw err;
      }
    });
  }
}

export const publishComponentToServer = async (data, doFetch = true) => {
  const { configContent, zipContent, rulesetName, rulesetVersion } = data;
  let { componentKey } = data;


  if (componentKey.indexOf("/") >=0) {
    const arKey = componentKey.split("/");
    componentKey = arKey[arKey.length - 1];
  }

  const configContentObj = JSON.parse(configContent);

  if (configContentObj.type == null || configContentObj.subtype == null) {
    console.log(chalk.bold.yellow(`No config-ext to publish for ${componentKey}`));
    return;
  }

  const apiBody = {
    configContent,
    zipContent,
    componentKey: configContentObj.componentKey,
    publishFor: 'constellation',
    rulesetName,
    rulesetVersion,
    category: ''
  };
  const defaultPegaConfig = await getPegaServerConfig();
  const url = constructCompleteUrl(
    defaultPegaConfig.server,
    PUBLISH_COMPONENT_SERVICE_REST_ENDPOINT
  );

  // fetch if not testing
  if (doFetch) {
    try {
      const OauthData = fs.readFileSync(TOKEN_PATH, 'utf8');
      if (OauthData) {
        const {
          access_token: accessToken,
          token_type: tokenType,
          refresh_token: refreshToken
        } = JSON.parse(OauthData);
        let status = 500;
        const response = await fetch(url, {
          method: 'POST',
          agent: getHttpsAgent(defaultPegaConfig),
          headers: {
            Authorization: `${tokenType} ${accessToken}`
          },
          body: JSON.stringify(apiBody)
        });

        status = response.status;
        if (!response.ok) {
          if (status === 401) {
            throw new Error(
              'Error occurred in authentication. Please regenerate using authenticate'
            );
            // console.log(accessTokenUri, refreshToken);
            /* TODO - Handle refresh_token */
          }
          else if (status === 404){
            throw new Error('404: Server resource not found');
          }
          else if (status === 405){
            throw new Error('405: Server method not allowed');
          }
          else if (status === 408){
            throw new Error('408: Server timed out');
          }
          else if (response.status === 403) {
            throw new Error(
              'Error forbidden: User does not have privileges to Publish.'
            );
          }
          // else if (response.status === 500) {
          //   throw new Error(
          //    `Error occurred in authentication. Please regenerate using authenticate`
          //   );
          // }
          // else {
          //   throw new Error(
          //     `Server error: ${status}`
          //   );
          // }

        }

        try {
          const data = await response.json();
          if (status === 500) {
            status = 999;
            throw new Error(data.message);
          }
        }
        catch (err) {
          if (status === 500) {
              throw new Error(
               `Error occurred in authentication. Please regenerate using authenticate`
              );
          }
          else if (status === 999) {
            throw new Error (err);
          }
        }




      } else {
        throw new Error(`Error occurred in authentication. Please regenerate using authenticate`);
      }
    } catch (err) {
      throw new Error(err);
    }
  }

};
