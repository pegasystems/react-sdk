import { PropsWithChildren } from 'react';
interface RegionProps {
}
export default function Region(props: PropsWithChildren<RegionProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Region.d.ts.map