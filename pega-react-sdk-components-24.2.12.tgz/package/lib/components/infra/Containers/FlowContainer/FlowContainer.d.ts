/// <reference types="react" />
import type { PConnProps } from '../../../../types/PConnProps';
interface FlowContainerProps extends PConnProps {
    pageMessages: any[];
    rootViewElement: React.ReactNode;
    getPConnectOfActiveContainerItem: Function;
    assignmentNames: string[];
    activeContainerItemID: string;
}
export declare const FlowContainer: (props: FlowContainerProps) => import("react/jsx-runtime").JSX.Element;
declare const _default: (props: any) => import("react/jsx-runtime").JSX.Element;
export default _default;
//# sourceMappingURL=FlowContainer.d.ts.map