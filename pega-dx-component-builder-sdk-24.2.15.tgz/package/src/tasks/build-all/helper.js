import fs from 'fs';
import path from 'path';

import AdmZip from 'adm-zip';
import chalk from 'chalk';

import {
  getComponentDirectoryPath,
  getComponentsObj,
  getPegaServerConfig,
  getOptionsCategory,
} from '../../util.js';
import { COMPONENT_SCHEMA, CATEGORY_CUSTOM } from '../../constants.js';

export const cleanUp = async () => {
  if (fs.existsSync('dist/components')) {
    fs.rm('dist/components', { recursive: true }, err => {
      if (err) {
        throw err;
      }
    });
  }

  if (fs.existsSync('lib')) {
    fs.rm('lib', { recursive: true }, err => {
      if (err) {
        throw err;
      }
    });
  }
}

export const getBuildCategory = async (options) => {
  const categoryType = getOptionsCategory(options);

  return [
    {
      name: 'category',
      type: 'rawlist',
      message: 'Category of components ?',
      choices: COMPONENT_SCHEMA.category,
      when() {
        return !options.params[4] && categoryType == null;
      }
    }
  ];
};

export const getBuildComponentQuestions = async (category) => {
  const components = await getComponentsObj(true, category);
  const defaultPegaConfig = await getPegaServerConfig();

  if (components.length == 0) {
    console.log(chalk.redBright("No components to build"));
    process.exit(1);
  }

  return [
    {
      name: 'devBuild',
      type: 'confirm',
      message: 'Generate development build ?',
      default: defaultPegaConfig.devBuild
    }
  ];
};



export const zipComponent = async (componentKey, category = CATEGORY_CUSTOM) => {
  const srcDirectory = await getComponentDirectoryPath(componentKey, category);
  const buildDirectory = await path.join(path.resolve(), 'dist/components', componentKey);
  const configJson = `${srcDirectory}/config.json`;
  const localizationJson = `${srcDirectory}/localizations.json`;

  const zip = new AdmZip();

  zip.addLocalFolder(srcDirectory, 'src/');
  zip.addLocalFile(configJson);

  if (fs.existsSync(localizationJson)) {
    zip.addLocalFile(localizationJson);
  }

  zip.addLocalFolder(buildDirectory);
  const zipContent = zip.toBuffer().toString('base64');

  const configContent = Buffer.from(fs.readFileSync(`${srcDirectory}/config.json`)).toString();
  // fs.rmd('dist/components', { recursive: true }, err => {
  //   if (err) {
  //     throw err;
  //   }
  // });
  return { zipContent, configContent };
};
