import './ListView.css';
import { PConnProps } from '../../../types/PConnProps';
interface ListViewProps extends PConnProps {
    bInForm?: boolean;
    globalSearch?: boolean;
    referenceList?: any[];
    selectionMode?: string;
    referenceType?: string;
    payload?: any;
    parameters?: any;
    compositeKeys?: any;
    showDynamicFields?: boolean;
    readonlyContextList?: any;
    value: any;
}
export default function ListView(props: ListViewProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=ListView.d.ts.map