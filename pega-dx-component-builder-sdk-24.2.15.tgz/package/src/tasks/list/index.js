import inquirer from 'inquirer';
import ora from 'ora';
import chalk from 'chalk';

import {
  listLocalComponents,
  SOURCE_OF_COMPONENT_TYPES,
  getComponentsFromServer,
  displayServerComponents,
  getListComponentsQuestions
} from './helper.js';

import { showVersion, getOptionsCategory } from '../../util.js';


const getList = async (sourceOfComponents, answers, options) => {
  switch (sourceOfComponents) {
    case SOURCE_OF_COMPONENT_TYPES.LOCAL: {
      let category;
      if (answers) {
        category = answers.category;
      }
      else {
        category = options.params[4];
      }
      await listLocalComponents(sourceOfComponents, category);
      break;
    }
    case SOURCE_OF_COMPONENT_TYPES.SERVER: {
      try {
        const data = await getComponentsFromServer(answers);
        await displayServerComponents(data, answers);
      }
      catch (error) {

        if (error.indexOf("ECONNREFUSED") >= 0) {
          console.log(`\n${chalk.bold.red('Error occurred in authentication. Please regenerate using authenticate')}`);
        }
        else {
          console.log(`${chalk.bold.red(error)}`);
        }
        process.exit(1);

      }

      break;

    }
    default: {
      console.log('Source of components needs to be either Local or Server');
      break;
    }
  }
};

export default async options => {

  showVersion();

  let sourceOfComponentsOption = SOURCE_OF_COMPONENT_TYPES.LOCAL;

  if (options.params[3] === SOURCE_OF_COMPONENT_TYPES.LOCAL) {
    sourceOfComponentsOption = options.params[3];
    await getList(sourceOfComponentsOption, null, options);
  } else if (options.params[3] === SOURCE_OF_COMPONENT_TYPES.SERVER) {
    sourceOfComponentsOption = options.params[3];
    const questions = await getListComponentsQuestions(options, sourceOfComponentsOption);
    const answers = await inquirer.prompt(questions);
    await getList(sourceOfComponentsOption, answers), options;
  } else {
    const questions = await getListComponentsQuestions(options);
    let answers = await inquirer.prompt(questions);
    const categoryType = getOptionsCategory(options);
    let { sourceOfComponents, category } = answers;
    if (!sourceOfComponents) {
      sourceOfComponents = SOURCE_OF_COMPONENT_TYPES.LOCAL
    }
    if (categoryType != null) {
      answers.category = categoryType;
    }
    await getList(sourceOfComponents, answers, options);
  }
};
