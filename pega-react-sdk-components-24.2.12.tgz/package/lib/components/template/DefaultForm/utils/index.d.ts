export declare const mapStateToProps: any;
export declare const getKeyForMappedField: (field: any) => any;
//# sourceMappingURL=index.d.ts.map