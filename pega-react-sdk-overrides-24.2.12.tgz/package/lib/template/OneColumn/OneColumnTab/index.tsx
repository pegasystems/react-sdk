export { default } from './OneColumnTab';
