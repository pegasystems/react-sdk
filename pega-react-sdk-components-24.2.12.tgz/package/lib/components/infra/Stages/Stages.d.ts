import { PConnProps } from '../../../types/PConnProps';
interface StagesProps extends PConnProps {
    stages: any[];
}
export default function Stages(props: StagesProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Stages.d.ts.map