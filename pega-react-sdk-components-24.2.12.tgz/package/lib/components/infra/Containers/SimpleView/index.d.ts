export { default } from './SimpleView';
//# sourceMappingURL=index.d.ts.map