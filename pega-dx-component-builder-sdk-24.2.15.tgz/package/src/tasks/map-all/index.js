import inquirer from 'inquirer';
import { Listr } from 'listr2';
import chalk from 'chalk';

import { showVersion, getOptionsCategory, getComponentsObj, getFramework, convertIntoKebabCase, convertIntoPascalCase } from '../../util.js';
import { updateComponentMap  } from '../map/map.js';
import { getBuildCategory } from './helper.js';




export default async options => {
  showVersion();

  const framework = await getFramework();

  const catQuestion = await getBuildCategory(options);
  const catAnswers = await inquirer.prompt(catQuestion);

  let category = catAnswers.category;
  if (category == null) {
    category = getOptionsCategory(options);
  }


  const components = await getComponentsObj(false, category);


  let componentKey;

  const customTasks = new Listr(
    [
      {
        title: 'Update component map',
        task: async () => {
            await updateComponentMap(componentKey, category);
        }
      }

    ],
    {
      exitOnError: true
    }
  );


  for (var index in components) {
    componentKey = components[index].value;
    console.log(chalk.bold.green("Mapping: " + components[index].name));

    switch (framework) {
      case "SDK-Angular":
        // componentKey is in Pascal case, which is associated, need to convert to Kabab case
        let arComp = componentKey.split("/");
        arComp[1] = convertIntoKebabCase(convertIntoPascalCase(arComp[1]));
        componentKey = arComp.join("/");
        break;
      case "SDK-React":
        break;
      case "SDK-WebComponents":
        break;
    }

    await customTasks.run().catch(err => {
        console.log(chalk.bold.red(err.toString()));
    });
  }


  return true;
};
