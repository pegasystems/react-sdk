import type { MarkdownMap } from '../GenAICoachContent/GenAICoach.types';
interface AgentRichTextViewerProps {
    content: string;
    markdownMap?: MarkdownMap;
}
/**
 * Renders agent markdown: the Cosmos `AgentRichTextViewer` (a `RichTextViewer` in markdown mode).
 * The markdown is parsed with `marked.lexer()` and the tokens are rendered as React elements, so no HTML
 * string is ever injected; raw HTML in the markdown is shown as plain text.
 * `markdownMap` maps a token type to a function returning the component that renders that token instead.
 * Memoised so completed messages are not re-rendered while another message streams.
 */
declare function AgentRichTextViewer(props: AgentRichTextViewerProps): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof AgentRichTextViewer>;
export default _default;
//# sourceMappingURL=AgentRichTextViewer.d.ts.map