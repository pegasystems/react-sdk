export { default } from './SubTabs';
//# sourceMappingURL=index.d.ts.map