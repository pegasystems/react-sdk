import type { PConnProps } from '../../../../types/PConnProps';
interface SimpleTableSelectProps extends PConnProps {
    label: string;
    referenceList: object[] | string;
    renderMode: string;
    showLabel: boolean;
    promptedFilters: object[];
    viewName: string;
    parameters: any;
    readonlyContextList: object[] | string;
    dataRelationshipContext: string;
    defaultRowHeight: string | number;
    showPromotedFilters: boolean;
    displayAs: string;
    contextPage: object;
    toggleFieldVisibility: boolean;
}
export default function SimpleTableSelect(props: SimpleTableSelectProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=SimpleTableSelect.d.ts.map