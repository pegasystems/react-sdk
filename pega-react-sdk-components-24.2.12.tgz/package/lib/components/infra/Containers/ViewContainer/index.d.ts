export { default } from './ViewContainer';
//# sourceMappingURL=index.d.ts.map