import type { ErrorResponse, MessageResponse, StreamEvent, StreamResponse } from '../widget/GenAICoach/GenAICoach.types';
import type { QuestionnaireConfig } from '../designSystemExtension/GenAICoachContent/GenAICoach.types';
interface LocalizationService {
    getLocalizedText: (text: string) => string;
}
export declare const normalizeErrorResponse: (e: unknown, l11nService: LocalizationService, fallbackMessage?: string) => ErrorResponse;
/**
 * Parses a questionnaire payload that arrives on a conversation history message.
 *
 * The history API serializes the questionnaire as a JSON string of the shape
 * `{ component: 'questionnaire', props: '<json string>' }`, where `props` is
 * itself a JSON string of `{ questionnaire: { questions: Question[] } }`.
 */
export declare const parseQuestionnaireFromHistory: (questionnaire: string | undefined) => QuestionnaireConfig | undefined;
export declare const handleMessageStream: (result: StreamResponse, streamHandler?: ({ data, streaming }: {
    data: string;
    streaming: boolean;
}) => void, errorHandler?: (error: ErrorResponse) => void, agentStreamHandler?: (event: StreamEvent) => void, questionnaireHandler?: (data: QuestionnaireConfig) => void) => Promise<MessageResponse | undefined>;
export {};
//# sourceMappingURL=message-stream-utils.d.ts.map