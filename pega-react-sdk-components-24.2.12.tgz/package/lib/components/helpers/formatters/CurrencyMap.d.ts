type CurrencyMapType = {
    name: string;
    symbolFormat: string;
    currencyCode: string;
};
declare const _default: {
    AF: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AL: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    DZ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AO: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AM: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AW: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AU: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AZ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BS: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BH: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BD: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BB: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BY: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BZ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BM: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BT: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BO: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BA: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BW: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    GB: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BN: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BG: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    BI: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    KH: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CA: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CV: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    KYD: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    XO: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    XA: CurrencyMapType;
    BJ: CurrencyMapType;
    BF: CurrencyMapType;
    CM: CurrencyMapType;
    CF: CurrencyMapType;
    TD: CurrencyMapType;
    CG: CurrencyMapType;
    CI: CurrencyMapType;
    GQ: CurrencyMapType;
    GA: CurrencyMapType;
    GW: CurrencyMapType;
    ML: CurrencyMapType;
    NE: CurrencyMapType;
    SN: CurrencyMapType;
    TG: CurrencyMapType;
    CL: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CN: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CO: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    KM: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CD: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    HR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CU: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CZ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    DK: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    DJ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    DO: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AI: CurrencyMapType;
    AG: CurrencyMapType;
    DM: CurrencyMapType;
    GD: CurrencyMapType;
    MS: CurrencyMapType;
    KN: CurrencyMapType;
    LC: CurrencyMapType;
    VC: CurrencyMapType;
    EG: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SV: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    ER: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    ET: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    FK: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    FJ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    GM: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    GE: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    GH: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    GI: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    XAU: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    GT: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    GG: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    GN: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    GY: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    HN: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    HK: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    HU: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    IS: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    IN: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    ID: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    IR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    IQ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    IM: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    IL: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    JM: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    JP: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    JEP: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    JO: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    KZ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    KE: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    KR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    KW: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    KG: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    LA: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    LB: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    LS: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    LR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    LY: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MO: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MK: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MG: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MW: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MY: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MV: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MU: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MX: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MD: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MN: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MA: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MZ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    MM: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    NA: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    NP: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AN: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    NZ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CK: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    NU: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    PN: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    NI: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    NG: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    KP: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    NO: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    OM: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    PF: CurrencyMapType;
    NC: CurrencyMapType;
    WF: CurrencyMapType;
    PK: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    XPD: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    PA: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    PG: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    PY: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    PE: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    PH: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    XPT: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    PL: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    QA: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    RO: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    RU: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    RW: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    WS: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    ST: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SA: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    RS: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SC: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SL: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    XAG: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SG: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SB: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SO: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    TJ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    ZA: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    LK: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SH: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AC: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SS: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SZ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SE: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    CH: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    SY: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    TW: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    TZ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    TH: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    TO: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    TT: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    TN: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    TR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    TM: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    US: CurrencyMapType;
    AS: CurrencyMapType;
    IO: CurrencyMapType;
    VG: CurrencyMapType;
    GU: CurrencyMapType;
    HT: CurrencyMapType;
    MH: CurrencyMapType;
    FM: CurrencyMapType;
    MP: CurrencyMapType;
    PW: CurrencyMapType;
    PR: CurrencyMapType;
    TC: CurrencyMapType;
    VI: CurrencyMapType;
    AE: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    UG: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    UA: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    UY: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    UZ: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    VU: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    VE: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    VN: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    YE: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    YU: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    ZR: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    ZM: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    ZW: {
        name: string;
        symbolFormat: string;
        currencyCode: string;
    };
    AD: CurrencyMapType;
    AT: CurrencyMapType;
    BE: CurrencyMapType;
    CY: CurrencyMapType;
    EE: CurrencyMapType;
    FI: CurrencyMapType;
    FR: CurrencyMapType;
    DE: CurrencyMapType;
    GR: CurrencyMapType;
    IE: CurrencyMapType;
    IT: CurrencyMapType;
    XK: CurrencyMapType;
    LV: CurrencyMapType;
    LT: CurrencyMapType;
    LU: CurrencyMapType;
    MT: CurrencyMapType;
    MC: CurrencyMapType;
    ME: CurrencyMapType;
    NL: CurrencyMapType;
    PT: CurrencyMapType;
    SM: CurrencyMapType;
    SK: CurrencyMapType;
    SI: CurrencyMapType;
    ES: CurrencyMapType;
    VA: CurrencyMapType;
};
export default _default;
//# sourceMappingURL=CurrencyMap.d.ts.map