export { default } from './DashboardFilter';
//# sourceMappingURL=index.d.ts.map