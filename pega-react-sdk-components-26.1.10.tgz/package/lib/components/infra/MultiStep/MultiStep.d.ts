import React, { type PropsWithChildren } from 'react';
import type { PConnProps } from '../../../types/PConnProps';
import './MultiStep.css';
interface MultiStepProps extends PConnProps {
    itemKey: string;
    actionButtons: any[];
    onButtonPress: any;
    stepIndicator?: 'horizontal' | 'vertical' | 'vertical-start';
    arNavigationSteps: any;
}
export default function MultiStep(props: PropsWithChildren<MultiStepProps>): React.JSX.Element;
export {};
//# sourceMappingURL=MultiStep.d.ts.map