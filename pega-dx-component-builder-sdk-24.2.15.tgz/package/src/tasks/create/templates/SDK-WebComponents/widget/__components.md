# The **Widget** directory

The **SDK-WebComponents/Widget** directory contains the template code for the widget components you want to use with the **WebComponents SDK**.

