export declare function isEmptyObject(obj: Object): boolean;
/**
 * Get a localized value from the Generic Fields
 * @param path - The path within Generic Fields (e.g., 'CosmosFields.fields.lists')
 * @param key - The key of the string to localize
 * @returns The localized string or the key itself if no translation is found
 */
export declare function getGenericFieldsLocalizedValue(path: string, key: string): string;
//# sourceMappingURL=common-utils.d.ts.map