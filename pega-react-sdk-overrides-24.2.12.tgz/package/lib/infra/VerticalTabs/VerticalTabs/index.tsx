export { default } from './VerticalTabs';
