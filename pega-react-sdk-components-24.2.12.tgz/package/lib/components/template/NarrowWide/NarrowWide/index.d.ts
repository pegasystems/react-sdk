export { default } from './NarrowWide';
//# sourceMappingURL=index.d.ts.map