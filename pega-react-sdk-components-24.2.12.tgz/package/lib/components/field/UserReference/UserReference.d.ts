/// <reference types="react" />
import { PConnProps } from '../../../types/PConnProps';
interface UserReferenceProps extends PConnProps {
    displayAs?: string;
    displayMode?: string;
    label?: string;
    value?: any;
    testId?: string;
    placeholder?: string;
    helperText?: string;
    disabled?: boolean;
    readOnly?: boolean;
    required?: boolean;
    validatemessage?: string;
    showAsFormattedText?: boolean;
    additionalProps?: object;
    hideLabel?: boolean;
    variant?: string;
    onChange?: any;
}
declare const _default: import("react").MemoExoticComponent<(props: UserReferenceProps) => any>;
export default _default;
//# sourceMappingURL=UserReference.d.ts.map