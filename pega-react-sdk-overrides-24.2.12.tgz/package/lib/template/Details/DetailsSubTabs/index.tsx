export { default } from './DetailsSubTabs';
