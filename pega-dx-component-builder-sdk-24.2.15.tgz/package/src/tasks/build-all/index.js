import inquirer from 'inquirer';
import { Listr } from 'listr2';
import chalk from 'chalk';

import validate from '../validator/index.js';

import { bundleReactComponent, bundleAngularComponent, bundleAssociatedComponent} from '../bundle/index.js';
import lintComponent from '../linter/index.js';
import { getBuildComponentQuestions, getBuildCategory, cleanUp } from './helper.js';
import { getComponentDirectoryPath, showVersion, getOptionsCategory, getComponentsObj, getFramework, getLocalComponentKeyFromConfig, convertIntoKebabCase, convertIntoPascalCase } from '../../util.js';

import { CATEGORY_CUSTOM } from '../../constants.js';



export function getCustomTasks(componentKey, category, sourceMap, devBuild, content, options, associatedComponentKey, framework) {


  const sDevBuild = devBuild ? '(dev build)' : '';
  const sFramework = framework.split("-")[1];

  return new Listr(
    [
      {
        title: 'Validate config schema',
        task: async () => {
          await validate(componentKey, category);
        }
      },
      {
        title: `Lint ${sFramework} component`,
        task: async () => {
          const targetDirectory = await getComponentDirectoryPath(componentKey, category);
          // console.log(`in buildComponent Lint component task: componentKey: ${componentKey} targetDirectory: ${targetDirectory}`);
          await lintComponent(targetDirectory);
        }
      },
      {
        title: `Bundle React component ${sDevBuild}`,
        task: async () => await bundleReactComponent(componentKey, sourceMap, devBuild, category),
        enabled: ok => framework === "SDK-React"
      },
      {
        title: `Bundle Angular component ${sDevBuild}`,
        task: async () => await bundleAngularComponent(componentKey, sourceMap, devBuild, category),
        enabled: ok => framework === "SDK-Angular"
      },
      {
        title: 'Lint associated component',
        task: async () => {
          const targetDirectory = await getComponentDirectoryPath(associatedComponentKey, "constellation");
          // console.log(`in buildComponent Lint component task: componentKey: ${componentKey} targetDirectory: ${targetDirectory}`);
          await lintComponent(targetDirectory);
        }
      },
      {
        title: `Bundle associated component ${sDevBuild}`,
        task: async () => await bundleAssociatedComponent(associatedComponentKey, sourceMap, devBuild, "constellation")
      }
    ],
    {
      exitOnError: true
    }
  );

}


export function getOverrideTasks(componentKey, category, sourceMap, devBuild, content, options, framework) {
  const sDevBuild = devBuild ? '(dev build)' : '';
  const sFramework = framework.split("-")[1];
  return new Listr(
    [
      {
        title: 'Validate config schema',
        task: async () => {
          await validate(componentKey, category);
        }
      },
      {
        title: `Lint ${sFramework} component`,
        task: async () => {
          const targetDirectory = await getComponentDirectoryPath(componentKey, category);
          // console.log(`in buildComponent Lint component task: componentKey: ${componentKey} targetDirectory: ${targetDirectory}`);
          await lintComponent(targetDirectory);
        }
      },
      {
        title: `Bundle React component ${sDevBuild}`,
        task: async () => await bundleReactComponent(componentKey, sourceMap, devBuild, category),
        enabled: ok => framework === "SDK-React"
      },
      {
        title: `Bundle Angular component ${sDevBuild}`,
        task: async () => await bundleAngularComponent(componentKey, sourceMap, devBuild, category),
        enabled: ok => framework === "SDK-Angular"
      }
    ],
    {
      exitOnError: true
    }
  );

}

export default async options => {
  showVersion();

  const framework = await getFramework();

  let sourceMap;
  let devBuild;
  let category;
  let content;
  let components;

  if (options.params.length >= 5) {
    category = options.params[3];
    const dBuild = options.params[4];
    devBuild = (dBuild === 'Y' ||
    dBuild === 'y' ||
    dBuild === true ||
    dBuild === 'true') ? true : false;

    content = { devBuild };
    components = await getComponentsObj(false, category);
  }
  else {
    const catQuestion = await getBuildCategory(options);
    const catAnswers = await inquirer.prompt(catQuestion);

    category = catAnswers.category;
    if (category == null) {
      category = getOptionsCategory(options);
    }

    components = await getComponentsObj(false, category);
    const questions = await getBuildComponentQuestions(category);
    const answers = await inquirer.prompt(questions);
    ({ sourceMap, devBuild } = answers);

    content = {
      ...answers
    };
  }

  if (category === CATEGORY_CUSTOM) {
    for (const component of components) {
      let componentKey = component.value;
      const componentKeyName = component.name;
      console.log(chalk.bold.green(`Building: ${componentKeyName}`));

      let associatedComponentKey = componentKey;

      switch (framework) {
        case "SDK-Angular":
          let arComp = componentKey.split("/");
          arComp[1] = convertIntoKebabCase(convertIntoPascalCase(arComp[1]));
          componentKey = arComp.join("/")
          break;
        case "SDK-React":
          break;
        case "SDK-WebComponents":
          break;
      }

      // switch (framework) {
      //   case "SDK-Angular":
      //     let arComp = associatedComponentKey.split("/");
      //     const componentKeyPascal = await getLocalComponentKeyFromConfig(associatedComponentKey);
      //     arComp[1] = componentKeyPascal;
      //     associatedComponentKey = arComp.join("/")
      //     break;
      //   case "SDK-React":
      //     break;
      //   case "SDK-WebComponents":
      //     break;
      // }

      let myCustomTasks = getCustomTasks(componentKey, category, sourceMap, devBuild, content, options, associatedComponentKey, framework);

      await myCustomTasks.run().catch(err => {
         console.log(chalk.bold.red(err.toString()));
         process.exit(1);
      });
    }
  }
  else {
    for (const component of components) {
      const componentKey = component.value;
      const componentKeyName = component.name;
      console.log(chalk.bold.green(`Building: ${componentKeyName}`));

      let myOverrideTasks = getOverrideTasks(componentKey, category, sourceMap, devBuild, content, options, framework);

      await myOverrideTasks.run().catch(err => {
         console.log(chalk.bold.red(err.toString()));
         process.exit(1);
      });
    }
  }

  await cleanUp();

  return true;
};
