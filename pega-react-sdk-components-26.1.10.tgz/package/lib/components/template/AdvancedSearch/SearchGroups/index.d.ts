export { default } from './SearchGroups';
//# sourceMappingURL=index.d.ts.map