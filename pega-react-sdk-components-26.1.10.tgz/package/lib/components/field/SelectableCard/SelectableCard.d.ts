export default function SelectableCard(props: any): import("react").JSX.Element;
//# sourceMappingURL=SelectableCard.d.ts.map