import './CaseSummaryFields.css';
interface CaseSummaryFieldsProps {
    status?: string;
    showStatus?: boolean;
    theFields: any[] | any | never;
    variant?: 'primary' | 'secondary';
}
export default function CaseSummaryFields(props: CaseSummaryFieldsProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=CaseSummaryFields.d.ts.map