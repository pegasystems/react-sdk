export { default } from './WideNarrowForm';
//# sourceMappingURL=index.d.ts.map