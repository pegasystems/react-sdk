import React from 'react';
import './PromotedFilters.css';
import type { PConnProps } from '../../../types/PConnProps';
interface PromotedFilterProps extends PConnProps {
    viewName: string;
    filters: any[];
    listViewProps: any;
    pageClass: string;
    parameters?: object;
}
export default function PromotedFilters(props: PromotedFilterProps): React.JSX.Element;
export {};
//# sourceMappingURL=PromotedFilters.d.ts.map