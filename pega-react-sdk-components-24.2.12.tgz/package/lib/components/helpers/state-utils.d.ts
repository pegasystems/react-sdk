declare const connectToState: (mapStateToProps?: () => void) => (Component: any) => (ownProps?: {}) => import("react/jsx-runtime").JSX.Element;
export default connectToState;
//# sourceMappingURL=state-utils.d.ts.map