import path from 'path';
import fs from 'fs';

import chalk from 'chalk';
import inquirer from 'inquirer';
import Ajv from 'ajv';

import { COMPONENT_SCHEMA, CATEGORY_CUSTOM, CATEGORY_OVERRIDE } from '../../constants.js';
import {
  getComponentDirectoryPath,
  getComponents,
  getOOTBComponents,
  removeComponentPrefix,
  getFramework,
  getLocalComponentKeyFromConfig
} from '../../util.js';

const ajv = new Ajv({ allErrors: true });

// const combinationTypes = ['PAGE', 'CASE'];

const allowedSubtypes = [
  ...new Set([
    ...COMPONENT_SCHEMA.subtype.field.map(({ value }) => value),
    ...COMPONENT_SCHEMA.subtype.template.map(({ value }) => value),
    ...COMPONENT_SCHEMA.subtype.widget.map(({ value }) => value)
  ])
];

const allowedOverrideTypes = [
  ...new Set([...COMPONENT_SCHEMA.type.map(({ value }) => value)]),
  'Group'
];

// additional subtypes are manually added below
const allowedOverrideSubtypes = [
  ...new Set([
    ...COMPONENT_SCHEMA.subtype.field.map(({ value }) => value),
    ...COMPONENT_SCHEMA.subtype.template.map(({ value }) => value),
    ...COMPONENT_SCHEMA.subtype.widget.map(({ value }) => value)
  ]),
  'ACTION',
  'DATA_CAPTURE',
  'SUMMARY',
  'CASEVIEW',
  'DATAVIEW',
  'LIST',
  'TAB'
];

const schema = {
  type: 'object',
  properties: {
    baseComponentName: { type: 'string' },
    componentKey: { type: 'string', pattern: '^[A-Za-z0-9]+_[A-Za-z0-9]+_[A-Za-z0-9]+$' },
    name: { type: 'string', pattern: '^[A-Za-z0-9]+_[A-Za-z0-9]+_[A-Za-z0-9]+$' },
    label: { type: 'string' },
    description: { type: 'string' },
    organization: { type: 'string' },
    version: { type: 'string' },
    library: { type: 'string' },
    allowedApplications: { type: 'array' },
    type: { type: 'string', enum: COMPONENT_SCHEMA.type.map(({ value }) => value) },
    subtype: {
      anyOf: [{ type: 'string' }, { type: 'array' }],

      enum: allowedSubtypes
    },
    icon: { type: 'string' },
    properties: {
      type: 'array',
      uniqueItems: true,
      items: {
        anyOf: [
          {
            type: 'object',
            properties: {
              name: { type: 'string' },
              label: { type: 'string' },
              format: { type: 'string' }
            },
            required: ['name', 'label', 'format']
          },
          {
            type: 'object',
            properties: {
              format: { type: 'string' },
              source: {
                type: 'object',
                properties: {
                  name: { type: 'string' },
                  label: { type: 'string' },
                  format: { type: 'string' }
                },
                required: ['name', 'label', 'format']
              },
              cascadeElements: {
                type: 'array',
                uniqueItems: true,
                items: {
                  anyOf: [
                    {
                      type: 'object',
                      properties: {
                        key: { type: 'string' },
                        name: { type: 'string' },
                        label: { type: 'string' },
                        format: { type: 'string' }
                      },
                      required: ['key', 'name', 'label', 'format']
                    }
                  ]
                }
              }
            },
            required: ['format']
          },
          {
            type: 'object',
            properties: {
              label: { type: 'string' },
              format: { type: 'string' },
              properties: {
                type: 'array',
                uniqueItems: true,
                items: {
                  anyOf: [
                    {
                      type: 'object',
                      properties: {
                        name: { type: 'string' },
                        label: { type: 'string' },
                        format: { type: 'string' }
                      },
                      required: ['name', 'label', 'format']
                    },
                    {
                      type: 'object',
                      properties: {
                        variant: { type: 'string' },
                        label: { type: 'string' },
                        format: { type: 'string' }
                      },
                      required: ['variant', 'label', 'format']
                    },
                    {
                      type: 'object',
                      properties: {
                        format: { type: 'string' },
                        elements: {
                          type: 'array',
                          uniqueItems: true,
                          items: {
                            anyOf: [
                              {
                                type: 'object',
                                properties: {
                                  key: { type: 'string' },
                                  name: { type: 'string' },
                                  label: { type: 'string' },
                                  format: { type: 'string' },
                                  variant: { type: 'string' }
                                },
                                required: ['key', 'format', 'label']
                              }
                            ]
                          }
                        }
                      },
                      required: ['format', 'elements']
                    }
                  ]
                }
              }
            },
            required: ['label', 'format']
          }
        ]
      }
    },
    defaultConfig: { type: 'object' }
  },
  required: ['componentKey', 'name', 'description', 'type', 'subtype', 'properties'],
  additionalProperties: true
};

const overrideSchema = {
  type: 'object',
  properties: {
    baseComponentName: { type: 'string' },
    componentKey: { type: 'string', pattern: '^[A-Za-z0-9]+$' },
    name: { type: 'string', pattern: '^[A-Za-z0-9]+$' },
    label: { type: 'string' },
    description: { type: 'string' },
    organization: { type: 'string' },
    version: { type: 'string' },
    library: { type: 'string' },
    allowedApplications: { type: 'array' },
    type: { type: 'string', enum: allowedOverrideTypes },
    subtype: {
      anyOf: [{ type: 'string' }, { type: 'array' }],

      enum: allowedOverrideSubtypes
    },
    icon: { type: 'string' },
    properties: {
      type: 'array',
      uniqueItems: true,
      items: {
        anyOf: [
          {
            type: 'object',
            properties: {
              name: { type: 'string' },
              label: { type: 'string' },
              format: { type: 'string' }
            },
            required: ['name', 'label', 'format']
          },
          {
            type: 'object',
            properties: {
              format: { type: 'string' },
              source: {
                type: 'object',
                properties: {
                  name: { type: 'string' },
                  label: { type: 'string' },
                  format: { type: 'string' }
                },
                required: ['name', 'label', 'format']
              },
              cascadeElements: {
                type: 'array',
                uniqueItems: true,
                items: {
                  anyOf: [
                    {
                      type: 'object',
                      properties: {
                        key: { type: 'string' },
                        name: { type: 'string' },
                        label: { type: 'string' },
                        format: { type: 'string' }
                      },
                      required: ['key', 'name', 'label', 'format']
                    }
                  ]
                }
              }
            },
            required: ['format']
          },
          {
            type: 'object',
            properties: {
              label: { type: 'string' },
              format: { type: 'string' },
              properties: {
                type: 'array',
                uniqueItems: true,
                items: {
                  anyOf: [
                    {
                      type: 'object',
                      properties: {
                        name: { type: 'string' },
                        label: { type: 'string' },
                        format: { type: 'string' }
                      },
                      required: ['name', 'label', 'format']
                    },
                    {
                      type: 'object',
                      properties: {
                        variant: { type: 'string' },
                        label: { type: 'string' },
                        format: { type: 'string' }
                      },
                      required: ['variant', 'label', 'format']
                    },
                    {
                      type: 'object',
                      properties: {
                        format: { type: 'string' },
                        elements: {
                          type: 'array',
                          uniqueItems: true,
                          items: {
                            anyOf: [
                              {
                                type: 'object',
                                properties: {
                                  key: { type: 'string' },
                                  name: { type: 'string' },
                                  label: { type: 'string' },
                                  format: { type: 'string' },
                                  variant: { type: 'string' }
                                },
                                required: ['key', 'format', 'label']
                              }
                            ]
                          }
                        }
                      },
                      required: ['format', 'elements']
                    }
                  ]
                }
              }
            },
            required: ['label', 'format']
          }
        ]
      }
    },
    defaultConfig: { type: 'object' }
  },
  required: ['name', 'type', 'subtype', 'properties', 'componentKey'],
  additionalProperties: true
};

const validateSchema = ajv.compile(schema);
const validateOverrideSchema = ajv.compile(overrideSchema);

export default async (option, category = CATEGORY_CUSTOM) => {
  let componentToValidate = null;
  const framework = await getFramework();

  if (option.params && option.params[3]) {
    componentToValidate = option.params[3];
  } else if (option && option.task === 'validateSchema') {
    const localComponents = await getComponents();
    const answer = await inquirer.prompt({
      name: 'component',
      type: 'rawlist',
      message: 'Select component to validate',
      choices: localComponents
    });

    componentToValidate = answer.component;
  } else if (option.name) {
    componentToValidate = option.value;
  } else {
    componentToValidate = option;
  }

  const componentDirectory = await getComponentDirectoryPath(componentToValidate, category);
  let configFileName = 'config.json';
  if (category === CATEGORY_OVERRIDE) {
    configFileName = 'config-ext.json';
  }
  const configFile = path.join(componentDirectory, configFileName);
  let configData;
  try {
    configData = fs.readFileSync(path.resolve(configFile), 'utf8');
  } catch (err) {
    if (category === CATEGORY_CUSTOM) {
      throw new Error(`Missing config file for: ${componentToValidate}`);
    } else if (category === CATEGORY_OVERRIDE) {
      // for now, if now file just end
      console.log(`${chalk.bold.yellow(`Config file not available for: ${componentToValidate}`)}`);
      return;
    }
  }

  // const data = JSON.parse(fs.readFileSync(path.resolve(configFile), 'utf8'));
  let data;
  try {
    data = JSON.parse(configData);
  }
  catch (er) {
    throw new Error(`Invalid schema json in config.json: ${er}`);
  }

  // for now a special case for ScalarList & Group, those doesn't have a "subtype", so for now manualy
  // add one in here, just to pass validation
  if (data.name === 'ScalarList') {
    data.subtype = 'LIST';
  }
  if (data.name === 'Group') {
    data.subtype = 'DATA_CAPTURE';
  }

  const valid =
    category === CATEGORY_OVERRIDE ? validateOverrideSchema(data) : validateSchema(data);

  if (valid) {
    // need to remove path
    const originalComponentToValidate = componentToValidate;
    componentToValidate = removeComponentPrefix(componentToValidate);

    // don't check for out the box if override
    if (category !== CATEGORY_OVERRIDE) {
      // we are validating the component name, not the actual component
      // so need to get the component name (or key) from config.json
      switch (framework) {
        case 'SDK-Angular':
          componentToValidate = await getLocalComponentKeyFromConfig(originalComponentToValidate);
          break;
        case 'SDK-React':
          break;
        case 'SDK-WebComponents':
          break;
        default:
          break;
      }

      if (
        componentToValidate &&
        !/^[A-Za-z0-9]+_[A-Za-z0-9]+_[A-Za-z0-9]+$/.test(componentToValidate)
      ) {
        const ootbComponents = await getOOTBComponents();
        if (ootbComponents.includes(componentToValidate)) {
          throw new Error(`Invalid: Error occurred in validating ${componentToValidate}`);
        }
      }
    }

    console.log(`${chalk.bold.green(componentToValidate)} schema is valid`);
  } else {
    // eslint-disable-next-line no-lonely-if
    if (category === CATEGORY_OVERRIDE) {
      throw new Error(`Invalid: ${ajv.errorsText(validateOverrideSchema.errors)}`);
    } else {
      throw new Error(`Invalid: ${ajv.errorsText(validateSchema.errors)}`);
    }
  }
};
