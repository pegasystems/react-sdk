export declare function getFieldMeta(getPConnect: any, dataRelationshipContext: any): {
    compositeKeys: any;
    fieldMetadata: any;
};
export declare const getFirstChildConfig: ({ firstChildMeta, getPConnect, rawViewMetadata, contextClass, dataReferenceConfigToChild, isCreateNewReferenceEnabled, disableStartingFieldsForReference, pyID }: {
    firstChildMeta: any;
    getPConnect: any;
    rawViewMetadata: any;
    contextClass: any;
    dataReferenceConfigToChild: any;
    isCreateNewReferenceEnabled: any;
    disableStartingFieldsForReference: any;
    pyID: any;
}) => any;
//# sourceMappingURL=utils.d.ts.map