export { default } from './Phone';
//# sourceMappingURL=index.d.ts.map