import type { PropsWithChildren } from 'react';
import type { PConnProps } from '../../../../types/PConnProps';
interface TwoColumnTabProps extends PConnProps {
    templateCol?: string;
}
export default function TwoColumnTab(props: PropsWithChildren<TwoColumnTabProps>): import("react").JSX.Element;
export {};
//# sourceMappingURL=TwoColumnTab.d.ts.map