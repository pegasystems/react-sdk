import type { ConversationHistoryProps } from '../GenAICoachContent/GenAICoach.types';
export default function ConversationHistory(props: ConversationHistoryProps): import("react").JSX.Element;
//# sourceMappingURL=ConversationHistory.d.ts.map