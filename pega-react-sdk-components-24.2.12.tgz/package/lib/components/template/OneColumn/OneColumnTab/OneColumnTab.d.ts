import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../../types/PConnProps';
interface OneColumnTabProps extends PConnProps {
}
export default function OneColumnTab(props: PropsWithChildren<OneColumnTabProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=OneColumnTab.d.ts.map