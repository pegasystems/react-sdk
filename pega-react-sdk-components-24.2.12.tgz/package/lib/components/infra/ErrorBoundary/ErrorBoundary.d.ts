import { PConnProps } from '../../../types/PConnProps';
interface ErrorBoundaryProps extends PConnProps {
    isInternalError?: boolean;
}
export default function ErrorBoundary(props: ErrorBoundaryProps): import("react/jsx-runtime").JSX.Element | null;
export {};
//# sourceMappingURL=ErrorBoundary.d.ts.map