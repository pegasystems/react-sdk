import './PromotedFilters.css';
import { PConnProps } from '../../../types/PConnProps';
interface PromotedFilterProps extends PConnProps {
    viewName: string;
    filters: any[];
    listViewProps: any;
    pageClass: string;
    parameters?: object;
}
export default function PromotedFilters(props: PromotedFilterProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=PromotedFilters.d.ts.map