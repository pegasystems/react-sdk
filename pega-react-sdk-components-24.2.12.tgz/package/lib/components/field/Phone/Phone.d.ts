import { PConnFieldProps } from '../../../types/PConnProps';
interface PhoneProps extends PConnFieldProps {
}
export default function Phone(props: PhoneProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Phone.d.ts.map