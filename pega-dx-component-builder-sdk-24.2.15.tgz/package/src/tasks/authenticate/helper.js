/* eslint-disable import/prefer-default-export */
import { getPegaServerConfig } from '../../util.js';

import { AUTHENTICATE_SCHEMA } from '../../constants.js';

export const getAuthQuestions = async (dxcbConfig) => {
  const defaultPegaConfig = dxcbConfig;
  const aMustAsk = dxcbConfig['questions_askAlways'] ? dxcbConfig['questions_askAlways'].split(',') : [];
  const aNeverAsk = dxcbConfig['questions_askNever'] ? dxcbConfig['questions_askNever'].split(',') : [];

  const initAnswers = (answers) => {
    // Setup default answers
    answers.serverType = defaultPegaConfig.serverType || "infinity";
    answers.server = defaultPegaConfig.server || undefined;
    answers.isolationId = defaultPegaConfig.isolationId || undefined;
    answers.clientId = defaultPegaConfig.clientId || undefined;
    answers.grantType = defaultPegaConfig.grantType || "authCode";
    answers.clientSecret = defaultPegaConfig.clientSecret || undefined;
    answers.user = defaultPegaConfig.user || undefined;
    answers.password = defaultPegaConfig.password || undefined;
  }

  const fnStandardWhen = (prop, answers) => {
    if (aNeverAsk.includes(prop)) {
      return false;
    }
    return aMustAsk.includes(prop) || !answers[prop];
  };

  return [
    {
      name: 'serverType',
      type: 'rawlist',
      message: 'Enter Pega server type',
      default: answers => {
        return defaultPegaConfig.serverType;
      },
      choices: AUTHENTICATE_SCHEMA.serverType,
      validate: value => {
        if (value.trim()) {
          return true;
        }
        return 'Pega server type cannot be empty';
      },
      when: answers => {
        initAnswers(answers);
        return fnStandardWhen('serverType', answers);
      }
    },
    {
      name: 'server',
      message: 'Enter pega server url',
      default: defaultPegaConfig.server,
      when: answers =>{
        return fnStandardWhen('server', answers);
      }
    },
    {
      name: 'isolationId',
      message: 'Enter isolation id',
      default: defaultPegaConfig.isolationId,
      when: answers => {
        return answers.serverType === "launchpad" && fnStandardWhen('isolationId', answers);
      }
    },
    {
      name: 'grantType',
      type: 'rawlist',
      message: 'Enter OAuth 2.0 grant type',
      default: defaultPegaConfig.grantType,
      choices: answers => {
        return AUTHENTICATE_SCHEMA.grantType.filter(gt => !(answers.serverType === "launchpad" && gt.value === "passwordCreds"));
      },
      validate: value => {
        if (value.trim()) {
          return true;
        }
        return 'Grant type cannot be empty';
      },
      when: answers => {
        return fnStandardWhen('grantType', answers);
      }
    },
    {
      name: 'user',
      message: 'Enter user id',
      default: defaultPegaConfig.user,
      validate: (value, answers) => {
        if (value.trim() || answers.grantType === "authCode") {
          return true;
        }
        return 'Username cannot be empty';
      },
      when: answers => {
        return (answers.serverType === "infinity" && answers.grantType === "passwordCreds") && fnStandardWhen('user', answers);
      }
    },
    {
      name: 'password',
      type: 'password',
      message: 'Enter password',
      default: defaultPegaConfig.password,
      validate: (value, answers) => {
        if (value.trim() || answers.grantType === "authCode") {
          return true;
        }
        return 'Password cannot be empty';
      },
      when: answers => {
        return (answers.user && (answers.serverType === "infinity" && answers.grantType === "passwordCreds") && fnStandardWhen('password', answers));
      }
    },
    {
      name: 'clientId',
      message: 'Enter clientId',
      default: defaultPegaConfig.clientId,
      validate: value => {
        if (value.trim()) {
          return true;
        }
        return 'clientId cannot be empty';
      },
      when: answers => {
        return fnStandardWhen('clientId', answers);
      }
    },
    {
      name: 'clientSecret',
      type: 'password',
      message: 'Enter clientSecret',
      default: defaultPegaConfig.clientSecret,
      validate: (value, answers) => {
        if (value.trim()) {
          return true;
        }
        return 'clientSecret cannot be empty';
      },
      when: answers => {
        return (answers.grantType !== "authCode" && fnStandardWhen('clientSecret', answers));
      }
    }
  ];
};
