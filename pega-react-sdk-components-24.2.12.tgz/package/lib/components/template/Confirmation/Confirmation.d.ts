import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../types/PConnProps';
interface ConfirmationProps extends PConnProps {
    datasource: {
        source: any;
    };
    label: string;
    showLabel: boolean;
    showTasks: boolean;
}
export default function Confirmation(props: PropsWithChildren<ConfirmationProps>): import("react/jsx-runtime").JSX.Element | null;
export {};
//# sourceMappingURL=Confirmation.d.ts.map