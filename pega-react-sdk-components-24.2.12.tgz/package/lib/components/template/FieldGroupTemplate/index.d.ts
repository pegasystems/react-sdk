export { default } from './FieldGroupTemplate';
//# sourceMappingURL=index.d.ts.map