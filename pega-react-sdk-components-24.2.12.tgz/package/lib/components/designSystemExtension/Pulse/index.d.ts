export { default } from './Pulse';
//# sourceMappingURL=index.d.ts.map