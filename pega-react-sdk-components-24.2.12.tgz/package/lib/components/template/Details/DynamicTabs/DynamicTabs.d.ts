import { PConnProps } from '../../../../types/PConnProps';
interface DynamicTabsProps extends PConnProps {
    showLabel: boolean;
    label: string;
    referenceList?: any[];
}
declare function DynamicTabs(props: DynamicTabsProps): import("react/jsx-runtime").JSX.Element;
export default DynamicTabs;
//# sourceMappingURL=DynamicTabs.d.ts.map