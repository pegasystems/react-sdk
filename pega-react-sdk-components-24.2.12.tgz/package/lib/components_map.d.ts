declare const ComponentMap: any[];
export declare const LazyMap: any[];
export default ComponentMap;
//# sourceMappingURL=components_map.d.ts.map