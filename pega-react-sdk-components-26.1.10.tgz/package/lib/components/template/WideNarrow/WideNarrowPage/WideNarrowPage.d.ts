import { type PropsWithChildren } from 'react';
import type { GenAICoach } from '../../../widget/GenAICoach/GenAICoach.types';
import type { PConnProps } from '../../../../types/PConnProps';
interface WideNarrowPageProps extends PConnProps {
    title: string;
    templateCol?: string;
    icon?: string;
    coaches?: GenAICoach[];
    localeReference?: string;
}
export default function WideNarrowPage(props: PropsWithChildren<WideNarrowPageProps>): string | number | bigint | boolean | import("react").JSX.Element | Iterable<import("react").ReactNode> | Promise<string | number | bigint | boolean | import("react").ReactPortal | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | Iterable<import("react").ReactNode> | null | undefined> | null | undefined;
export {};
//# sourceMappingURL=WideNarrowPage.d.ts.map