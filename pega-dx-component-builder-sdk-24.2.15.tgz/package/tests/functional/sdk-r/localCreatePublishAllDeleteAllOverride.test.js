// import { exec } from 'child_process';
const path = require('path');
const fs = require('fs');
const util = require('node:util');
const exec = util.promisify(require('node:child_process').exec);

describe('override publish and deleteAll local override', () => {
  it('initial delete/cleanup', async () => {
    const script = `npm run deleteAll Local override Y --prefix ../../..`;

    const { stdout, stderr } = await exec(script);
    // console.log(stdout);
    expect(stdout).not.toBeNull();
    expect(stderr).not.toBeNull();
  }, 20000);

  it('npm run override auto complete override', async () => {
    const fileName = 'AutoComplete';
    const script = `npm run override Field ${fileName} --prefix ../../..`;

    const { stdout, stderr } = await exec(script);
    // console.log(stdout);
    expect(stdout).not.toBeNull();
    expect(stderr).not.toBeNull();

    // want message to contain component name
    expect(stdout).toContain(fileName);

    // don't want message with already exists
    expect(stdout).not.toContain('already exists');

    // check to see file exists

    const createOverrideFile = path.resolve('../../..', path.join(`src/components/override-sdk/field/${fileName}`, `${fileName}.tsx`));
    const doesOverrideExist = fs.existsSync(createOverrideFile);
    expect(doesOverrideExist).toBeTruthy();
  }, 20000);

  it('npm run override case view override', async () => {
    const fileName = 'CaseView';
    const script = `npm run override Template ${fileName} --prefix ../../..`;

    const { stdout, stderr } = await exec(script);
    // console.log(stdout);
    expect(stdout).not.toBeNull();
    expect(stderr).not.toBeNull();

    // want message to contain component name
    expect(stdout).toContain(fileName);

    // don't want message with already exists
    expect(stdout).not.toContain('already exists');

    // check to see file exists

    const createOverrideFile = path.resolve('../../..', path.join(`src/components/override-sdk/template/${fileName}`, `${fileName}.tsx`));
    const doesOverrideExist = fs.existsSync(createOverrideFile);
    expect(doesOverrideExist).toBeTruthy();
  }, 20000);

  it('npm run override navbar override', async () => {
    const fileName = 'ToDo';
    const script = `npm run override Widget ${fileName} --prefix ../../..`;

    const { stdout, stderr } = await exec(script);
    // console.log(stdout);
    expect(stdout).not.toBeNull();
    expect(stderr).not.toBeNull();

    // want message to contain component name
    expect(stdout).toContain(fileName);

    // don't want message with already exists
    expect(stdout).not.toContain('already exists');

    // check to see file exists

    const createOverrideFile = path.resolve('../../..', path.join(`src/components/override-sdk/widget/${fileName}`, `${fileName}.tsx`));
    const doesOverrideExist = fs.existsSync(createOverrideFile);
    expect(doesOverrideExist).toBeTruthy();
  }, 20000);

  it('npm run publishAll (no fetch) custom verify in map', async () => {
    const script = `npm run publishAll override LoanV2 01-01-01 N noFetch --prefix ../../..`;
    const { stdout, stderr } = await exec(script);
    // console.log(stdout);
    expect(stdout).not.toBeNull();
    expect(stderr).not.toBeNull();

    //    expect(stdout).toContain('Compiled successfully.');
    //    expect(stdout).not.toContain('Compiled with warnings.');
    //    expect(stdout).not.toContain('error');
    //    expect(stdout).not.toContain('Error');

    expect(stdout).toContain('AutoComplete');
    expect(stdout).toContain('CaseView');
    expect(stdout).toContain('ToDo');
    // done();

    // verify in map
    const pegaLocalComponentMapPath = path.join(path.resolve('../../..'), 'sdk-local-component-map.js');
    const mapData = fs.readFileSync(pegaLocalComponentMapPath, { encoding: 'utf8' });
    let isInMap = true;

    if (mapData.indexOf('AutoComplete') < 0) {
      isInMap = false;
    }

    if (mapData.indexOf('CaseView') < 0) {
      isInMap = false;
    }


    if (mapData.indexOf('ToDo') < 0) {
      isInMap = false;
    }


    expect(isInMap).toBeTruthy();
  }, 100000);

  it('npm run deleteAll Local override verify removed from map', async () => {
    const script = `npm run deleteAll Local override Y --prefix ../../..`;

    const { stdout, stderr } = await exec(script);
    // console.log(stdout);
    expect(stdout).not.toBeNull();
    expect(stderr).not.toBeNull();

    // pick one
    const newFileName = 'AutoComplete';

    // want message to contain component name
    expect(stdout).toContain(newFileName);


    // message deleted
    expect(stdout).toContain('is deleted');

    // check to see file exists

    // I think run through a map of them here

    // const fileDir = path.resolve('../../..', `src/components/${newFileName}`);
    // const createFile = path.resolve('../../..', path.join(`src/components/${newFileName}`, 'index.tsx'));
    // const doesExist = fs.existsSync(createFile);
    // expect(doesExist).not.toBeTruthy();

    // verify removed from map
    const pegaLocalAngularComponentMapPath = path.join(path.resolve('../../..'), 'sdk-local-component-map.js');
    const mapDataAng = fs.readFileSync(pegaLocalAngularComponentMapPath, { encoding: 'utf8' });
    let isInMap = false;

    if (mapDataAng.indexOf('AutoComplete') >= 0) {
      isInMap = true;
    }


    if (mapDataAng.indexOf('CaseView') >= 0) {
      isInMap = true;
    }


    if (mapDataAng.indexOf('ToDo') >= 0) {
      isInMap = true;
    }


    expect(isInMap).not.toBeTruthy();
  }, 20000);
});
