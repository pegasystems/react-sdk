export { default } from './QuickCreate';
//# sourceMappingURL=index.d.ts.map