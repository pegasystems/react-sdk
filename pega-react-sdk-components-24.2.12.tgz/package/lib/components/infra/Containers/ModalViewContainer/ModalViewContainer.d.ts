import { PConnProps } from '../../../../types/PConnProps';
interface ModalViewContainerProps extends PConnProps {
    loadingInfo?: string;
    routingInfo?: any;
    pageMessages?: string[];
}
export default function ModalViewContainer(props: ModalViewContainerProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=ModalViewContainer.d.ts.map