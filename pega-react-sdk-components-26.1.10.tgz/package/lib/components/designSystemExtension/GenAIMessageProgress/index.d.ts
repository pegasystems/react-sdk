export { default } from './GenAIMessageProgress';
//# sourceMappingURL=index.d.ts.map