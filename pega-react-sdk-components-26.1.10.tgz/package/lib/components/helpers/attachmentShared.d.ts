export declare const validateMaxSize: (fileObj: Record<string, number>, maxSizeInMB: string) => boolean;
//# sourceMappingURL=attachmentShared.d.ts.map