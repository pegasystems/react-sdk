export { default } from './CaseViewActionsMenu';
//# sourceMappingURL=index.d.ts.map