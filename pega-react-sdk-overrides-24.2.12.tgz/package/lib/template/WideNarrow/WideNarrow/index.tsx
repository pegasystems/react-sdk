export { default } from './WideNarrow';
