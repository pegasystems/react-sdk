export { default } from './DataReference';
//# sourceMappingURL=index.d.ts.map