import { PConnProps } from '../../../types/PConnProps';
interface CaseViewActionsMenuProps extends PConnProps {
    availableActions: any[];
    availableProcesses: any[];
    caseTypeID: string;
    caseTypeName: string;
}
export default function CaseViewActionsMenu(props: CaseViewActionsMenuProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=CaseViewActionsMenu.d.ts.map