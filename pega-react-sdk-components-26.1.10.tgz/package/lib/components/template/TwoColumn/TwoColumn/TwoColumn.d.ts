import type { PropsWithChildren } from 'react';
import type { PConnProps } from '../../../../types/PConnProps';
interface TwoColumnProps extends PConnProps {
    templateCol?: string;
}
export default function TwoColumn(props: PropsWithChildren<TwoColumnProps>): import("react").JSX.Element;
export {};
//# sourceMappingURL=TwoColumn.d.ts.map