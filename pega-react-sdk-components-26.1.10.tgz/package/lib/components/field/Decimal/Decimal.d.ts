import type { PConnFieldProps } from '../../../types/PConnProps';
interface DecimalProps extends PConnFieldProps {
    currencyISOCode?: string;
    decimalPrecision?: number;
    showGroupSeparators?: boolean;
    formatter?: string;
    showFieldMessage?: boolean;
    messageConfig?: {
        content?: string;
        visibility?: boolean;
    };
    variant?: string;
}
export default function Decimal(props: DecimalProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=Decimal.d.ts.map