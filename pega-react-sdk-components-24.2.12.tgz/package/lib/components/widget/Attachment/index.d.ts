export { default } from './Attachment';
//# sourceMappingURL=index.d.ts.map