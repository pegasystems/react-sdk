import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../../types/PConnProps';
interface NarrowWidePageProps extends PConnProps {
    title: string;
    templateCol: string;
    icon: string;
}
export default function NarrowWidePage(props: PropsWithChildren<NarrowWidePageProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=NarrowWidePage.d.ts.map