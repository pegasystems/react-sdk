export { default } from './EmbeddedDataMulti';
//# sourceMappingURL=index.d.ts.map