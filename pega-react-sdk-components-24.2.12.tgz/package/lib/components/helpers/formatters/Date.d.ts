declare const _default: {
    'DateTime-Long': (value: any, options: any) => string;
    'DateTime-Short': (value: any, options: any) => string;
    'DateTime-Since': (value: any) => string;
    'Time-Only': (value: any, options: any) => any;
    convertToTimezone: (value: any, options: any) => any;
    convertFromTimezone: (value: any, timezone: any) => any;
    Date: (value: any, options: any) => string;
};
export default _default;
//# sourceMappingURL=Date.d.ts.map