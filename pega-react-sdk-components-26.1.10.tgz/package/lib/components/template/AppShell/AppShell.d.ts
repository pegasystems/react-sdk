import { type PropsWithChildren } from 'react';
import type { PConnProps } from '../../../types/PConnProps';
import './AppShell.css';
interface PortalAgentConfig {
    pyComponentName: string;
    classID: string;
    pxInsName: string;
    pyDisplayLabel?: string;
    pyLabel?: string;
}
interface AppShellProps extends PConnProps {
    showAppName: boolean;
    pages: {
        pxPageViewIcon: string;
        pyClassName: string;
        pyLabel: string;
        pyRuleName: string;
        pyURLContent: string;
    }[];
    caseTypes?: object[];
    portalTemplate: string;
    portalName: string;
    portalLogo: string;
    navDisplayOptions: {
        alignment: string;
        position: string;
        enableAIAgent?: boolean;
        selectedAgents?: PortalAgentConfig[];
        aiAssistantWidth?: string;
    };
    httpMessages: string[];
    pageMessages: string[];
}
export default function AppShell(props: PropsWithChildren<AppShellProps>): import("react").JSX.Element;
export {};
//# sourceMappingURL=AppShell.d.ts.map