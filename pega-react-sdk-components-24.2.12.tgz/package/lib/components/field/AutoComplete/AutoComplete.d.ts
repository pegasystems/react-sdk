import { PConnFieldProps } from '../../../types/PConnProps';
interface AutoCompleteProps extends PConnFieldProps {
    displayMode?: string;
    deferDatasource?: boolean;
    datasourceMetadata?: any;
    status?: string;
    onRecordChange?: any;
    additionalProps?: object;
    listType: string;
    parameters?: any;
    datasource: any;
    columns: any[];
}
export default function AutoComplete(props: AutoCompleteProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=AutoComplete.d.ts.map