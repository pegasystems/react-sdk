import type { PConnProps } from '../../../../types/PConnProps';
/**
 * WARNING: This file is part of the infrastructure component responsible for working with Redux and managing the creation and update of Redux containers and PConnect.
 * You may override Material components within this component if needed, but do not modify any container-related logic. Changing this logic can lead to unexpected behavior.
 */
interface ModalViewContainerProps extends PConnProps {
    loadingInfo?: string;
    routingInfo?: any;
    pageMessages?: string[];
    httpMessages?: any[];
}
export default function ModalViewContainer(props: ModalViewContainerProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=ModalViewContainer.d.ts.map