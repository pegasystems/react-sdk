/// <reference types="react" />
declare const ReactReduxContext: import("react").Context<{}>;
export declare const useConstellationContext: () => {};
export default ReactReduxContext;
//# sourceMappingURL=StoreContext.d.ts.map