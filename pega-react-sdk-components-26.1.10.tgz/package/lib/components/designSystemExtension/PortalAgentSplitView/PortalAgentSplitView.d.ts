import type { PortalAgentSplitViewProps } from '../GenAICoachContent/GenAICoach.types';
export default function PortalAgentSplitView(props: PortalAgentSplitViewProps): import("react").JSX.Element;
//# sourceMappingURL=PortalAgentSplitView.d.ts.map