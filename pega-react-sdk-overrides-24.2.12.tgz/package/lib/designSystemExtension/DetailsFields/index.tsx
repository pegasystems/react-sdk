export { default } from './DetailsFields';
