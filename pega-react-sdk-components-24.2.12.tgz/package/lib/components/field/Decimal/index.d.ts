export { default } from './Decimal';
//# sourceMappingURL=index.d.ts.map