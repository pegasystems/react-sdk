declare const LeftAlignVerticalTabs: any;
export default LeftAlignVerticalTabs;
//# sourceMappingURL=LeftAlignVerticalTabs.d.ts.map