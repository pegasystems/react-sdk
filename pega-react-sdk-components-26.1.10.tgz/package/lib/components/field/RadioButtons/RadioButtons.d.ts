import type { PConnFieldProps } from '../../../types/PConnProps';
interface RadioButtonsProps extends PConnFieldProps {
    inline: boolean;
    fieldMetadata?: any;
    variant?: string;
    hideFieldLabels?: boolean;
    additionalProps?: any;
    imagePosition?: string;
    imageSize?: string;
    showImageDescription?: boolean;
    datasource?: any;
    showFieldMessage?: boolean;
    messageConfig?: {
        content?: string;
        visibility?: boolean;
    };
}
export default function RadioButtons(props: RadioButtonsProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=RadioButtons.d.ts.map