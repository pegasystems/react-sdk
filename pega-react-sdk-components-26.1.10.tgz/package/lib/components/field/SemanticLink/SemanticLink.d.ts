import type { PConnFieldProps } from '../../../types/PConnProps';
interface SemanticLinkProps extends PConnFieldProps {
    text: string;
    resourcePayload: any;
    resourceParams: any;
    previewKey: string | null;
    onClick: (event: any) => void;
    testId: string;
    referenceType: string | null;
    dataRelationshipContext: string | null;
    contextPage: any;
}
export default function SemanticLink(props: SemanticLinkProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=SemanticLink.d.ts.map