import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../types/PConnProps';
interface InlineDashboardPageProps extends PConnProps {
    title: string;
    icon?: string;
    filterPosition?: string;
}
export default function InlineDashboardPage(props: PropsWithChildren<InlineDashboardPageProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=InlineDashboardPage.d.ts.map