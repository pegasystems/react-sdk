import type { PropsWithChildren } from 'react';
import type { PConnProps } from '../../../../types/PConnProps';
import './WideNarrowForm.css';
interface WideNarrowFormProps extends PConnProps {
}
export default function WideNarrowForm(props: PropsWithChildren<WideNarrowFormProps>): import("react").JSX.Element;
export {};
//# sourceMappingURL=WideNarrowForm.d.ts.map