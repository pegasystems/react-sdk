/**
 * Function that accepts array of messages as input and group them by their type and returns the resulting object
 * @param {Array} inputMessages
 * Eg: [
 * {message: 'First Name is required', type: 'error'},
 * {message: 'Last Name is required', type: 'error'},
 * {message: 'Address field should be clear and precise', type: 'info'}
 * ]
 *
 * @returns {object}
 *
 * Eg: {
 *  error: ['First Name is required', 'Last Name is required'],
 *  info: ['Address field should be clear and precise']
 * }
 */
declare function getMessagesGrouped(inputMessages: any): {};
declare function getBanners(config: any): any;
export { getMessagesGrouped, getBanners };
//# sourceMappingURL=case-utils.d.ts.map