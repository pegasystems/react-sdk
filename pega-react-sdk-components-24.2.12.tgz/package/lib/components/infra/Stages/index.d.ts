export { default } from './Stages';
//# sourceMappingURL=index.d.ts.map