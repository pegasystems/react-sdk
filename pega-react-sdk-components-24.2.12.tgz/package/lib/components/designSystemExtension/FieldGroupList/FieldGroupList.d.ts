interface FieldGroupListProps {
    items: any[] | any;
    onDelete: any;
    onAdd: any;
}
export default function FieldGroupList(props: FieldGroupListProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=FieldGroupList.d.ts.map