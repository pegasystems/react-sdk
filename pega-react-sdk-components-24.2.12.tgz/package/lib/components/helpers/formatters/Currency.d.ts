declare const _default: {
    Currency: (value: any, options: any) => string;
    'Currency-Code': (value: any, options: any) => string;
    Decimal: (value: any, options: any) => string;
    'Decimal-Auto': (value: any, options: any) => string;
    Integer: (value: any, options: any) => string;
    Percentage: (value: any, options: any) => string;
};
export default _default;
//# sourceMappingURL=Currency.d.ts.map