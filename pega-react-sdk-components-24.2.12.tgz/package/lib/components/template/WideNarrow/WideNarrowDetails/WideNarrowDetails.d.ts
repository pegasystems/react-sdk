import { PConnProps } from '../../../../types/PConnProps';
interface WideNarrowDetailsProps extends PConnProps {
    showLabel?: boolean;
    label?: string;
    showHighlightedData?: boolean;
}
export default function WideNarrowDetails(props: WideNarrowDetailsProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=WideNarrowDetails.d.ts.map