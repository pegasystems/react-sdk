import type { PropsWithChildren } from 'react';
interface PulseProps {
}
export default function Pulse(props: PropsWithChildren<PulseProps>): import("react").JSX.Element;
export {};
//# sourceMappingURL=Pulse.d.ts.map