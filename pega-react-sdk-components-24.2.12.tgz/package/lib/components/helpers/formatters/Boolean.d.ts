declare const _default: {
    TrueFalse: (value: any, options: any) => any;
};
export default _default;
//# sourceMappingURL=Boolean.d.ts.map