import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../types/PConnProps';
interface SubTabsProps extends PConnProps {
}
export default function SubTabs(props: PropsWithChildren<SubTabsProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=SubTabs.d.ts.map