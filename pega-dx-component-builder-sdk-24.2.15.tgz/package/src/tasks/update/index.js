import publishComponent from '../publish/index.js';

export default options => {
  return publishComponent(options);
};
