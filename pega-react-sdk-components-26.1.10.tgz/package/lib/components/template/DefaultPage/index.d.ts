export { default } from './DefaultPage';
//# sourceMappingURL=index.d.ts.map