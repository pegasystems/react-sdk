export { default } from './DeferLoad';
//# sourceMappingURL=index.d.ts.map