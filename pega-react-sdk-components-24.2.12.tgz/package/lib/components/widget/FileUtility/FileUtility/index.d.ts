export { default } from './FileUtility';
//# sourceMappingURL=index.d.ts.map