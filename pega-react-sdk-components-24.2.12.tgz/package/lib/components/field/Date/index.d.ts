export { default } from './Date';
//# sourceMappingURL=index.d.ts.map