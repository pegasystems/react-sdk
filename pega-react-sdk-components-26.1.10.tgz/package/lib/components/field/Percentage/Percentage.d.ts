import type { PConnFieldProps } from '../../../types/PConnProps';
interface PercentageProps extends PConnFieldProps {
    currencyISOCode?: string;
    showGroupSeparators?: string;
    decimalPrecision?: number;
    showFieldMessage?: boolean;
    messageConfig?: {
        content?: string;
        visibility?: boolean;
    };
    variant?: string;
}
export default function Percentage(props: PercentageProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=Percentage.d.ts.map