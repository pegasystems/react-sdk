import type { PConnProps } from '../../../../types/PConnProps';
interface SimpleTableSelectReadonlyProps extends PConnProps {
    label?: string;
    referenceList: object[] | string;
    readonlyContextList?: object[];
    primaryField?: string;
    referenceType?: string;
    selectionKey?: string;
    selectionList?: string;
    hideLabel?: boolean;
    variant?: string;
    displayAs?: string;
    displayMode?: string;
}
export default function SimpleTableSelectReadonly(props: SimpleTableSelectReadonlyProps): any;
export {};
//# sourceMappingURL=SimpleTableSelectReadonly.d.ts.map