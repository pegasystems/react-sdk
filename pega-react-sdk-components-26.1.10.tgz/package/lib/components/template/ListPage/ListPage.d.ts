import type { GenAICoach } from '../../widget/GenAICoach/GenAICoach.types';
import type { PConnProps } from '../../../types/PConnProps';
interface ListPageProps extends PConnProps {
    parameters: object;
    coaches?: GenAICoach[];
    localeReference?: string;
}
export default function ListPage(props: ListPageProps): string | number | bigint | boolean | import("react").JSX.Element | Iterable<import("react").ReactNode> | Promise<string | number | bigint | boolean | import("react").ReactPortal | import("react").ReactElement<unknown, string | import("react").JSXElementConstructor<any>> | Iterable<import("react").ReactNode> | null | undefined> | null | undefined;
export {};
//# sourceMappingURL=ListPage.d.ts.map