import './FileUtility.css';
import type { PConnProps } from '../../../../types/PConnProps';
interface FileUtilityProps extends PConnProps {
    caseId?: string;
}
export default function FileUtility(props: FileUtilityProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=FileUtility.d.ts.map