export { default } from './Multiselect';
//# sourceMappingURL=index.d.ts.map