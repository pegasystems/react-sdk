import type { PConnFieldProps } from '../../../types/PConnProps';
interface TimeProps extends PConnFieldProps {
    showFieldMessage?: boolean;
    messageConfig?: {
        content?: string;
        visibility?: boolean;
    };
    variant?: string;
}
export default function Time(props: TimeProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=Time.d.ts.map