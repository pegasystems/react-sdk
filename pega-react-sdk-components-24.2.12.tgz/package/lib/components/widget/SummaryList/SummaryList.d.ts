import { PConnProps } from '../../../types/PConnProps';
interface SummaryListProps extends PConnProps {
    arItems$: any[];
    menuIconOverride$?: string;
    menuIconOverrideAction$?: any;
}
export default function SummaryList(props: SummaryListProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=SummaryList.d.ts.map