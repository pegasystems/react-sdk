import fs from 'fs';
import path from 'path';
import chalk from 'chalk';

import { validateCompile } from '../create/index.js';
import {
  showVersion,
  getComponentDirectoryPath,
  getComponentsAndSubDirectory, 
  getFramework
} from '../../util.js';
import {CATEGORY_CONSTELLATION, CATEGORY_CUSTOM } from '../..//constants.js';
import { or } from 'ajv/dist/compile/codegen/index.js';

export const DXCB_CONFIG_INTERNAL_JSON_FILENAME = 'src/dxcb.config.json';
const pegaConfigInternalJsonPath = path.join(path.resolve(), DXCB_CONFIG_INTERNAL_JSON_FILENAME);


const getMissingList = async () => {
  const customList = await getComponentsAndSubDirectory(CATEGORY_CUSTOM);
  const constellationList = await getComponentsAndSubDirectory(CATEGORY_CONSTELLATION);
  let missingList = [];

  for (var el in customList) {
    const found = constellationList.find(element => element === customList[el]);
    if (found === undefined) {
      missingList.push(customList[el]);
    }
  }

  return missingList;
}

const generateMissingCompanion = async (componentKey) => {
  const srcDirectory = await getComponentDirectoryPath(componentKey, CATEGORY_CUSTOM);
  const configJson = `${srcDirectory}/config.json`;

  if (fs.existsSync(configJson)) {
    let data = fs.readFileSync(configJson, { encoding: 'utf8' });
    data = JSON.parse(data);

    const { name, label, description, organization, version, library, componentKey, type, subtype} = data;
    let { allowedApplications } = data;

    const componentName = componentKey.split("_")[2];

    // look up the framework
    const framework = await getFramework();

    allowedApplications = allowedApplications.toString();


    validateCompile({library, organization, componentName, label, version, framework, type, subtype, description, allowedApplications}, null, true);
  }

}

export default async options => {

  showVersion();

  const missingList = await getMissingList();

  if (missingList.length === 0) {
    console.log(chalk.bold.green("No missing companion components!"));
    return;
  }

  for (var el in missingList) {
    await generateMissingCompanion(missingList[el]);
  }


}
