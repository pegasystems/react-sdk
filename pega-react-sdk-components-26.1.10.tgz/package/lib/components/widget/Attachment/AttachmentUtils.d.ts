import type { FileObject, PageInstructionOptions, ReduxAttachments } from './Attachment.types';
export declare const isContentBinary: (headers: Record<string, string>) => boolean;
export declare const isContentBase64: (headers: Record<string, string>) => boolean;
export declare const validateFileExtension: (fileObj: Record<string, string>, allowedExtensions: string) => boolean;
export declare const fileDownload: (data: string | Blob, fileName: string, ext: string | null, headers: Record<string, string>) => void;
export declare const getIconFromFileType: (fileType: string) => string;
export declare const fileDownloadVar: (content: {
    data: string;
    headers: Record<string, string>;
}, type: string, name: string, extension: string) => void;
export declare const getMappedValue: (value: string) => string;
export declare const updateReduxState: (transformedAttachments: ReduxAttachments[], pConn: typeof PConnect, valueRef: string, options: PageInstructionOptions) => void;
export declare const insertAttachments: (files: FileObject[], pConn: typeof PConnect, attachmentsInModal: ReduxAttachments[], options: PageInstructionOptions) => void;
export declare const deleteAttachments: (files: FileObject[], pConn: typeof PConnect, attachmentsInModal: Pick<ReduxAttachments, "instruction" | "fileIndex">[], options: PageInstructionOptions) => void;
export declare const clearFieldErrorMessages: (pConn: typeof PConnect) => void;
export declare const useFileDownload: (context: string) => ({ ID, name, extension, type, category, responseType }: {
    ID: string;
    name: string;
    extension: string;
    type: string;
    category: string;
    responseType: string;
}) => void;
export declare const useDeepMemo: (memoFn: any, key: any) => any;
//# sourceMappingURL=AttachmentUtils.d.ts.map