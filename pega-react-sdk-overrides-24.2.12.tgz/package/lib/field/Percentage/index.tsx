export { default } from './Percentage';
