export { default } from './CaseSummary';
//# sourceMappingURL=index.d.ts.map