declare const SearchForm: (props: any) => import("react").JSX.Element;
export default SearchForm;
//# sourceMappingURL=SearchForm.d.ts.map