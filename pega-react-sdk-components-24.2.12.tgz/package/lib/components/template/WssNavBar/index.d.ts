export { default } from './WssNavBar';
//# sourceMappingURL=index.d.ts.map