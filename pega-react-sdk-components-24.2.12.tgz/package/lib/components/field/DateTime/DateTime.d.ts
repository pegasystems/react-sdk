import { PConnFieldProps } from '../../../types/PConnProps';
interface DateTimeProps extends PConnFieldProps {
}
export default function DateTime(props: DateTimeProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=DateTime.d.ts.map