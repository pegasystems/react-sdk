export { default } from './SelfServiceCaseView';
//# sourceMappingURL=index.d.ts.map