import { type Ref, type RefObject } from 'react';
/**
 * @example const ref = useConsolidatedRefs(refs);
 * @param refs The ref or refs to consolidate.
 * @returns ref:: The consolidated ref.
 */
declare const useConsolidatedRef: <T>(...refs: (Ref<T> | undefined)[]) => RefObject<T | null>;
export default useConsolidatedRef;
//# sourceMappingURL=useConsolidatedRef.d.ts.map