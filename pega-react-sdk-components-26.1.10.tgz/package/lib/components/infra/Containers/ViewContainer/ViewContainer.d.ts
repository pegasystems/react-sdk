import React from 'react';
import type { PConnProps } from '../../../../types/PConnProps';
interface ViewContainerProps extends PConnProps {
    name?: string;
    loadingInfo?: any;
    routingInfo?: any;
    mode?: string;
    limit?: number;
}
/**
 * WARNING: This file is part of the infrastructure component responsible for working with Redux and managing the creation and update of Redux containers and PConnect.
 * You may override Material components within this component if needed, but do not modify any container-related logic. Changing this logic can lead to unexpected behavior.
 */
export default function ViewContainer(props: ViewContainerProps): React.JSX.Element;
export {};
//# sourceMappingURL=ViewContainer.d.ts.map