import type { GenAICoachContentProps } from './GenAICoach.types';
/**
 * The agent panel: MUI port of the Cosmos `GenAICoach` component (`GenAICoachContent` and `HeaderActions`).
 * It is registered as `GenAICoachContent` because `GenAICoach` is the widget's key in the component map.
 */
export default function GenAICoachContent(props: GenAICoachContentProps): import("react").JSX.Element;
//# sourceMappingURL=GenAICoachContent.d.ts.map