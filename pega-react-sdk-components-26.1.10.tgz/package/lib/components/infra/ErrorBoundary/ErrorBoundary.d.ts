import type { PConnProps } from '../../../types/PConnProps';
interface ErrorBoundaryProps extends PConnProps {
    isInternalError?: boolean;
}
export default function ErrorBoundary(props: ErrorBoundaryProps): import("react").JSX.Element | null;
export {};
//# sourceMappingURL=ErrorBoundary.d.ts.map