import type { PConnFieldProps } from '../../../types/PConnProps';
interface DateTimeProps extends PConnFieldProps {
    showFieldMessage?: boolean;
    messageConfig?: {
        content?: string;
        visibility?: boolean;
    };
    variant?: string;
}
export default function DateTime(props: DateTimeProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=DateTime.d.ts.map