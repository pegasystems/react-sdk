# The **Template** directory

The **SDK-Angular/Template** directory contains the template code for the template components you want to use with the **Angular SDK**.

