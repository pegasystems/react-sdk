export { default } from './CancelAlert';
//# sourceMappingURL=index.d.ts.map