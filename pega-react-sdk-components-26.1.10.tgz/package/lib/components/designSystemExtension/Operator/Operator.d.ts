import React from 'react';
import type { PConnProps } from '../../../types/PConnProps';
interface OperatorProps extends PConnProps {
    label: string;
    createDateTime: string;
    createLabel: string;
    createOperator: {
        userName: string;
        userId: string;
    };
    updateDateTime: string;
    updateLabel: string;
    updateOperator: {
        userName: string;
        userId: string;
    };
    displayLabel?: any;
    displayMode?: string;
}
export default function Operator(props: OperatorProps): React.JSX.Element;
export {};
//# sourceMappingURL=Operator.d.ts.map