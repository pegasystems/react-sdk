import { PConnProps } from '../../../types/PConnProps';
interface ScalarListProps extends PConnProps {
    displayInModal: boolean;
    hideLabel: boolean;
    value: any[];
    componentType: string;
    label: string;
    displayMode: string;
}
export default function ScalarList(props: ScalarListProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=ScalarList.d.ts.map