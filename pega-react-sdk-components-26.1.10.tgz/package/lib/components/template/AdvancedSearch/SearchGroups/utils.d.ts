export declare function getCacheInfo(cache: {
    selectedCategory: string;
    activeGroupId: string;
    searchFields: unknown;
}, groups: {
    config: {
        id: string;
    };
}[]): {
    useCache: boolean;
    initialActiveGroupId: string;
};
export declare function isValidInput(input: {
    [s: string]: unknown;
}): boolean;
//# sourceMappingURL=utils.d.ts.map