import { type PropsWithChildren } from 'react';
import { type HierarchicalFormProps } from './hooks';
export default function HierarchicalForm(props: PropsWithChildren<HierarchicalFormProps>): import("react").JSX.Element | null;
//# sourceMappingURL=HierarchicalForm.d.ts.map