export default function Multiselect(props: any): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=Multiselect.d.ts.map