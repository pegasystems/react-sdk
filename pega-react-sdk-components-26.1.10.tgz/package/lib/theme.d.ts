import type { Theme } from '@mui/material/styles';
/**
 * Since makeStyles is now exported from @mui/styles package which does not know about Theme in the core package.
 * you need to augment the DefaultTheme (empty object) in @mui/styles with Theme from the core.
 */
declare module '@mui/styles/defaultTheme' {
    interface DefaultTheme extends Theme {
        backgroundColor: string;
        card: {
            backgroundColor: string;
            borderLeft: string;
            borderLeftColor: string;
        };
        modal: {
            backgroundColor: string;
            topColor: string;
        };
        headerNav: {
            backgroundColor: string;
            navLinkColor: string;
            navLinkHoverColor: string;
            menuToggleColor: string;
        };
        embedded: {
            resolutionTextColor: string;
        };
        actionButtons: {
            primary: {
                backgroundColor: string;
                color: string;
            };
            secondary: {
                backgroundColor: string;
                color: string;
            };
        };
    }
}
export declare const theme: Theme;
//# sourceMappingURL=theme.d.ts.map