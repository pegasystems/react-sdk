export { default } from './AgentRichTextViewer';
//# sourceMappingURL=index.d.ts.map