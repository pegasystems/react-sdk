import type { GenAIMessageProps } from '../GenAICoachContent/GenAICoach.types';
export default function GenAIMessage(props: GenAIMessageProps): import("react").JSX.Element | null;
//# sourceMappingURL=GenAIMessage.d.ts.map