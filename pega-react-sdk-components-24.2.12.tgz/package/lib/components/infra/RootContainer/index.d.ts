export { default } from './RootContainer';
//# sourceMappingURL=index.d.ts.map