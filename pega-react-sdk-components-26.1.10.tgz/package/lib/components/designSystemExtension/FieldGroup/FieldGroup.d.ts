import { type PropsWithChildren } from 'react';
interface FieldGroupProps {
    name?: string;
    instructions?: string;
    defaultCollapsed?: any;
    collapsed?: any;
    onToggleCollapsed?: () => void;
    isCollapsibleMode?: boolean;
}
export default function FieldGroup(props: PropsWithChildren<FieldGroupProps>): import("react").JSX.Element;
export {};
//# sourceMappingURL=FieldGroup.d.ts.map