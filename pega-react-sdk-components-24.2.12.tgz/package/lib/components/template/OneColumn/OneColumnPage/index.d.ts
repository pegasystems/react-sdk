export { default } from './OneColumnPage';
//# sourceMappingURL=index.d.ts.map