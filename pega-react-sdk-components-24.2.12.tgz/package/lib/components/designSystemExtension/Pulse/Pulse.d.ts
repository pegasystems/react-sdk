import { PropsWithChildren } from 'react';
interface PulseProps {
}
export default function Pulse(props: PropsWithChildren<PulseProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Pulse.d.ts.map