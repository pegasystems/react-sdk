import type { PropsWithChildren } from 'react';
import type { PConnProps } from '../../../types/PConnProps';
interface CaseSummaryProps extends PConnProps {
    arPrimaryFields: any[];
    arSecondaryFields: any[];
}
export default function CaseSummary(props: PropsWithChildren<CaseSummaryProps>): import("react").JSX.Element;
export {};
//# sourceMappingURL=CaseSummary.d.ts.map