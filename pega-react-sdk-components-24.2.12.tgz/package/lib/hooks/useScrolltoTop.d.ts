/**
 * @example useScrolltoTop(id, children);;
 * Page scrolls to top on view change.
 */
declare const useScrolltoTop: (id: any, children: any) => void;
export default useScrolltoTop;
//# sourceMappingURL=useScrolltoTop.d.ts.map