export { default } from './Percentage';
//# sourceMappingURL=index.d.ts.map