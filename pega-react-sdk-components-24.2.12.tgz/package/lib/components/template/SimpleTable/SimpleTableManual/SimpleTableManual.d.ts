import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../../types/PConnProps';
interface SimpleTableManualProps extends PConnProps {
    hideAddRow?: boolean;
    hideDeleteRow?: boolean;
    referenceList?: any[];
    renderMode?: string;
    presets?: any[];
    label?: string;
    showLabel?: boolean;
    dataPageName?: string;
    contextClass?: string;
    propertyLabel?: string;
    fieldMetadata?: any;
    editMode?: string;
    addAndEditRowsWithin?: any;
    viewForAddAndEditModal?: any;
    editModeConfig?: any;
    displayMode?: string;
    useSeparateViewForEdit: any;
    viewForEditModal: any;
    validatemessage?: string;
    required?: boolean;
}
export default function SimpleTableManual(props: PropsWithChildren<SimpleTableManualProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=SimpleTableManual.d.ts.map