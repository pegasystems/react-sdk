import { type PropsWithChildren } from 'react';
import type { PConnProps } from '../../../types/PConnProps';
import './DefaultForm.css';
interface DefaultFormProps extends PConnProps {
    NumCols: string;
    instructions: string;
}
export default function DefaultForm(props: PropsWithChildren<DefaultFormProps>): import("react").JSX.Element;
export {};
//# sourceMappingURL=DefaultForm.d.ts.map