import { type PropsWithChildren, type SyntheticEvent } from 'react';
import type { PConnProps } from '../../../types/PConnProps';
export interface HierarchicalFormProps extends PConnProps {
    tabsVisibility?: Record<string, boolean>;
    template?: string;
    instructions?: string;
    lastUpdateCaseTime?: string | number;
}
export declare function useHierarchicalForm(props: PropsWithChildren<HierarchicalFormProps>): {
    currentTabId: any;
    handleTabClick: (event: SyntheticEvent, id: string) => void;
    processedTabs: any[];
    instructions: string | undefined;
};
//# sourceMappingURL=hooks.d.ts.map