import fs from 'fs';
import path, {join} from 'path';
import inquirer from 'inquirer';
import chalk from 'chalk';


import {
  showVersion,
  getFramework,
  getJestFunctionalTestList } from '../../util.js';

import { JEST_TESTS_FUNCTIONAL_PATH } from '../../constants.js';


export const quarnUnquarnTests = async(answers) => {
  switch (answers.QuarUnQuar) {
    case "Quarantine" :
      await quarantineTests(answers);
      break;
    case "Unquarantine" :
      await unquarantineTests(answers);
      break;
  }
}



export const quarantineTests = async(answers) => {
  const testList = await getJestFunctionalTestList("ALL");
  const frameWork = await getFramework();
  const SDK_PATH = frameWork === "SDK-Angular" ? "sdk-a" : "sdk-r";
  const SDK_PATH_CAP = SDK_PATH.toUpperCase();
  const functionalPath = join(path.resolve(), JEST_TESTS_FUNCTIONAL_PATH, SDK_PATH);

  // rename .test to .notest
  for (const testName of testList) {
    const quarantineName = testName.replace(".test", ".notest");
    fs.renameSync(join(functionalPath, testName), join(functionalPath, quarantineName));
  }

  console.log(chalk.green(`All ${SDK_PATH_CAP} tests are quarantined.`));

}

export const unquarantineTests = async(answers) => {
  const testList = await getJestFunctionalTestList("ALL");
  const frameWork = await getFramework();
  const SDK_PATH = frameWork === "SDK-Angular" ? "sdk-a" : "sdk-r";
  const SDK_PATH_CAP = SDK_PATH.toUpperCase();
  const functionalPath = join(path.resolve(), JEST_TESTS_FUNCTIONAL_PATH, SDK_PATH);

  // rename .test to .notest
  for (const testName of testList) {
    const restoreName = testName.replace(".notest", ".test");
    fs.renameSync(join(functionalPath, testName), join(functionalPath, restoreName));
  }

  console.log(chalk.green(`All ${SDK_PATH_CAP} tests are unquarantined.`));

}


export default async options => {

  await showVersion();

  const quaranAnswers = await inquirer.prompt([

    {
      name: 'QuarUnQuar',
      type: 'rawlist',
      message: `Quarantine or UnQuarantine tests`,
      choices: ["Quarantine", "Unquarantine"],
      default: 'Quarantine'

    }
  ]);

  // await showCurrentStatus();
  await quarnUnquarnTests(quaranAnswers);


}
