import fs from 'fs';
import path from 'path';
import { join } from 'path';
import * as prettier from 'prettier';

import {
  convertIntoPascalCase,
  convertIntoKebabCase,
  reverseKebabCase,
  removeComponentPrefix,
  getLocalComponentKeyFromConfig,
  getFramework
} from '../../util.js';

import {
  REACT_COMPONENTS_DIRECTORY_PATH,
  ANGULAR_COMPONENTS_DIRECTORY_PATH,
  ANGULAR_COMPONENTS_APP_DIRECTORY_PATH,
  SDK_CONFIG_JSON_FILENAME,
  CATEGORY_CUSTOM,
  CATEGORY_CONSTELLATION,
  COMPONENT_DIRECTORY_PREFIX_CUSTOM,
  COMPONENT_DIRECTORY_SUFFIX_SDK,
  COMPONENT_REACT_LIB_PATH,
  COMPONENT_ANGULAR_LIB_PATH,
  PRETTIER_CONFIG_FILENAME
} from '../../constants.js';
import { or } from 'ajv/dist/compile/codegen/index.js';

export const SDK_LOCAL_REACT_COMPONENT_MAP_FILENAME = "sdk-local-component-map.js";
export const SDK_LOCAL_ANGULAR_COMPONENT_MAP_FILENAME = "sdk-local-component-map.ts";
export const IMPORT_END_TAG = "/* import end";
export const MAP_END_TAG = "/* map end";

export const DXCB_CONFIG_INTERNAL_JSON_FILENAME = 'src/dxcb.config.json';
const pegaConfigInternalJsonPath = path.join(path.resolve(), DXCB_CONFIG_INTERNAL_JSON_FILENAME);
const pegaLocalReactComponentMapPath = path.join(path.resolve(), SDK_LOCAL_REACT_COMPONENT_MAP_FILENAME);
const pegaLocalAngularComponentMapPath = path.join(path.resolve(),  SDK_LOCAL_ANGULAR_COMPONENT_MAP_FILENAME);
const prettierConfigJsonPath = path.join(path.resolve(), PRETTIER_CONFIG_FILENAME);

export const getPrettierFormattedString = async (content) => {
  const options = await prettier.resolveConfig(prettierConfigJsonPath);

  // format the contents
  if (options) {
    options.parser = 'babel';
    return  prettier.format(content, options);
  }
  else {
    return content;
  }
}

//
// some components reference have a slightly different case/spelling than the component name, class, etc.
//
export const getSpecialCase = (componentKey, framework) => {

  switch (framework) {
    case 'SDK-React':
      switch(componentKey) {
        case "ToDo":
          return "Todo";
      }
      break;
    case 'SDK-Angular':
      break;
    case 'SDK-WebComponents' :
      break;
  }

  return componentKey;
}

export const updateComponentMap = async (componentKey, category = CATEGORY_CUSTOM) => {

  const framework = await getFramework();

  // POSIX key
  componentKey = componentKey.split(path.sep).join("/");

  switch (framework) {
    case 'SDK-React' :

      const categoryDirectory = (category === CATEGORY_CONSTELLATION) ? join("/", COMPONENT_DIRECTORY_PREFIX_CUSTOM + category.toLowerCase()) : join("/", category.toLowerCase() + COMPONENT_DIRECTORY_SUFFIX_SDK);

      const componentNameNoPrefix = removeComponentPrefix(componentKey);
      const componentName = convertIntoPascalCase(componentNameNoPrefix);

      let mapData = fs.readFileSync(pegaLocalReactComponentMapPath, { encoding: 'utf8' });

      let importComponent = join(REACT_COMPONENTS_DIRECTORY_PATH, categoryDirectory, componentKey);

      // POSIX path
      importComponent = "./".concat(importComponent).split(path.sep).join("/");

      let importFull = "import ".concat(componentName).concat(" from '").concat(importComponent).concat("/';");
      let mapFull = "\"".concat(getSpecialCase(componentNameNoPrefix, framework)).concat("\" : " ).concat(componentName).concat(",");

      if (mapData.indexOf(importComponent.concat("/")) < 0) {
        // not present so we can add

        // add import
        let endImportIndex = mapData.indexOf(IMPORT_END_TAG);
        let mapDataStart = mapData.substring(0, endImportIndex);
        let mapDataEnd = mapData.substring(endImportIndex);

        mapData = mapDataStart.concat(importFull).concat("\n").concat(mapDataEnd);

        // add map
        let endMapIndex = mapData.indexOf(MAP_END_TAG);
        mapDataStart = mapData.substring(0, endMapIndex);
        mapDataEnd = mapData.substring(endMapIndex);

        // when prettier involved need to append a comma on last line (because it removes it
        // so check if last line has comma, if not add, before appending
        const numChars = mapDataStart.length - 1;
        let appendArr = [];
        for (let i = numChars; i > 0; i--) {
           const myChar = mapDataStart[i];
           if (myChar != ' ' && myChar != '\n') {
            if (myChar == '{') {
              // group is empty
              break;
            }
            if (myChar != ',') {
              const strStart = mapDataStart.substring(0, i + 1);
              const strEnd = mapDataStart.substring(i+ 1);
              mapDataStart = strStart.concat(",").concat(strEnd);
              break;
            }
            else {
              // has comma, do nothing
              break;
            }
           }
        }

        mapData = mapDataStart.concat("  ").concat(mapFull).concat("\n").concat(mapDataEnd);

        // prettier
        mapData = await getPrettierFormattedString(mapData);

        fs.writeFileSync(pegaLocalReactComponentMapPath, mapData, { encoding: 'utf8' });

      }
      break;
    case 'SDK-Angular' :
      const categoryDirectoryAng = (category === CATEGORY_CONSTELLATION) ? join("/", COMPONENT_DIRECTORY_PREFIX_CUSTOM + category.toLowerCase()) : join("/", category.toLowerCase() + COMPONENT_DIRECTORY_SUFFIX_SDK);

      const componentNameNoPrefixAng = removeComponentPrefix(componentKey);
      const originalComponenttNameConfigAng = await getLocalComponentKeyFromConfig(componentKey, category);
      const originalComponentName = originalComponenttNameConfigAng != "" ? originalComponenttNameConfigAng : reverseKebabCase(componentNameNoPrefixAng);

      const componentComponentNameAng = convertIntoPascalCase(originalComponentName).concat("Component");

      let mapDataAng = fs.readFileSync(pegaLocalAngularComponentMapPath, { encoding: 'utf8' });

      // componentKey twice for directory and file
      let importComponentAng = join(ANGULAR_COMPONENTS_DIRECTORY_PATH, categoryDirectoryAng, componentKey, componentNameNoPrefixAng);

      // POSIX path
      importComponentAng = "./".concat(importComponentAng).split(path.sep).join("/");

      let importFullAng = "import { ".concat(componentComponentNameAng).concat(" } from '").concat(importComponentAng).concat(".component';");
      let mapFullAng = "\"".concat(getSpecialCase(originalComponentName, framework)).concat("\" : " ).concat(componentComponentNameAng).concat(",");

      if (mapDataAng.indexOf(importComponentAng.concat(".component")) < 0) {
        // not present so we can add

        // add import
        let endImportIndex = mapDataAng.indexOf(IMPORT_END_TAG);
        let mapDataStart = mapDataAng.substring(0, endImportIndex);
        let mapDataEnd = mapDataAng.substring(endImportIndex);

        mapDataAng = mapDataStart.concat(importFullAng).concat("\n").concat(mapDataEnd);

        // add map
        let endMapIndex = mapDataAng.indexOf(MAP_END_TAG);
        mapDataStart = mapDataAng.substring(0, endMapIndex);
        mapDataEnd = mapDataAng.substring(endMapIndex);

        // when prettier involved need to append a comma on last line (because it removes it
        // so check if last line has comma, if not add, before appending
        const numChars = mapDataStart.length - 1;
        let appendArr = [];
        for (let i = numChars; i > 0; i--) {
           const myChar = mapDataStart[i];
           if (myChar != ' ' && myChar != '\n') {
            if (myChar == '{') {
              // group is empty
              break;
            }
            if (myChar != ',') {
              const strStart = mapDataStart.substring(0, i + 1);
              const strEnd = mapDataStart.substring(i+ 1);
              mapDataStart = strStart.concat(",").concat(strEnd);
              break;
            }
            else {
              // has comma, do nothing
              break;
            }
           }
        }

        mapDataAng = mapDataStart.concat("  ").concat(mapFullAng).concat("\n").concat(mapDataEnd);

        // prettier
        mapDataAng = await getPrettierFormattedString(mapDataAng);

        fs.writeFileSync(pegaLocalAngularComponentMapPath, mapDataAng, { encoding: 'utf8' });


      }
      break;
    case 'SDK-WebComponents' :
      break;

  }

};

export const deleteFromComponentMap = async (componentKey, category = CATEGORY_CUSTOM) =>  {

  const framework = await getFramework();

  // POSIX key
  componentKey = componentKey.split(path.sep).join("/");

  switch (framework) {
    case 'SDK-React' :
      const categoryDirectory = (category === CATEGORY_CONSTELLATION) ? join("/", COMPONENT_DIRECTORY_PREFIX_CUSTOM + category.toLowerCase()) : join("/", category.toLowerCase() + COMPONENT_DIRECTORY_SUFFIX_SDK);

      const componentNameNoPrefix = removeComponentPrefix(componentKey);
      const componentName = convertIntoPascalCase(componentNameNoPrefix);

      let mapData = fs.readFileSync(pegaLocalReactComponentMapPath, { encoding: 'utf8' });

      let importComponent = join(REACT_COMPONENTS_DIRECTORY_PATH, categoryDirectory, componentKey);

      // POSIX path
      importComponent = "./".concat(importComponent).split(path.sep).join("/");


      let importFull = "import ".concat(componentName).concat(" from '").concat(importComponent).concat("/';");
      let mapFull = "\"".concat(getSpecialCase(componentNameNoPrefix, framework)).concat("\" : " ).concat(componentName).concat(",");
      let mapFullPretty = getSpecialCase(componentNameNoPrefix, framework).concat(": ").concat(componentName);

      if (mapData.indexOf(importFull) >= 0) {

        let removeImport = importFull.concat("\n");
        let removeMap = "  ".concat(mapFull).concat("\n");
        let removeMapPrettyComma = "  ".concat(mapFullPretty).concat(",").concat("\n");
        let removeMapPretty = "  ".concat(mapFullPretty).concat("\n");

        mapData = mapData.replace(removeImport, "");
        mapData = mapData.replace(removeMap, "");

        // pretty with comma
        mapData = mapData.replace(removeMapPrettyComma, "");
        // pretty without comma
        mapData = mapData.replace(removeMapPretty, "");


        // prettier
        mapData = await getPrettierFormattedString(mapData);

        fs.writeFileSync(pegaLocalReactComponentMapPath, mapData, { encoding: 'utf8' });

      }
      break;
    case 'SDK-Angular' :
      const categoryDirectoryAng = (category === CATEGORY_CONSTELLATION) ? join("/", COMPONENT_DIRECTORY_PREFIX_CUSTOM + category.toLowerCase()) : join("/", category.toLowerCase() + COMPONENT_DIRECTORY_SUFFIX_SDK);

      const componentNameNoPrefixAng = removeComponentPrefix(componentKey);
      const originalComponenttNameConfigAng = await getLocalComponentKeyFromConfig(componentKey, category);
      const originalComponentName = originalComponenttNameConfigAng != "" ? originalComponenttNameConfigAng : reverseKebabCase(componentNameNoPrefixAng);

      const componentComponentNameAng = convertIntoPascalCase(originalComponentName).concat("Component");

      let mapDataAng = fs.readFileSync(pegaLocalAngularComponentMapPath, { encoding: 'utf8' });

      // componentKey twice for directory and file
      let importComponentAng = join(ANGULAR_COMPONENTS_DIRECTORY_PATH, categoryDirectoryAng, componentKey, componentNameNoPrefixAng);

      // POSIX path
      importComponentAng = "./".concat(importComponentAng).split(path.sep).join("/");


      let importFullAng = "import { ".concat(componentComponentNameAng).concat(" } from '").concat(importComponentAng).concat(".component';");
      let mapFullAng = "\"".concat(getSpecialCase(originalComponentName, framework)).concat("\" : " ).concat(componentComponentNameAng).concat(",");

      let mapFullAngPretty = getSpecialCase(originalComponentName, framework).concat(": ").concat(componentComponentNameAng);

      if (mapDataAng.indexOf(importFullAng) >= 0) {

        let removeImport = importFullAng.concat("\n");
        let removeMap = "  ".concat(mapFullAng).concat("\n");
        let removeMapPrettyComma = "  ".concat(mapFullAngPretty).concat(",").concat("\n");
        let removeMapPretty = "  ".concat(mapFullAngPretty).concat("\n");

        mapDataAng = mapDataAng.replace(removeImport, "");
        // original
        mapDataAng = mapDataAng.replace(removeMap, "");
        // pretty with comma
        mapDataAng = mapDataAng.replace(removeMapPrettyComma, "");
        // pretty without comma
        mapDataAng = mapDataAng.replace(removeMapPretty, "");

        // prettier
        mapDataAng = await getPrettierFormattedString(mapDataAng);

        fs.writeFileSync(pegaLocalAngularComponentMapPath, mapDataAng, { encoding: 'utf8' });

      }
      break;
    case 'SDK-WebComponents' :
      break;

  }

};

export const renameComponentInMap = async (oldComponentKey, newComponentKey) =>  {

  const framework = await getFramework();

  // POSIX key
  oldComponentKey = oldComponentKey.split(path.sep).join("/");
  newComponentKey = newComponentKey.split(path.sep).join("/");

  switch (framework) {
    case 'SDK-React' :

      const oldComponentNameNoPrefix = removeComponentPrefix(oldComponentKey);
      const oldComponentName = convertIntoPascalCase(oldComponentNameNoPrefix);

      const newComponentNameNoPrefix = removeComponentPrefix(newComponentKey);
      const newComponentName = convertIntoPascalCase(newComponentNameNoPrefix);

      let mapData = fs.readFileSync(pegaLocalReactComponentMapPath, { encoding: 'utf8' });

      if (mapData.indexOf(oldComponentName) >= 0) {

        mapData = mapData.replaceAll(oldComponentName + " ", newComponentName + " ");
        mapData = mapData.replaceAll(oldComponentName + ",", newComponentName + ",");

        // pretty
        // if last one, new line
        mapData = mapData.replaceAll(oldComponentName + "\n", newComponentName + "\n" );

        mapData = mapData.replaceAll(oldComponentNameNoPrefix + "/", newComponentNameNoPrefix + "/");
        mapData = mapData.replaceAll( '"' + oldComponentNameNoPrefix + '"' , '"' + newComponentNameNoPrefix + '"');

        // pretty
        mapData = mapData.replaceAll( getSpecialCase(oldComponentNameNoPrefix, framework) + ':' , getSpecialCase(newComponentNameNoPrefix, framework) + ':');

        // prettier
        mapData = await getPrettierFormattedString(mapData);

        fs.writeFileSync(pegaLocalReactComponentMapPath, mapData, { encoding: 'utf8' });

      }
      break;
    case 'SDK-Angular' :
      const oldComponentNameNoPrefixAng = removeComponentPrefix(oldComponentKey);
      const oldComponentNameAng = convertIntoPascalCase(oldComponentNameNoPrefixAng);
      const oldComponentKebabNameAng = convertIntoKebabCase(oldComponentNameAng);

      const newComponentNameNoPrefixAng = removeComponentPrefix(newComponentKey);
      const newComponentNameAng = convertIntoPascalCase(newComponentNameNoPrefixAng);
      const newComponentKebabNameAng = convertIntoKebabCase(newComponentNameAng);

      let mapDataAng = fs.readFileSync(pegaLocalAngularComponentMapPath, { encoding: 'utf8' });

      if (mapDataAng.indexOf(oldComponentNameAng) >= 0) {

        // get with space and comma first
        mapDataAng = mapDataAng.replaceAll(oldComponentNameAng + " ", newComponentNameAng + " ");
        mapDataAng = mapDataAng.replaceAll(oldComponentNameAng + ",", newComponentNameAng + ",");

        // pretty
        // if last one, new line
        mapDataAng = mapDataAng.replaceAll(oldComponentNameAng + "\n", newComponentNameAng + "\n" );

        mapDataAng = mapDataAng.replaceAll(oldComponentKebabNameAng + "/", newComponentKebabNameAng + "/");
        mapDataAng = mapDataAng.replaceAll(oldComponentKebabNameAng + ".component", newComponentKebabNameAng + ".component");

        mapDataAng = mapDataAng.replaceAll( '"' + oldComponentNameNoPrefixAng + '"' , '"' + newComponentNameNoPrefixAng + '"');
        mapDataAng = mapDataAng.replaceAll( oldComponentNameAng + 'Component' , newComponentNameAng + 'Component');

        // pretty
        mapDataAng = mapDataAng.replaceAll( getSpecialCase(oldComponentNameNoPrefixAng, framework) + ':' , getSpecialCase(newComponentNameNoPrefixAng, framework) + ':');

        // prettier
        mapDataAng = await getPrettierFormattedString(mapDataAng);

        fs.writeFileSync(pegaLocalAngularComponentMapPath, mapDataAng, { encoding: 'utf8' });

      }
      break;
    case 'WebComponents' :
      break;

  }

};


export const clearComponentMap = async () =>  {

  const framework = await getFramework();
  let blankMap;
  let blankMapData;

  switch (framework) {
    case 'SDK-React' :
      // get blank version
      blankMap = path.join(path.resolve(), COMPONENT_REACT_LIB_PATH, SDK_LOCAL_REACT_COMPONENT_MAP_FILENAME);

      blankMapData = fs.readFileSync(blankMap, { encoding: 'utf8' });

      // store blank version in sdk-local-component-map.js
      fs.writeFileSync(pegaLocalReactComponentMapPath, blankMapData, { encoding: 'utf8' });

      break;
    case 'SDK-Angular' :
      // get blank version
      blankMap = path.join(path.resolve(), COMPONENT_ANGULAR_LIB_PATH, SDK_LOCAL_ANGULAR_COMPONENT_MAP_FILENAME);

      blankMapData= fs.readFileSync(blankMap, { encoding: 'utf8' });

      // store blank version in sdk-local-component-map.js
      fs.writeFileSync(pegaLocalAngularComponentMapPath, blankMapData, { encoding: 'utf8' });
      break;
    case 'WebComponents' :
      break;

  }

};

export const isComponentInMap = (componentName, framework) => {

  let isInMap = true;

  switch (framework) {

    case "SDK-React":
      const mapData = fs.readFileSync(pegaLocalAngularComponentMapPath, { encoding: 'utf8' });
      const componentPascal = convertIntoPascalCase(componentName)


      if (mapDataAng.indexOf(componentName) < 0) {
        isInMap = false;
      }
      if (mapDataAng.indexOf(componentPascal) < 0) {
        isInMap = false;
      }

      break;
    case "SDK-Angular":
      const mapDataAng = fs.readFileSync(pegaLocalAngularComponentMapPath, { encoding: 'utf8' });
      const componentPascalAng = convertIntoPascalCase(componentName);
      const componentKebabAng = convertIntoKebabCase(componentPascalAng);

      if (mapDataAng.indexOf(componentName) < 0) {
        isInMap = false;
      }
      if (mapDataAng.indexOf(componentPascalAng) < 0) {
        isInMap = false;
      }
      if (mapDataAng.indexOf(componentKebabAng) < 0) {
        isInMap = false;
      }

      break;
    case "SDK-WebComponents":
      // need to handle this
      isInMap = false;
      break
  }

  return isInMap;

};

export const isComponentMapEmpty = (framework) => {
  let isEmpty = false;
  let blankMap;
  let blankMapData;
  let mapData;

  switch (framework) {
    case "SDK-React":
      blankMap = path.join(path.resolve(), COMPONENT_REACT_LIB_PATH, SDK_LOCAL_REACT_COMPONENT_MAP_FILENAME);
      blankMapData = fs.readFileSync(blankMap, { encoding: 'utf8' });
      mapData = fs.readFileSync(pegaLocalAngularComponentMapPath, { encoding: 'utf8' });

      if (mapData === blankMapData) {
        isEmpty = true;
      }

      break;
    case "SDK-Angular":
      blankMap = path.join(path.resolve(), COMPONENT_ANGULAR_LIB_PATH, SDK_LOCAL_ANGULAR_COMPONENT_MAP_FILENAME);
      blankMapData= fs.readFileSync(blankMap, { encoding: 'utf8' });
      mapData = fs.readFileSync(pegaLocalAngularComponentMapPath, { encoding: 'utf8' });

      if (mapData === blankMapData) {
        isEmpty = true;
      }

      break;
    case "SDK-WebComponents":
      break;
  }

  return isEmpty;
};
