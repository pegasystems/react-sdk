export { default } from './DetailsTwoColumn';
//# sourceMappingURL=index.d.ts.map