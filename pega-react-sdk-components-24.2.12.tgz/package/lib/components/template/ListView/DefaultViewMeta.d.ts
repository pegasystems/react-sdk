export default function getDefaultViewMeta(fieldMeta: any, classID: any, showField: any): any;
//# sourceMappingURL=DefaultViewMeta.d.ts.map