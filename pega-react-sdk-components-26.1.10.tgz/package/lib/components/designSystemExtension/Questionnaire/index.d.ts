export { default } from './Questionnaire';
//# sourceMappingURL=index.d.ts.map