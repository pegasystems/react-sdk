import { PConnProps } from '../../../types/PConnProps';
interface MultiReferenceReadOnlyProps extends PConnProps {
    config: {
        referenceList: any;
        readonlyContextList: any;
    };
    label: string;
    hideLabel: boolean;
}
export default function MultiReferenceReadOnly(props: MultiReferenceReadOnlyProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MultiReferenceReadOnly.d.ts.map