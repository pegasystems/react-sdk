interface ActionButtonsProps {
    arMainButtons?: any[];
    arSecondaryButtons?: any[];
    onButtonPress: any;
}
export default function ActionButtons(props: ActionButtonsProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=ActionButtons.d.ts.map