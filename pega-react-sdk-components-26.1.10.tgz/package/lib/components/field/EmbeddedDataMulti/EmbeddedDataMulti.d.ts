import type { PConnProps } from '../../../types/PConnProps';
interface EmbeddedDataMultiProps extends PConnProps {
    addEditAction?: string;
    addEditView?: string;
    displayAs?: string;
    editAction?: string;
    editMode?: string;
    editType?: string;
    editView?: string;
    readOnly?: boolean;
    repeatingView?: string;
    targetObjectClass?: string;
    useSeparateActionForEdit?: boolean;
    useSeparateViewForEdit?: boolean;
}
export default function EmbeddedDataMulti(props: EmbeddedDataMultiProps): import("react").JSX.Element | null;
export {};
//# sourceMappingURL=EmbeddedDataMulti.d.ts.map