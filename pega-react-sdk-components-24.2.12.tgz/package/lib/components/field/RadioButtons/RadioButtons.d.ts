import { PConnFieldProps } from '../../../types/PConnProps';
interface RadioButtonsProps extends PConnFieldProps {
    inline: boolean;
    fieldMetadata?: any;
}
export default function RadioButtons(props: RadioButtonsProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=RadioButtons.d.ts.map