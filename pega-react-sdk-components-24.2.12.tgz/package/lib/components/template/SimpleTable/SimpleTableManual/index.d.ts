export { default } from './SimpleTableManual';
//# sourceMappingURL=index.d.ts.map