export { default } from './Integer';
//# sourceMappingURL=index.d.ts.map