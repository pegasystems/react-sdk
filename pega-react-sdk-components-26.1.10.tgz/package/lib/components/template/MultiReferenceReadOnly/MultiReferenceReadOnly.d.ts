import type { PConnProps } from '../../../types/PConnProps';
interface MultiReferenceReadOnlyProps extends PConnProps {
    config: {
        referenceList: any;
        readonlyContextList: any;
    };
    label: string;
    hideLabel: boolean;
    displayMode?: any;
    displayAs?: any;
}
export default function MultiReferenceReadOnly(props: MultiReferenceReadOnlyProps): any;
export {};
//# sourceMappingURL=MultiReferenceReadOnly.d.ts.map