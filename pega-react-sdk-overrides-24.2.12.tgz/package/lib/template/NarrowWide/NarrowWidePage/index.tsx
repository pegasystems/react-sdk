export { default } from './NarrowWidePage';
