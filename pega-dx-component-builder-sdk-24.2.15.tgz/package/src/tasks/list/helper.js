import fs from 'fs';

import chalk from 'chalk';
import fetch from 'node-fetch';

import { LIST_COMPONENT_SERVICE_REST_ENDPOINT, TOKEN_PATH, COMPONENT_SCHEMA, CATEGORY_CUSTOM } from '../../constants.js';
import { constructCompleteUrl, getComponents, getPegaServerConfig, getHttpsAgent } from '../../util.js';


export const SOURCE_OF_COMPONENT_TYPES = {
  SERVER: 'Server',
  LOCAL: 'Local'
};


export const getListComponentsQuestions = async (options, sourceOfComponentsOption) => {
  const defaultPegaServerConfig = await getPegaServerConfig();

  return [

    {
      name: 'sourceOfComponents',
      type: 'rawlist',
      message: 'List components from Server or Local ?',
      choices: Object.values(SOURCE_OF_COMPONENT_TYPES),
      default: defaultPegaServerConfig.sourceOfComponents,
    },
    {
      name: 'category',
      type: 'rawlist',
      message: 'Category of components ?',
      choices: COMPONENT_SCHEMA.category,
      when(answers) {
        return answers.sourceOfComponents != "Server"
      }
    },
  ];
};

export const listLocalComponents = async (sourceOfComponents, category = CATEGORY_CUSTOM) => {
  let localComponents = await getComponents(false, category);
  localComponents = localComponents.map(name => ({ 'Rule name': name }));
  const sourceOfComponentsLC = sourceOfComponents.toLowerCase();
  if (localComponents.length > 0) {
    console.log(chalk.bold.blueBright(`List of ${sourceOfComponentsLC} ${category} components.`));
    console.table(localComponents, ['Rule name']);
  } else {
    console.log(chalk.bold.redBright(`No custom components in ${sourceOfComponents}`));
  }
};

export const getComponentsFromServer = async data => {
  const defaultPegaServerConfig = await getPegaServerConfig();
  const url = constructCompleteUrl(
    defaultPegaServerConfig.server,
    LIST_COMPONENT_SERVICE_REST_ENDPOINT
  );
  return new Promise((resolve, reject) => {
    try {
      fs.readFile(TOKEN_PATH, 'utf8', (err, data) => {
        if (err) {
          reject(
            `\n${chalk.bold.red(
              'Error occurred in authentication. Please regenerate using authenticate'
            )}`
          );
        }
        if (data) {
          const {
            access_token: accessToken,
            token_type: tokenType,
            refresh_token: refreshToken
          } = JSON.parse(data);
          let status = 500;
          fetch(url, {
            method: 'GET',
            agent: getHttpsAgent(defaultPegaServerConfig),
            headers: {
              Authorization: `${tokenType} ${accessToken}`
            }
          })
            .then(response => {
              status = response.status;
              if (status === 401) {
                throw new Error(
                  'Error occurred in authentication. Please regenerate using authenticate'
                );
                // console.log(accessTokenUri, refreshToken);
                /* TODO - Handle refresh_token */
              }
              else if (status === 404){
                throw new Error('404: Server resource not found');
              }
              else if (status === 405){
                throw new Error('405: Server method not allowed');
              }
              else if (status === 408){
                throw new Error('408: Server timed out');
              }

              return response.text();
            })
            .then(resp => {
              const respData = JSON.parse(resp);
              if (status == 200) {
                resolve(resp);
              } else {
                throw new Error(`${respData.message}`);
              }
            })
            .catch(e => reject(`${chalk.bold.red(e)}`));
        }
      });
    } catch (error) {
      console.log(`\n${chalk.bold.red(error)}`);
      reject(`${chalk.bold.red(error)}`);
    }
  });
};

export const displayServerComponents = async data => {
  const defaultPegaServerConfig = await getPegaServerConfig();
  const parsedData = JSON.parse(data);
  const componentList = parsedData.pxResults?.map(({ label, pyRuleSet, pyRuleSetVersion }) => ({
    'Rule name': label,
    'Ruleset name': pyRuleSet,
    'Ruleset version': pyRuleSetVersion
  }));

  const sourceOfComponentsLC = defaultPegaServerConfig.server.toLowerCase();
  if (componentList && componentList.length > 0) {
    console.log(
      chalk.bold.blueBright(`List of ${sourceOfComponentsLC} custom/override components.`)
    );
    console.table(componentList, ['Rule name', 'Ruleset name', 'Ruleset version']);
  } else {
    console.log(chalk.bold.redBright(`No ${sourceOfComponentsLC} custom/override components.`));
  }
};
