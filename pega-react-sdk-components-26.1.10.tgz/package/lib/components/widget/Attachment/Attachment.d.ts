import type { PConnFieldProps } from '../../../types/PConnProps';
import './Attachment.css';
interface AttachmentProps extends Omit<PConnFieldProps, 'value'> {
    value: any;
    allowMultiple: boolean | string;
    extensions: string;
    editMode: string;
    isTableFormatter: boolean;
}
export default function Attachment(props: AttachmentProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=Attachment.d.ts.map