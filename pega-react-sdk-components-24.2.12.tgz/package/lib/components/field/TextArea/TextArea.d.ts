import { PConnFieldProps } from '../../../types/PConnProps';
interface TextAreaProps extends PConnFieldProps {
    fieldMetadata?: any;
}
export default function TextArea(props: TextAreaProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=TextArea.d.ts.map