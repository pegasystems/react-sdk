declare const _default: {
    'DateTime-Long': (value: any, options: any) => string;
    'DateTime-Short': (value: any, options: any) => string;
    'DateTime-Since': (value: any) => string;
    'Time-Only': (value: any, options: any) => any;
    convertToTimezone: (value: any, options: any) => any;
    convertFromTimezone: (value: any, timezone: any) => any;
    Date: (value: any, options: any) => string;
    Currency: (value: any, options: any) => string;
    'Currency-Code': (value: any, options: any) => string;
    Decimal: (value: any, options: any) => string;
    'Decimal-Auto': (value: any, options: any) => string;
    Integer: (value: any, options: any) => string;
    Percentage: (value: any, options: any) => string;
    TrueFalse: (value: any, options: any) => any;
};
export default _default;
export declare function format(value: any, type: any, options?: {}): string;
//# sourceMappingURL=index.d.ts.map