/**
 * @example useFocusFirstField(id, viewName);
 * Focuses first editable field in the view based on field identity.
 */
declare const useFocusFirstField: (id: any, viewName: any) => void;
export default useFocusFirstField;
//# sourceMappingURL=useFocusFirstField.d.ts.map