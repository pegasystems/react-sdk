import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../types/PConnProps';
interface AssignmentProps extends PConnProps {
    itemKey: string;
    isInModal: boolean;
    banners: any[];
    actionButtons: any[];
}
export default function Assignment(props: PropsWithChildren<AssignmentProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Assignment.d.ts.map