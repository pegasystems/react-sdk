import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../types/PConnProps';
import './View.css';
interface ViewProps extends PConnProps {
    template?: string;
    label?: string;
    showLabel: boolean;
    mode?: string;
    title?: string;
    visibility?: boolean;
    name?: string;
    bInForm?: boolean;
    type?: any;
}
declare function View(props: PropsWithChildren<ViewProps>): import("react/jsx-runtime").JSX.Element | "" | null;
declare namespace View {
    var additionalProps: (state: any, getPConnect: any) => {};
}
export default View;
//# sourceMappingURL=View.d.ts.map