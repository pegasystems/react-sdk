export { default } from './NarrowWideDetails';
//# sourceMappingURL=index.d.ts.map