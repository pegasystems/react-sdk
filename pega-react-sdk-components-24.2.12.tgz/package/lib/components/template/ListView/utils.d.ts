export declare const formatConstants: {
    WorkStatus: string;
    Integer: string;
    WorkLink: string;
};
export declare function getContext(componentConfig: any): Promise<{
    promisesResponseArray: any[];
    setPropertyMaps: (originalToMappedPropertyObj?: {}, mappedToOriginalPropertyObj?: {}) => void;
    getMappedProperty: (propertyName: any) => any;
    getOriginalProperty: (propertyName: any) => any;
}>;
/**
 * [getFieldNameFromEmbeddedFieldName]
 * Description    -               converting embeddedField name starting with !P! or !PL! to normal field
 * @ignore
 * @param {string} propertyName   EmbeddedField name starting with !P! or !PL!
 * @returns {string}              returns converted string without !P! or !PL! and :
 *
 * @example <caption>Example for getFieldNameFromEmbeddedFieldName </caption>
 * getFieldNameFromEmbeddedFieldName('!P!Organisation:Name') return 'Organisation.Name'
 * getFieldNameFromEmbeddedFieldName('!PL!Employees:Name') return 'Employees.Name'
 */
export declare function getFieldNameFromEmbeddedFieldName(propertyName: any): any;
/**
 * [updateMetaEmbeddedFieldID]
 * Description    -           If the fieldID in meta starts with '!P!' or '!PL!' and contains ':' then replace them with .(dot)
 * @ignore
 * @param {Array} metaFields  Fields metadata Array. Contains metadata of all the fields.
 */
export declare function updateMetaEmbeddedFieldID(metaFields: any): any;
export declare const isEmbeddedField: (field: any) => boolean;
/**
 * [isPageListProperty]
 * Description    -        checking if propertyName is pageList or not
 * @ignore
 * @param {string} propertyName   PropertyName
 * @returns {boolean}  true if property is pageList else false
 *
 * @example <caption>Example for isPageListProperty </caption>
 * isPageListProperty('!PL!Employees.Name') return true
 * isPageListProperty('!P!Employees.Name') return false
 * isPageListProperty('Name') return false
 */
export declare function isPageListProperty(propertyName: any): any;
export declare const isPageListInPath: (propertyName: any, currentClassID: any) => any;
/**
 * [getEmbeddedFieldName]
 * Description    -               converting normal field name to embedded field starting with !P! or !PL!
 * @ignore
 * @param {string} propertyName   Field name
 * @param {string} classID        classID of datapage
 * @returns {string}              returns converted string with !P! or !PL! and :
 *
 * @example <caption>Example for getEmbeddedFieldName </caption>
 * For page property, getEmbeddedFieldName('Organisation.Name') return '!P!Organisation:Name'
 * For pageList property, getEmbeddedFieldName('Employees.Name') return '!PL!Employees:Name'
 */
export declare function getEmbeddedFieldName(propertyName: any, classID: any): any;
/**
 * [preparePropertyMaps]
 * Description    -        preparing maps for property names and set it in dataApi context
 * @ignore
 * @param {Array} fields   fields array
 * @param {string} classID  classID of datapage
 * @param {string} context  dataApi context
 * @returns {boolean} true if pageListProperty is present
 */
export declare function preparePropertyMaps(fields: any, classID: any, context: any): any;
/**
 * [getConfigEmbeddedFieldsMeta]
 * Description    -           Get the metadata for configured embedded fields
 * @ignore
 * @param {Set} configFields  Set of config fields
 * @param {string} classID    clasID of datapage
 * @returns {Array}           Metadata of configured embedded fields
 */
export declare function getConfigEmbeddedFieldsMeta(configFields: any, classID: any): any[];
/**
 * [mergeConfigEmbeddedFieldsMeta]
 * Description    -           Get the metadata for configured embedded fields
 * @ignore
 * @param {Array} configEmbeddedFieldsMeta  config fields metadata.
 * @param {Array} metaFields  Fields metadata Array. Contains metadata of all the fields
 */
export declare function mergeConfigEmbeddedFieldsMeta(configEmbeddedFieldsMeta: any, metaFields: any): any[];
/**
 * [getTableConfigFromPresetMeta]
 * Description - Get the table config from the presets meta.
 * @ignore
 * @param   {object}    presetMeta          Presets meta
 * @param   {boolean}   isMetaWithPresets   true if meta has presets else false
 * @param   {Function}  getPConnect         Callback to get the PConnect object
 * @param   {string}    classID             Class ID from the response
 * @param   {Array}     primaryFields       List of Primary Fields
 * @param   {Array}     metaFields          List of all metafields
 * @returns {object}                        Table config object
 */
export declare function getTableConfigFromPresetMeta(presetMeta: any, isMetaWithPresets: any, getPConnect: any, classID: any, primaryFields: any, metaFields: any): {
    presetId: any;
    presetName: any;
    cardHeader: any;
    secondaryText: any;
    timelineDate: any;
    timelineTitle: any;
    timelineStatus: any;
    timelineIcon: any;
    filterExpression: any;
    fieldsMeta: any;
    configFields: any;
};
export declare function initializeColumns(fields?: any[], getMappedProperty?: any): any[];
export declare const getItemKey: (fields: any) => any;
export declare function preparePatchQueryFields(fields: any, isDataObject?: boolean, classID?: string): any[];
/**
 * Update the renderer type for the properties of type Page.
 */
export declare function updatePageFieldsConfig(configFields: any, parentClassID: any): any;
export declare const readContextResponse: (context: any, params: any) => Promise<void>;
//# sourceMappingURL=utils.d.ts.map