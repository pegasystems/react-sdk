import { PConnFieldProps } from '../../../types/PConnProps';
interface SemanticLinkProps extends PConnFieldProps {
    text: string;
}
export default function SemanticLink(props: SemanticLinkProps): import("react/jsx-runtime").JSX.Element | undefined;
export {};
//# sourceMappingURL=SemanticLink.d.ts.map