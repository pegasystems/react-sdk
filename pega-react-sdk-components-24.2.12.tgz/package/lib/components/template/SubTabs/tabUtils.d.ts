export declare const getDeferFriendlyTabs: (allTabs: any) => any;
export declare const getVisibleTabs: (allTabs: any, uuid: any) => any;
export declare const getTransientTabs: (availableTabs: any, currentTabId: any, tabItems: any) => any;
export declare const tabClick: (id: any, availableTabs: any, currentTabId: any, setCurrentTabId: any, tabItems: any) => void;
//# sourceMappingURL=tabUtils.d.ts.map