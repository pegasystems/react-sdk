import type { PConnProps } from '../../../../../types/PConnProps';
interface DataViewActionButtonsProps extends PConnProps {
    context: string;
    classId: string;
    dataObjectAction: string;
    dataRecordKeys: string;
    actionID: string;
    closeActionsDialog: () => void;
}
export default function DataViewActionButtons(props: DataViewActionButtonsProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=DataViewActionButtons.d.ts.map