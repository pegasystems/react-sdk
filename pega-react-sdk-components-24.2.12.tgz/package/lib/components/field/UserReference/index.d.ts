export { default } from './UserReference';
//# sourceMappingURL=index.d.ts.map