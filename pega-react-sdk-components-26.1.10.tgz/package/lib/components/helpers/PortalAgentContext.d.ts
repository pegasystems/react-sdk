import type { ReactNode } from 'react';
export interface PortalAgentContextValue {
    showAgentPanel: boolean;
    agentExpanded: boolean;
    onAgentToggle: () => void;
    onAgentClick: () => void;
    /**
     * The page-content panel rendered to the right of the agent in the portal
     * split view.  `undefined` when not in portal-agent mode.
     */
    pagePanel?: {
        /** The page-content node rendered in the right panel. */
        content: ReactNode;
        /** Whether the right panel is currently visible. */
        visible: boolean;
    };
}
declare const PortalAgentContext: import("react").Context<PortalAgentContextValue>;
export default PortalAgentContext;
//# sourceMappingURL=PortalAgentContext.d.ts.map