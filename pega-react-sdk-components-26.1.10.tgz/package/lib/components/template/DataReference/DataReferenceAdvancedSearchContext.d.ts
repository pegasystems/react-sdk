declare const DataReferenceAdvancedSearchContext: import("react").Context<{
    disableStartingFieldsForReference: boolean;
    dataReferenceConfigToChild: {
        selectionMode: string;
    };
}>;
export default DataReferenceAdvancedSearchContext;
//# sourceMappingURL=DataReferenceAdvancedSearchContext.d.ts.map