declare function getDataReferenceInfo(pConnect: any, dataRelationshipContext: any): {
    dataContext: string;
    dataContextParameters: {};
} | {
    dataContext?: undefined;
    dataContextParameters?: undefined;
};
declare function isLinkTextEmpty(text: any): boolean;
declare const _default: {
    getDataReferenceInfo: typeof getDataReferenceInfo;
    isLinkTextEmpty: typeof isLinkTextEmpty;
};
export default _default;
//# sourceMappingURL=utils.d.ts.map