export { default } from './WideNarrowDetails';
//# sourceMappingURL=index.d.ts.map