import type { CoachMessageProps, MarkdownMap } from '../components/designSystemExtension/GenAICoachContent/GenAICoach.types';
import type { GetActiveCoach, SetMessagesUpdater, StreamEvent } from '../components/widget/GenAICoach/GenAICoach.types';
/**
 * Manages the message-object lifecycle for an agent SSE stream.
 *
 * During a PERFORM_ASSIGNMENT (PA) flow, two persistent message objects are maintained:
 * 1. A progress indicator message — created on the first PA toolCallStart, updated in-place.
 * 2. A text message — created on the first `message` event after a PA tool call.
 *
 * Call `finalizeStream` after the stream ends and before applying final response metadata.
 */
declare const useAgentStreamHandler: (setMessages: SetMessagesUpdater, getActiveCoach: GetActiveCoach, markdownMap?: MarkdownMap) => {
    handleAgentStreamEvent: (event: StreamEvent) => void;
    resetStreamState: () => void;
    finalizeAgentStream: (needsToolConfirmation?: boolean) => void;
    cancelAgentStream: (stopped?: boolean, addFeedback?: (msg: CoachMessageProps) => CoachMessageProps) => void;
};
export default useAgentStreamHandler;
//# sourceMappingURL=useAgentStreamHandler.d.ts.map