export { default } from './ScalarList';
//# sourceMappingURL=index.d.ts.map