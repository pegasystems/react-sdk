import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../../types/PConnProps';
import './WideNarrow.css';
interface WideNarrowProps extends PConnProps {
    a: any;
    b: any;
    title?: string;
    cols?: string;
    icon?: string;
}
export default function WideNarrow(props: PropsWithChildren<WideNarrowProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=WideNarrow.d.ts.map