import type { PConnFieldProps } from '../../../types/PConnProps';
interface URLComponentProps extends PConnFieldProps {
    showFieldMessage?: boolean;
    messageConfig?: {
        content?: string;
        visibility?: boolean;
    };
    variant?: string;
}
export default function URLComponent(props: URLComponentProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=URL.d.ts.map