import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../types/PConnProps';
interface BannerPageProps extends PConnProps {
    layout?: string;
    heading?: string;
    message?: string;
    imageTheme?: string;
    backgroundImage?: string;
    backgroundColor?: string;
    tintImage?: boolean;
}
export default function BannerPage(props: PropsWithChildren<BannerPageProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=BannerPage.d.ts.map