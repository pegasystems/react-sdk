export { default } from './HierarchicalForm';
//# sourceMappingURL=index.d.ts.map