import type { PConnFieldProps } from '../../../types/PConnProps';
interface TextInputProps extends PConnFieldProps {
    fieldMetadata?: any;
    showFieldMessage?: boolean;
    messageConfig?: {
        content?: string;
        visibility?: boolean;
    };
    variant?: string;
}
export default function TextInput(props: TextInputProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=TextInput.d.ts.map