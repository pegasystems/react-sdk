/// <reference types="react" />
export declare const getPConnectOfActiveContainerItem: (containerInfo: any, options: any) => (() => import("@pega/pcore-pconnect-typedefs/interpreter/c11n-env").C11nEnv) | null;
export declare const getActiveContainerRootViewElement: (containerInfo: any, options: any) => import("react").CElement<{
    getPConnect: () => import("@pega/pcore-pconnect-typedefs/interpreter/c11n-env").C11nEnv;
}, import("react").Component<{
    getPConnect: () => import("@pega/pcore-pconnect-typedefs/interpreter/c11n-env").C11nEnv;
}, any, any>> | null;
export declare const getActiveContainerItemID: (containerInfo: any) => any;
export declare const useContainerInitializer: (getPConnect: any, mode: any) => void;
//# sourceMappingURL=helper.d.ts.map