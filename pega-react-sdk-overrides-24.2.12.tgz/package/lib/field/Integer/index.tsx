export { default } from './Integer';
