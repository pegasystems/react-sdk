import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../types/PConnProps';
interface InlineDashboardProps extends PConnProps {
    title: string;
    filterPosition?: string;
}
export default function InlineDashboard(props: PropsWithChildren<InlineDashboardProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=InlineDashboard.d.ts.map