export { default } from './GenAIMessageFeedback';
//# sourceMappingURL=index.d.ts.map