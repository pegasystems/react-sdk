# The **Widget** directory

The **SDK-Angular/Widget** directory contains the template code for the widget components you want to use with the **Angular SDK**.

