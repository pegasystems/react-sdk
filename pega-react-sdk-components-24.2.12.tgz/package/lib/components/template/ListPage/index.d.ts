export { default } from './ListPage';
//# sourceMappingURL=index.d.ts.map