import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../types/PConnProps';
interface FollowersProps extends PConnProps {
}
export default function Followers(props: PropsWithChildren<FollowersProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=Followers.d.ts.map