/**
 * versionHelpers.ts
 *
 * Container helper functions that can identify which version of
 * PCore/PConnect is being run
 */
export declare const sdkVersion = "8.7";
export declare function compareSdkPCoreVersions(): void;
//# sourceMappingURL=versionHelpers.d.ts.map