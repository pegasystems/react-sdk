export default function AdvancedSearch(props: any): import("react").JSX.Element;
//# sourceMappingURL=AdvancedSearch.d.ts.map