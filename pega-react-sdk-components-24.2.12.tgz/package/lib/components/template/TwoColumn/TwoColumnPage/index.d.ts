export { default } from './TwoColumnPage';
//# sourceMappingURL=index.d.ts.map