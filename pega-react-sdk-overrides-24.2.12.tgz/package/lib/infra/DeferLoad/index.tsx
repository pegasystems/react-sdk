export { default } from './DeferLoad';
