export declare const TABLE_CELL = "SdkRenderer";
export declare const DELETE_ICON = "DeleteIcon";
export declare const getContext: (thePConn: any) => {
    contextName: any;
    referenceListStr: any;
    pageReferenceForRows: any;
};
export declare const populateRowKey: (rawData: any) => any;
export declare const getApiContext: (processedData: any, pConnect: any, reorderCB: any) => {
    fetchData: () => Promise<unknown>;
    fetchPersonalizations: () => Promise<{}>;
    applyRowReorder: (sourceKey: any, destinationKey: any) => Promise<any>;
};
export declare const buildMetaForListView: (fieldMetadata: any, fields: any, type: any, ruleClass: any, name: any, propertyLabel: any, isDataObject: any, parameters: any) => {
    name: any;
    config: {
        type: any;
        referenceList: any;
        parameters: any;
        personalization: boolean;
        isDataObject: any;
        grouping: boolean;
        globalSearch: boolean;
        reorderFields: boolean;
        toggleFieldVisibility: boolean;
        title: any;
        personalizationId: string;
        template: string;
        presets: {
            name: string;
            template: string;
            config: {};
            children: {
                name: string;
                type: string;
                children: any;
            }[];
            label: any;
            id: string;
        }[];
        ruleClass: any;
    };
};
export declare const buildFieldsForTable: (configFields: any, fields: any, showDeleteButton: any) => any;
export declare const createMetaForTable: (fields: any, renderMode: any) => {
    height: {
        minHeight: string;
        fitHeightToElement: string;
        deltaAdjustment: string;
        autoSize: boolean;
    };
    fieldDefs: any;
    itemKey: string;
    grouping: boolean;
    reorderFields: boolean;
    reorderItems: boolean;
    dragHandle: boolean;
    globalSearch: boolean;
    personalization: boolean;
    toggleFieldVisibility: boolean;
    toolbar: boolean;
    footer: boolean;
    filterExpression: null;
    editing: boolean;
    timezone: string | undefined;
};
/**
 * This method returns a callBack function for Add action.
 * @param {object} pConnect - PConnect object
 * @param {number} index - index of the page list to add
 */
export declare const getAddRowCallback: (pConnect: any, index: any) => () => any;
/**
 * This method creates a PConnect object with proper options for Add and Delete actions
 * @param {string} contextName - contextName
 * @param {string} referenceList - referenceList
 * @param {string} pageReference - pageReference
 */
export declare function createPConnect(contextName: any, referenceList: any, pageReference: any): any;
export declare const filterData: (filterByColumns: any) => (item: any) => boolean;
//# sourceMappingURL=simpleTableHelpers.d.ts.map