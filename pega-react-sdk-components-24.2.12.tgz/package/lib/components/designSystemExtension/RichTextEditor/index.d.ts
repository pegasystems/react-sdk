export { default } from './RichTextEditor';
//# sourceMappingURL=index.d.ts.map