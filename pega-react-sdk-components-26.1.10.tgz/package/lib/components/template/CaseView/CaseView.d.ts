import { type PropsWithChildren } from 'react';
import type { GenAICoach } from '../../widget/GenAICoach/GenAICoach.types';
import type { PConnProps } from '../../../types/PConnProps';
interface CaseViewProps extends PConnProps {
    icon: string;
    subheader: string;
    header: string;
    showIconInHeader: boolean;
    caseInfo: any;
    lastUpdateCaseTime: any;
    coaches?: GenAICoach[];
}
export default function CaseView(props: PropsWithChildren<CaseViewProps>): import("react").JSX.Element;
export {};
//# sourceMappingURL=CaseView.d.ts.map