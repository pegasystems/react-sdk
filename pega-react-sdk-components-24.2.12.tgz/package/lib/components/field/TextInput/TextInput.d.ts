import { PConnFieldProps } from '../../../types/PConnProps';
interface TextInputProps extends PConnFieldProps {
    fieldMetadata?: any;
}
export default function TextInput(props: TextInputProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=TextInput.d.ts.map