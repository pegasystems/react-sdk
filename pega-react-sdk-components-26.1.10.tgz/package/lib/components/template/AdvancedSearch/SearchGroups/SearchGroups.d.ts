import React from 'react';
export declare const initializeSearchFields: (searchFields: any, getPConnect: any, referenceListClassID: any, searchFieldRestoreValues?: {}) => {};
export default function SearchGroups(props: any): React.JSX.Element;
//# sourceMappingURL=SearchGroups.d.ts.map