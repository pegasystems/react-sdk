/// <reference types="react" />
export declare const NavContext: import("react").Context<{
    open: boolean;
    setOpen: (f: any) => any;
}>;
export declare const useNavBar: () => {
    open: boolean;
    setOpen: (f: any) => any;
};
//# sourceMappingURL=reactContextHelpers.d.ts.map