import { PropsWithChildren } from 'react';
interface FieldGroupProps {
    name?: string;
    collapsible?: boolean;
    instructions?: string;
}
export default function FieldGroup(props: PropsWithChildren<FieldGroupProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=FieldGroup.d.ts.map