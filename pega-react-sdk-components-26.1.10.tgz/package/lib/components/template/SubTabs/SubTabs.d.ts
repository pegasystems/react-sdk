import { type PropsWithChildren } from 'react';
import type { PConnProps } from '../../../types/PConnProps';
interface SubTabsProps extends PConnProps {
}
export default function SubTabs(props: PropsWithChildren<SubTabsProps>): import("react").JSX.Element;
export {};
//# sourceMappingURL=SubTabs.d.ts.map