import { PConnFieldProps } from '../../../types/PConnProps';
interface DropdownProps extends PConnFieldProps {
    datasource?: any[];
    onRecordChange?: any;
    fieldMetadata?: any;
    listType: string;
    deferDatasource?: boolean;
    datasourceMetadata?: any;
    parameters?: any;
    columns: any[];
}
export default function Dropdown(props: DropdownProps): import("react/jsx-runtime").JSX.Element | null;
export {};
//# sourceMappingURL=Dropdown.d.ts.map