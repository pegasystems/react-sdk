import { type PropsWithChildren } from 'react';
import type { PConnProps } from '../../../types/PConnProps';
import 'react-datepicker/dist/react-datepicker.css';
interface DashboardFilterProps extends PConnProps {
    name: string;
    filterProp: string;
    type?: string;
    metadata?: any;
}
export default function DashboardFilter(props: PropsWithChildren<DashboardFilterProps>): import("react").JSX.Element;
export {};
//# sourceMappingURL=DashboardFilter.d.ts.map