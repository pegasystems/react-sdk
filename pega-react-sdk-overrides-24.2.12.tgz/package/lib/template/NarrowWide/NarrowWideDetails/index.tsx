export { default } from './NarrowWideDetails';
