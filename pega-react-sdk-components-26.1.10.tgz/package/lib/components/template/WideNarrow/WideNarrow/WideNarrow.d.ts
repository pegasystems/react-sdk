import type { PropsWithChildren } from 'react';
import type { PConnProps } from '../../../../types/PConnProps';
import './WideNarrow.css';
interface WideNarrowProps extends PConnProps {
    a: any;
    b: any;
    title?: string;
    cols?: string;
    icon?: string;
}
export default function WideNarrow(props: PropsWithChildren<WideNarrowProps>): import("react").JSX.Element;
export {};
//# sourceMappingURL=WideNarrow.d.ts.map