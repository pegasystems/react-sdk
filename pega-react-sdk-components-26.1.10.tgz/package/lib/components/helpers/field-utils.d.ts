import type { SxProps } from '@mui/material';
import type { Status } from '../../hooks/useStatus';
/**
 * Returns sx prop for TextField/MuiTelInput/Picker components based on status.
 * Shows red helper text when status is 'warning'.
 */
export declare const getFieldSx: (status: Status) => SxProps | undefined;
/**
 * Returns sx prop for FormControl-based components (RadioButtons, Checkbox).
 * Shows red helper text when status is 'warning'.
 */
export declare const getFormControlSx: (status: Status) => SxProps | undefined;
//# sourceMappingURL=field-utils.d.ts.map