export { default } from './URL';
//# sourceMappingURL=index.d.ts.map