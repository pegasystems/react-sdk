import type { PConnProps } from '../../../../types/PConnProps';
import './ActionButtonsForFileUtil.css';
interface ActionButtonsForFileUtilProps extends PConnProps {
    arMainButtons: any[];
    arSecondaryButtons: any[];
    primaryAction: any;
    secondaryAction: any;
}
export default function ActionButtonsForFileUtil(props: ActionButtonsForFileUtilProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=ActionButtonsForFileUtil.d.ts.map