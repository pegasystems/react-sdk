export declare const getUserId: (user: any) => string;
export declare const isUserNameAvailable: (user: any) => any;
//# sourceMappingURL=UserReferenceUtils.d.ts.map