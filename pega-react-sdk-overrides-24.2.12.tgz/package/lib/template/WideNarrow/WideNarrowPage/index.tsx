export { default } from './WideNarrowPage';
