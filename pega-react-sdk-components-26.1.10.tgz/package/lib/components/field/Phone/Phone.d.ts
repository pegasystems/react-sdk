import type { PConnFieldProps } from '../../../types/PConnProps';
interface PhoneProps extends PConnFieldProps {
    showFieldMessage?: boolean;
    messageConfig?: {
        content?: string;
        visibility?: boolean;
    };
    variant?: string;
}
export default function Phone(props: PhoneProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=Phone.d.ts.map