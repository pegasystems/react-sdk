export { default } from './NarrowWideForm';
