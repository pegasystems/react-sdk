import { PConnProps } from '../../../types/PConnProps';
interface ListPageProps extends PConnProps {
    parameters: object;
}
export default function ListPage(props: ListPageProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=ListPage.d.ts.map