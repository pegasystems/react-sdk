import { PropsWithChildren } from 'react';
import { PConnProps } from '../../../types/PConnProps';
import './MultiStep.css';
interface MultiStepProps extends PConnProps {
    itemKey: string;
    actionButtons: any[];
    onButtonPress: any;
    bIsVertical: boolean;
    arNavigationSteps: any;
}
export default function MultiStep(props: PropsWithChildren<MultiStepProps>): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=MultiStep.d.ts.map