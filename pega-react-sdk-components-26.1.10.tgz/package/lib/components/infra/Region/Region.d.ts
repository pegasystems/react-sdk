import type { PropsWithChildren } from 'react';
interface RegionProps {
}
export default function Region(props: PropsWithChildren<RegionProps>): import("react").JSX.Element;
export {};
//# sourceMappingURL=Region.d.ts.map