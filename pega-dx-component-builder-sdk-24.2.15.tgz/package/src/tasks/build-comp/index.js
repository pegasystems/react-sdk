import inquirer from 'inquirer';
import { Listr } from 'listr2';
import chalk from 'chalk';

import validate from '../validator/index.js';

import { bundleReactComponent, bundleAngularComponent, bundleAssociatedComponent} from '../bundle/index.js';
import lintComponent from '../linter/index.js';
import { getBuildComponentQuestions, getBuildCategory, cleanUp } from './helper.js';
import { getComponentDirectoryPath, showVersion, getOptionsCategory, getFramework, getLocalComponentKeyFromConfig, convertIntoKebabCase, convertIntoPascalCase } from '../../util.js';

import { CATEGORY_CUSTOM } from '../../constants.js';


export default async options => {
  showVersion();

  const framework = await getFramework();

  let category;
  let componentKey;
  let sourceMap;
  let devBuild;
  let content;

  if (options.params.length >= 7) {
    category = options.params[3]
    componentKey = options.params[4];
    sourceMap = options.params[5];
    const dBuild = options.params[6];
    devBuild = (dBuild === 'Y' ||
    dBuild === 'y' ||
    dBuild === true ||
    dBuild === 'true') ? true : false;

    content = { componentKey, sourceMap, devBuild};
  }
  else {
    const catQuestion = await getBuildCategory(options);
    const catAnswers = await inquirer.prompt(catQuestion);

    category = catAnswers.category;
    if (category == null) {
      category = getOptionsCategory(options);
    }

    const questions = await getBuildComponentQuestions(category);
    const answers = await inquirer.prompt(questions);
    ({ componentKey, sourceMap, devBuild } = answers);

    content = {
      ...answers
    };

  }

  const sDevBuild = devBuild ? '(dev build)' : '';
  const sFramework = framework.split("-")[1];

  let associatedComponentKey = componentKey;

  switch (framework) {
    case "SDK-Angular":
      let arComp = componentKey.split("/");
      arComp[1] = convertIntoKebabCase(convertIntoPascalCase(arComp[1]));
      componentKey = arComp.join("/")
      break;
    case "SDK-React":
      break;
    case "SDK-WebComponents":
      break;
  }


  const customTasks = new Listr(
    [
      {
        title: 'Validate config schema',
        task: async () => {
          await validate(componentKey, category);
        }
      },
      {
        title: `Lint ${sFramework} component`,
        task: async () => {
          const targetDirectory = await getComponentDirectoryPath(componentKey, category);
          // console.log(`in buildComponent Lint component task: componentKey: ${componentKey} targetDirectory: ${targetDirectory}`);
          await lintComponent(targetDirectory);
        }
      },
      {
        title: `Bundle React component ${sDevBuild}`,
        task: async () => await bundleReactComponent(componentKey, sourceMap, devBuild, category),
        enabled: ok => framework === "SDK-React"
      },
      {
        title: `Bundle Angular component ${sDevBuild}`,
        task: async () => await bundleAngularComponent(componentKey, sourceMap, devBuild, category),
        enabled: ok => framework === "SDK-Angular"
      },
      {
        title: 'Lint associated component',
        task: async () => {
          const targetDirectory = await getComponentDirectoryPath(associatedComponentKey, "constellation");
          // console.log(`in buildComponent Lint component task: componentKey: ${componentKey} targetDirectory: ${targetDirectory}`);
          await lintComponent(targetDirectory);
        }
      },
      {
        title: `Bundle associated component ${sDevBuild}`,
        task: async () => await bundleAssociatedComponent(associatedComponentKey, sourceMap, devBuild, "constellation")
      }
    ],
    {
      exitOnError: true
    }
  );

  const overrideTasks = new Listr(
    [
      {
        title: 'Validate config schema',
        task: async () => {
          await validate(componentKey, category);
        }
      },
      {
        title: `Lint ${sFramework} component`,
        task: async () => {
          const targetDirectory = await getComponentDirectoryPath(componentKey, category);
          // console.log(`in buildComponent Lint component task: componentKey: ${componentKey} targetDirectory: ${targetDirectory}`);
          await lintComponent(targetDirectory);
        }
      },
      {
        title: `Bundle React component ${sDevBuild}`,
        task: async () => await bundleReactComponent(componentKey, sourceMap, devBuild, category),
        enabled: ok => framework === "SDK-React"
      },
      {
        title: `Bundle Angular component ${sDevBuild}`,
        task: async () => await bundleAngularComponent(componentKey, sourceMap, devBuild, category),
        enabled: ok => framework === "SDK-Angular"
      }
    ],
    {
      exitOnError: true
    }
  );

  if (category == CATEGORY_CUSTOM) {
    await customTasks.run().catch(err => {
      console.log(chalk.bold.red(err.toString()));
    });
  }
  else {
    await overrideTasks.run().catch(err => {
      console.log(chalk.bold.red(err.toString()));
    });
  }


  cleanUp();

  return true;
};
