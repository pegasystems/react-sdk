interface AlertBannerProps {
    id: string;
    variant: string;
    messages: string[];
    onDismiss?: any;
}
export default function AlertBanner(props: AlertBannerProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=AlertBanner.d.ts.map