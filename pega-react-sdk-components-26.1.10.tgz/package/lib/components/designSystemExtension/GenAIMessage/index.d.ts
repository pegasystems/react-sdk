export { default } from './GenAIMessage';
//# sourceMappingURL=index.d.ts.map