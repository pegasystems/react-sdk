export { default } from './MultiStep';
//# sourceMappingURL=index.d.ts.map