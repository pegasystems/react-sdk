export { default } from './NarrowWideForm';
//# sourceMappingURL=index.d.ts.map