export { default } from './SummaryList';
//# sourceMappingURL=index.d.ts.map